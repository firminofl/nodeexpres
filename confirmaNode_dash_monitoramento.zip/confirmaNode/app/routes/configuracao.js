var express = require('express');
var router = express.Router();
var configuracoes_controller = require('../controller/configuracoes');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Mostrar todos os registros na tela
router.get('/select', configuracoes_controller.select);

//Update no banco para configurações
router.post('/update', configuracoes_controller.update);

//restart do dialer
router.get('/restart', configuracoes_controller.restart);
module.exports = router;
