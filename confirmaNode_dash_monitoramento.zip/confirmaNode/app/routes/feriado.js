var express = require('express');
var router = express.Router();
var feriados_controller = require('../controller/feriados');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Cadastrar feriado
router.post('/insert', feriados_controller.insert);

//Buscar todos os feriados
router.get('/select', feriados_controller.select);

//Atualizar feriado
router.post('/update', feriados_controller.update);

//Exclui feriado
router.post('/delete', feriados_controller.delete);

module.exports = router;
