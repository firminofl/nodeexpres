const pg = require('../db');
const exec = require('child_process').exec;
// Requiring fs module in which 
// writeFile function is defined. 
const fs = require('fs')

var houveAlteracaoEstatico = 0;
var houveAlteracaoDomingo = 0;
var houveAlteracaoSegunda = 0;
var houveAlteracaoTerca = 0;
var houveAlteracaoQuarta = 0;
var houveAlteracaoQuinta = 0;
var houveAlteracaoSexta = 0;
var houveAlteracaoSabado = 0;

module.exports = {
    select: (req, res) => {
        //Buscar informações de domingo
        var selectDomingo = 'SELECT * FROM dia_semana;';
        pg.query(selectDomingo, [], (err, ans) => {
            if (err) {
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao atualizar as informações de domingo.'
                });
            } else {
                fs.readFile(__dirname + '/alteracaoDiasSemana.txt', (err, data) => {
                    res.status(200).send({
                        rows: ans.rows,
                        houveAlteracao: parseInt(data)
                    });
                });
            }
        });
    },

    update: (req, res) => {
        //Variaveis---------------------------------
        //Segunda-feira
        var horaInicioSegundaFeira = req.body.horaInicioSegundaFeira;
        var horaFimSegundaFeira = req.body.horaFimSegundaFeira;
        var ativoSegundaFeira = req.body.ativoSegundaFeira;

        //Terça-feira
        var horaInicioTercaFeira = req.body.horaInicioTercaFeira;
        var horaFimTercaFeira = req.body.horaFimTercaFeira;
        var ativoTercaFeira = req.body.ativoTercaFeira;

        //Quarta-feira
        var horaInicioQuartaFeira = req.body.horaInicioQuartaFeira;
        var horaFimQuartaFeira = req.body.horaFimQuartaFeira;
        var ativoQuartaFeira = req.body.ativoQuartaFeira;

        //Quinta-feira
        var horaInicioQuintaFeira = req.body.horaInicioQuintaFeira;
        var horaFimQuintaFeira = req.body.horaFimQuintaFeira;
        var ativoQuintaFeira = req.body.ativoQuintaFeira;

        //Sexta-feira
        var horaInicioSextaFeira = req.body.horaInicioSextaFeira;
        var horaFimSextaFeira = req.body.horaFimSextaFeira;
        var ativoSextaFeira = req.body.ativoSextaFeira;

        //Sábado
        var horaInicioSabado = req.body.horaInicioSabado;
        var horaFimSabado = req.body.horaFimSabado;
        var ativoSabado = req.body.ativoSabado;

        //Domingo
        var horaInicioDomingo = req.body.horaInicioDomingo;
        var horaFimDomingo = req.body.horaFimDomingo;
        var ativoDomingo = req.body.ativoDomingo;
        //Fim Variaveis-----------------------------

        //Montagem das querys de update
        if (ativoDomingo == 'true') {
            var queryDomingo = 'UPDATE dia_semana SET dia_semana_dia = 0 ' +
                ' ,dia_semana_hora_ini = ' + horaInicioDomingo +
                ' ,dia_semana_hora_fim = ' + horaFimDomingo +
                ' ,dia_semana_ativo = ' + ativoDomingo + ' WHERE dia_semana_id = 1';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioDomingo, horaFimDomingo, 1, true);

            //UPDATE DOMINGO
            queryExecutor(queryDomingo, 'domingo.');

        } else {
            var queryDomingo = 'UPDATE dia_semana SET dia_semana_dia = 0 ' +
                ' ,dia_semana_ativo = ' + ativoDomingo + ' WHERE dia_semana_id = 1';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioDomingo, horaFimDomingo, 1, false);

            //UPDATE ATIVADO DOMINGO
            queryExecutor(queryDomingo, 'domingo.');
        }

        if (ativoSegundaFeira == 'true') {
            var querySegundaFeira = 'UPDATE dia_semana SET dia_semana_dia = 1' +
                ' ,dia_semana_hora_ini = ' + horaInicioSegundaFeira +
                ' ,dia_semana_hora_fim = ' + horaFimSegundaFeira +
                ' ,dia_semana_ativo = ' + ativoSegundaFeira + ' WHERE dia_semana_id = 2';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioSegundaFeira, horaFimSegundaFeira, 2, true);

            //UPDATE SEGUNDA-FEIRA
            queryExecutor(querySegundaFeira, 'segunda-feira.');
        } else {
            var querySegundaFeira = 'UPDATE dia_semana SET dia_semana_dia = 1' +
                ' ,dia_semana_ativo = ' + ativoSegundaFeira + ' WHERE dia_semana_id = 2';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioSegundaFeira, horaFimSegundaFeira, 2, false);

            //UPDATE ATIVADO SEGUNDA-FEIRA
            queryExecutor(querySegundaFeira, 'segunda-feira.');
        }

        if (ativoTercaFeira == 'true') {
            var queryTercaFeira = 'UPDATE dia_semana SET dia_semana_dia = 2' +
                ' ,dia_semana_hora_ini = ' + horaInicioTercaFeira +
                ' ,dia_semana_hora_fim = ' + horaFimTercaFeira +
                ' ,dia_semana_ativo = ' + ativoTercaFeira + ' WHERE dia_semana_id = 3';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioTercaFeira, horaFimTercaFeira, 3, true);

            //UPDATE TERÇA-FEIRA
            queryExecutor(queryTercaFeira, 'terça-feira.');
        } else {
            var queryTercaFeira = 'UPDATE dia_semana SET dia_semana_dia = 2' +
                ' ,dia_semana_ativo = ' + ativoTercaFeira + ' WHERE dia_semana_id = 3';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioTercaFeira, horaFimTercaFeira, 3, false);

            //UPDATE ATIVADO TERÇA-FEIRA
            queryExecutor(queryTercaFeira, 'terça-feira.');
        }

        if (ativoQuartaFeira == 'true') {
            var queryQuartaFeira = 'UPDATE dia_semana SET dia_semana_dia = 3' +
                ' ,dia_semana_hora_ini = ' + horaInicioQuartaFeira +
                ' ,dia_semana_hora_fim = ' + horaFimQuartaFeira +
                ' ,dia_semana_ativo = ' + ativoQuartaFeira + ' WHERE dia_semana_id = 4';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioQuartaFeira, horaFimQuartaFeira, 4, true);

            //UPDATE QUARTA-FEIRA
            queryExecutor(queryQuartaFeira, 'quarta-feira.');
        } else {
            var queryQuartaFeira = 'UPDATE dia_semana SET dia_semana_dia = 3' +
                ' ,dia_semana_ativo = ' + ativoQuartaFeira + ' WHERE dia_semana_id = 4';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioQuartaFeira, horaFimQuartaFeira, 4, false);

            //UPDATE ATIVADO QUARTA-FEIRA
            queryExecutor(queryQuartaFeira, 'quarta-feira.');
        }

        if (ativoQuintaFeira == 'true') {
            var queryQuintaFeira = 'UPDATE dia_semana SET dia_semana_dia = 4' +
                ' ,dia_semana_hora_ini = ' + horaInicioQuintaFeira +
                ' ,dia_semana_hora_fim = ' + horaFimQuintaFeira +
                ' ,dia_semana_ativo = ' + ativoQuintaFeira + ' WHERE dia_semana_id = 5';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioQuintaFeira, horaFimQuintaFeira, 5, true);

            //UPDATE QUINTA-FEIRA
            queryExecutor(queryQuintaFeira, 'quinta-feira.');
        } else {
            var queryQuintaFeira = 'UPDATE dia_semana SET dia_semana_dia = 4' +
                ' ,dia_semana_ativo = ' + ativoQuintaFeira + ' WHERE dia_semana_id = 5';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioQuintaFeira, horaFimQuintaFeira, 5, false);

            //UPDATE ATIVADO QUINTA-FEIRA
            queryExecutor(queryQuintaFeira, 'quinta-feira.');
        }

        if (ativoSextaFeira == 'true') {
            var querySextaFeira = 'UPDATE dia_semana SET dia_semana_dia = 5' +
                ' ,dia_semana_hora_ini = ' + horaInicioSextaFeira +
                ' ,dia_semana_hora_fim = ' + horaFimSextaFeira +
                ' ,dia_semana_ativo = ' + ativoSextaFeira + ' WHERE dia_semana_id = 6';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioSextaFeira, horaFimSextaFeira, 6, true);

            //UPDATE SEXTA-FEIRA
            queryExecutor(querySextaFeira, 'sexta-feira.');
        } else {
            var querySextaFeira = 'UPDATE dia_semana SET dia_semana_dia = 5' +
                ' ,dia_semana_ativo = ' + ativoSextaFeira + ' WHERE dia_semana_id = 6';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioSextaFeira, horaFimSextaFeira, 6, false);

            //UPDATE ATIVADO SEXTA-FEIRA
            queryExecutor(querySextaFeira, 'sexta-feira.');
        }

        if (ativoSabado == 'true') {
            var querySabado = 'UPDATE dia_semana SET dia_semana_dia = 6' +
                ' ,dia_semana_hora_ini = ' + horaInicioSabado +
                ' ,dia_semana_hora_fim = ' + horaFimSabado +
                ' ,dia_semana_ativo = ' + ativoSabado + ' WHERE dia_semana_id = 7';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioSabado, horaFimSabado, 7, true);

            //UPDATE ATIVADO SABADO
            queryExecutor(querySabado, 'sábado');
        } else {
            var querySabado = 'UPDATE dia_semana SET dia_semana_dia = 6' +
                ' ,dia_semana_ativo = ' + ativoSabado + ' WHERE dia_semana_id = 7';

            //Retorno da situação de atualizacao dos dados
            analyzeReturn(horaInicioSabado, horaFimSabado, 7, false);

            //UPDATE ATIVADO SABADO
            queryExecutor(querySabado, 'sábado');
        }

        fs.readFile(__dirname + '/alteracaoDiasSemana.txt', (err, data) => {
            res.status(200).send({
                message: 'Configuração efetuada com sucesso!',
                houveAlteracao: parseInt(data)
            });
        });
    },

    restart: (req, res) => {
        try {
            execute('sudo dialer.sh start', (error, stdout) => { });

            setTimeout(() => {
                houveAlteracaoEstatico = 0;
                arquivoTxt(houveAlteracaoEstatico);
                res.status(200).send()
            }, 2500);
        } catch (error) {
            console.log(error);
            return res.status(500).send({
                error: 'Erro interno',
                message: 'Erro interno ao reiniciar o servidor.'
            });
        }
    }
}

function queryExecutor(query, dia) {
    try {
        pg.query(query, [], (err, ans) => {
            if (err) {
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao atualizar as informações de ' + dia
                });
            }
        });
    } catch (error) {
        console.log(error);
        return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno do servidor.'
        });
    }
}

function execute(command, callback) {
    exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};

function analyzeReturn(horaInicio, horaFim, dia, ativo) {
    //Buscar dados referente aos dias da semana
    var query = 'SELECT * FROM dia_semana WHERE dia_semana_id = ' + dia + ';';
    var alterado = 0;

    try {
        pg.query(query, [], (err, ans) => {
            if (err) {
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao buscar as informações de ' + dia
                });
            } else {
                switch (dia) {
                    case 1://Domingo
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoDomingo = 1;
                        } else {
                            houveAlteracaoDomingo = 0;
                        }
                        break;

                    case 2://Segunda-feira
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoSegunda = 1;
                        } else {
                            houveAlteracaoSegunda = 0;
                        }
                        break;

                    case 3://Terça-feira
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoTerca = 1;
                        } else {
                            houveAlteracaoTerca = 0;
                        }
                        break;

                    case 4://Quarta-feira
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoQuarta = 1;
                        } else {
                            houveAlteracaoQuarta = 0;
                        }
                        break;

                    case 5://Quinta-feira
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoQuinta = 1;
                        } else {
                            houveAlteracaoQuinta = 0;
                        }
                        break;

                    case 6://Sexta-feira
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoSexta = 1;
                        } else {
                            houveAlteracaoSexta = 0;
                        }
                        break;

                    case 7://Sabado
                        if (parseInt(ans.rows[0].dia_semana_hora_ini) != parseInt(horaInicio)
                            || parseInt(ans.rows[0].dia_semana_hora_fim) != parseInt(horaFim)
                            || ans.rows[0].dia_semana_ativo != ativo) {

                            houveAlteracaoSabado = 1;
                        } else {
                            houveAlteracaoSabado = 0;
                        }

                        break;
                }
                //Verificar se não houve nenhuma alteracao no front-end
                if (houveAlteracaoDomingo == 0 && //Não ocorreu alteracao nos dados de Domingo
                    houveAlteracaoSegunda == 0 && //Não ocorreu alteracao nos dados de Segunda
                    houveAlteracaoTerca == 0 && //Não ocorreu alteracao nos dados de Terca
                    houveAlteracaoQuarta == 0 && //Não ocorreu alteracao nos dados de Quarta
                    houveAlteracaoQuinta == 0 && //Não ocorreu alteracao nos dados de Quinta
                    houveAlteracaoSexta == 0 && //Não ocorreu alteracao nos dados de Sexta
                    houveAlteracaoSabado == 0) {  //Não ocorreu alteracao nos dados de Sabado

                    houveAlteracaoEstatico = 0; //Variavel de controle de alteracao
                    arquivoTxt(houveAlteracaoEstatico);
                } else {
                    houveAlteracaoEstatico = 1; //Ocorreu alteracao no front-end
                    arquivoTxt(houveAlteracaoEstatico);
                }
            }
        });
    } catch (error) {
        console.log(error);
        return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno do servidor.'
        });
    }
}

function arquivoTxt(houveAlteracao) {
    fs.open(__dirname + '/alteracaoDiasSemana.txt', 'wx', (err, fd) => {
        if (err) {
            if (err.code === 'EEXIST') {
                fs.unlink(__dirname + '/alteracaoDiasSemana.txt', function (err) {
                    if (err) throw err;
                    return;
                });
                fs.appendFile(__dirname + '/alteracaoDiasSemana.txt', houveAlteracao, (err) => {
                    if (err) throw err;
                });
            } else if (err.code === 'ENOENT') {
                fs.appendFile(__dirname + '/alteracaoDiasSemana.txt', houveAlteracao, (err) => {
                    if (err) throw err;
                    return;
                });
            }
        }
    });
}