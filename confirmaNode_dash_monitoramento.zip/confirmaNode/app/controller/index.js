const pg = require('../db');

var qtdCDR = null;
var totalConsultasConfirmar = null;
var totalConfirmadas = null;
var totalReagendadas = null;
var restantes = null;
var retornoJson = null;

module.exports = {
    select: (req, res) => {
        //Montagem do arquivo JSON para retornar ao cliente no front-end
        var retornoJsonZerado = {
            consultasAConfirmar: 0,
            restantes: 0,
            discagemRealizadas: 0,
            confirmadas: 0,
            reagendadas: 0,
            canceladas: 0
        }

        //verificar se a tabela CDR está vazia
        var query = 'SELECT COUNT(*) as contador FROM cdr;'
        pg.query(query, [], (err, ans) => {
            if (err) {
                return res.status(500).send({
                    message: 'Erro ao selecionar dados no servidor. Linha 17',
                    retornoJson: retornoJsonZerado
                });
            } else {
                //Variavel que recebe o valor retornado da consulta no BD
                //Discagens realizadas
                qtdCDR = ans.rows[0].contador;

                if (qtdCDR == 0) {
                    //Data fim
                    var date = new Date();
                    var dataExecQuery = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate());

                    return res.status(400).send({
                        message: 'Nenhum bilhete registrado!',
                        retornoJson: retornoJsonZerado
                    });
                } else {
                    //Verificar CONSULTAS A CONFIRMAR
                    //Data fim
                    var date = new Date();
                    var dataExecQuery = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate());

                    var query = 'SELECT COUNT(log_total_consultas) as total FROM log WHERE log_data_hora_exe_query BETWEEN ' + "'" + dataExecQuery + " 00:00:00' AND " + "'" + dataExecQuery + " 23:59:59';";
                    pg.query(query, [], (err, ans) => {
                        if (err) {
                            return res.status(500).send({
                                message: 'Erro ao selecionar dados no servidor. Linha 39',
                                retornoJson: retornoJsonZerado
                            });
                        } else {
                            //CONSULTAS A CONFIRMAR
                            var totalConsultas = ans.rows[0].total;

                            if (totalConsultas == 0) {
                                return res.status(400).send({
                                    message: 'Nenhum bilhete registrado!',
                                    retornoJson: retornoJsonZerado
                                });
                            } else {
                                //Consultas a confirmar
                                var query = 'SELECT log_total_consultas FROM log WHERE log_data_hora_exe_query BETWEEN ' + "'" + dataExecQuery + " 00:00:00' AND " + "'" + dataExecQuery + " 23:59:59';";
                                pg.query(query, [], (err, ans) => {
                                    if (err) {
                                        return res.status(500).send({
                                            message: 'Erro ao selecionar dados no servidor. Linha 55',
                                            retornoJson: retornoJsonZerado
                                        });
                                    } else {
                                        totalConsultasConfirmar = ans.rows[0].log_total_consultas;

                                        //Obtendo total de CONFIRMADAS
                                        var query = "SELECT COUNT(cdr_status_consulta) as confirmadas FROM cdr WHERE cdr_status_consulta = 'CONFIRMADA'"
                                        pg.query(query, [], (err, ans) => {
                                            if (err) {
                                                return res.status(500).send({
                                                    message: 'Erro ao selecionar dados no servidor. Linha 55',
                                                    retornoJson: retornoJsonZerado
                                                });
                                            } else {
                                                //CONFIRMADAS
                                                totalConfirmadas = ans.rows[0].confirmadas;

                                                //Obtendo total de REAGENDADAS
                                                var query = "SELECT COUNT(cdr_status_consulta) as reagendadas FROM cdr WHERE cdr_status_consulta = 'REAGENDADA'"
                                                pg.query(query, [], (err, ans) => {
                                                    if (err) {
                                                        return res.status(500).send({
                                                            message: 'Erro ao selecionar dados no servidor. Linha 66',
                                                            retornoJson: retornoJsonZerado
                                                        });
                                                    } else {
                                                        //REAGENDADAS
                                                        totalReagendadas = ans.rows[0].reagendadas;

                                                        //Obtendo total de CANCELADAS
                                                        var query = "SELECT COUNT(cdr_status_consulta) as canceladas FROM cdr WHERE cdr_status_consulta = 'CANCELADA'"
                                                        pg.query(query, [], (err, ans) => {
                                                            if (err) {
                                                                return res.status(500).send({
                                                                    message: 'Erro ao selecionar dados no servidor. Linha 77',
                                                                    retornoJson: retornoJsonZerado
                                                                });
                                                            } else {
                                                                //CANCELADAS
                                                                totalCanceladas = ans.rows[0].canceladas;

                                                                //CONSULTAS RESTANTES
                                                                restantes = parseInt(totalConsultasConfirmar) - parseInt(totalConfirmadas) - parseInt(totalCanceladas) - parseInt(totalReagendadas);

                                                                //Montar arquivo JSON separadamente para ter melhor organização dos dados
                                                                retornoJson = {
                                                                    consultasAConfirmar: totalConsultasConfirmar,
                                                                    restantes: restantes,
                                                                    discagemRealizadas: qtdCDR,
                                                                    confirmadas: totalConfirmadas,
                                                                    reagendadas: totalReagendadas,
                                                                    canceladas: totalCanceladas
                                                                }
                                                                //response para o cliente
                                                                res.status(200).send(retornoJson);
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
    },
    historico: (req, res) => {
        //Data inicio do histórico
        dataInicio = req.body.dataInicio;
        //Data fim do histórico
        dataFim = req.body.dataFim;

        //Data Inicio
        var dateInicio = new Date(dataInicio + " 00:00:00");//Convertendo data de inicio para o padrão yyyy-mm-dd
        var dataInicioHistorico = dateInicio.getFullYear() + "-" + ((dateInicio.getMonth() + 1) < 10 ? '0' + (dateInicio.getMonth() + 1) : ((dateInicio.getMonth() + 1))) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00:00";

        //Data Fim
        var dateFim = new Date(dataFim + " 23:59:59");//Convertendo data de inicio para o padrão yyyy-mm-dd
        var dataFimHistorico = dateFim.getFullYear() + "-" + ((dateFim.getMonth() + 1) < 10 ? '0' + (dateFim.getMonth() + 1) : ((dateFim.getMonth() + 1))) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " 23:59:59";

        //Convertendo em milissegundos
        var inicio = new Date(dataInicioHistorico).valueOf();
        var fim = new Date(dataFimHistorico).valueOf();

        //var query = 'select log_data_hora_exe_query::date from log where log_data_hora_exe_query BETWEEN '+"'"+dataInicioHistorico+"'"+' AND '+"'"+dataFimHistorico+"';"

        var pagination = req.body.pagination;

        if (pagination == null || pagination == 1) {
            pagination = 0;
        } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
        }

        if (inicio < fim) {
            var query = 'select count(log_data_hora_exe_query) from log where log_data_hora_exe_query BETWEEN ' + "'" + dataInicioHistorico + "'" + ' AND ' + "'" + dataFimHistorico + "';"
            pg.query(query, [], (err, ans) => {
                if (err) {
                    return res.status(500).send({
                        message: 'Erro ao selecionar dados no servidor. 1'
                    });
                } else {
                    var qtdDatasLog = ans.rows[0].count;
                    if (qtdDatasLog == 0) {
                        return res.status(500).send({
                            message: 'Nenhum dado encontrado para o período informado'
                        });
                    } else {

                        var query = 'select cdr_data_hora_chamada::date, cdr_status_consulta, count(cdr_status_consulta) as status_consulta from cdr where cdr_data_hora_chamada::date >= ' + "'" + dataInicioHistorico + "'" + ' and cdr_data_hora_chamada::date <= ' + "'" + dataFimHistorico + "'" + ' group by cdr_data_hora_chamada::date, cdr_status_consulta ORDER BY cdr_data_hora_chamada ASC LIMIT 10 OFFSET ' + pagination;
                        pg.query(query, [], (err, ans) => {
                            if (err) {
                                return res.status(500).send({
                                    message: 'Erro ao selecionar dados no servidor. 2'
                                });
                            } else {
                                var resultCdr = ans.rows;

                                var query = 'select log_data_hora_exe_query::date, log_total_consultas from log where log_data_hora_exe_query::date >= ' + "'" + dataInicioHistorico + "'" + ' and log_data_hora_exe_query::date <= ' + "'" + dataFimHistorico + "'" +
                                    ' ORDER BY log_data_hora_exe_query ASC LIMIT 10 OFFSET ' + pagination;
                                pg.query(query, [], (err, ans) => {
                                    if (err) {
                                        return res.status(500).send({
                                            message: 'Erro ao selecionar dados no servidor. 3'
                                        });
                                    } else {
                                        var resultLog = ans.rows;

                                        var query = 'select count(distinct cdr_status_consulta) as count_status_consulta,  cdr_data_hora_chamada::date from cdr where cdr_data_hora_chamada::date >= ' + "'" + dataInicioHistorico + "'" + ' and cdr_data_hora_chamada::date <= ' + "'" + dataFimHistorico + "'" +
                                            ' group by cdr_data_hora_chamada::date  ORDER BY cdr_data_hora_chamada ASC LIMIT 10 OFFSET ' + pagination;
                                        pg.query(query, [], (err, ans) => {
                                            if (err) {
                                                return res.status(500).send({
                                                    message: 'Erro ao selecionar dados no servidor. 3'
                                                });
                                            } else {
                                                var resultQtdCdrDia = ans.rows;

                                                var data = {
                                                    contador: qtdDatasLog,
                                                    resultCdr: resultCdr,
                                                    resultLog: resultLog,
                                                    resultQtdCdrDia: resultQtdCdrDia
                                                }
                                                res.status(200).send(data)
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                }
            });
        } else {
            return res.status(500).send({
                message: 'Data de início está maior que a de fim.'
            });
        }
    }
}