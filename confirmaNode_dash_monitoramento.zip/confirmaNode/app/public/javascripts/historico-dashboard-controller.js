var datasJson = {};

(function () {
    //Mostrar data no front-end para o usuário ter a opções de filtro.
    var date = new Date();
    $('#dataInicioHistorico').val((date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear());
    $('#dataFimHistorico').val((date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear());
})();

function validarDatas() {
    //Datas e horas referentes ao filtro
    var dataInicioHistorico = $('#dataInicioHistorico').val();
    var dataFimHistorico = $('#dataFimHistorico').val();

    if (dataInicioHistorico == '' && dataFimHistorico == '') {
        alertSwal('Nenhuma data está selecionada!');
        return;
    }

    if (dataInicioHistorico == '' && dataFimHistorico != '') {
        alertSwal('Informe a data de início!');
        return;
    }

    if (dataInicioHistorico != '' && dataFimHistorico == '') {
        alertSwal('Informe a data de fim!');
        return;
    }

    if (dataInicioHistorico != '' && dataFimHistorico != '') {

        //Converter de pt-br para en o formato da data para consulta no banco
        var dataInicioHistoricoo = null;
        if (!dataInicioHistorico.length == 0) {
            dataInicioHistoricoo =
                dataInicioHistorico[3] + dataInicioHistorico[4] + //mes
                "/" + dataInicioHistorico[0] + dataInicioHistorico[1] + // dia
                "/" + dataInicioHistorico[6] + dataInicioHistorico[7] + dataInicioHistorico[8] + dataInicioHistorico[9]; //ano
        } else {
            dataInicioHistoricoo = '';
        }

        var dataFimHistoricoo = null;
        if (!dataFimHistorico.length == 0) {
            dataFimHistoricoo =
                dataFimHistorico[3] + dataFimHistorico[4] + //mes
                "/" + dataFimHistorico[0] + dataFimHistorico[1] + // dia
                "/" + dataFimHistorico[6] + dataFimHistorico[7] + dataFimHistorico[8] + dataFimHistorico[9]; //ano
        } else {
            dataFimHistoricoo = '';
        }

        datasJson = { dataInicio: dataInicioHistoricoo, dataFim: dataFimHistoricoo };
        atualizarHistorico();
    }
}

function atualizarHistorico() {
    var xhttp = new XMLHttpRequest();
    var paginationAtual = $('#atual').val();

    var object = {
        pagination: paginationAtual,
        dataInicio: datasJson.dataInicio,
        dataFim: datasJson.dataFim
    }

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    addHistoricoNaTabela(JSON.parse(this.response).resultCdr, JSON.parse(this.response).resultLog, JSON.parse(this.response).resultQtdCdrDia);
                    valorMaximoPag(JSON.parse(this.response).contador);
                    break;

                case 304:
                    addHistoricoNaTabela(JSON.parse(this.response).resultCdr, JSON.parse(this.response).resultLog, JSON.parse(this.response).resultQtdCdrDia);
                    valorMaximoPag(JSON.parse(this.response).contador);
                    break;
                case 500:
                    $("#totalRegistros").val('0 registros.')
                    alertSwal(JSON.parse(this.response).message);
                    break;
                default:
                    //addHistoricoNaTabela();
                    alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }
    xhttp.open('POST', '/historico');
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(JSON.stringify(object));
}

function exportarCSV() {
    var xhttp = new XMLHttpRequest();
    var paginationAtual = $('#atual').val();

    var object = {
        pagination: paginationAtual,
        dataInicio: datasJson.dataInicio,
        dataFim: datasJson.dataFim
    }

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    montarExportarCSV(JSON.parse(this.response).resultCdr, JSON.parse(this.response).resultLog, JSON.parse(this.response).resultQtdCdrDia);
                    break;

                case 304:
                    montarExportarCSV(JSON.parse(this.response).resultCdr, JSON.parse(this.response).resultLog, JSON.parse(this.response).resultQtdCdrDia);
                    break;
                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;
                default:
                    //addHistoricoNaTabela();
                    alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }
    xhttp.open('POST', '/historico');
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(JSON.stringify(object));
}


function addHistoricoNaTabela(rowsCdr, rowsLog, rowsStatusDia) {
    //Pegar referencia da tabela de bilhetes
    const table = document.querySelector('#tabelaHistorico tbody');

    while (table.hasChildNodes()) {
        table.removeChild(table.firstChild);
    }

    //Incrementar em CDR, porque ele sempre será maior que log e é preciso obter todos os registros até o final
    var contCdr = 0;

    for (var i = 0; i < rowsLog.length; i++) {
        var newRow = table.insertRow(i);
        var totalRestantes = 0;
        var count = 0;

        //Data/Hora chamada
        var chamadaCell = newRow.insertCell(count);
        var date = new Date(rowsLog[i].log_data_hora_exe_query);
        var dataChamadaValue = document.createTextNode(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}`);
        var dataLog = (`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}`);
        chamadaCell.appendChild(dataChamadaValue);
        count++;

        //Total de consultas a confirmar
        var consultaConfirmar = newRow.insertCell(count);
        var consultaConfirmarValue = document.createTextNode(rowsLog[i].log_total_consultas);
        var totalConsultaConfirmar = rowsLog[i].log_total_consultas;
        consultaConfirmar.appendChild(consultaConfirmarValue);
        count++;

        //Obtendo data de cdr para comparar com log para executar a operação de soma
        var date = new Date(rowsStatusDia[i].cdr_data_hora_chamada)
        var dataCdr = (`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}`);

        //Quantidade de registros para o dia do cdr
        var statusCdrDia = parseInt(rowsStatusDia[i].count_status_consulta);

        if (dataCdr == dataLog) {
            var map1 = new Map();
            //Flag usada para controlar a inserção no mapa, para não sobrescrever os valores
            var flag = true;

            //Pega o que tem do dia do cdr mais o quanto percorreu anteriomente
            var incrementa = parseInt(statusCdrDia) + parseInt(contCdr);

            for (var j = contCdr; j < incrementa; j++) {
                //Cancelada
                if (rowsCdr[j].cdr_status_consulta == "CANCELADA") {
                    map1.set(0, rowsCdr[j].status_consulta);
                    flag = false;
                } else {
                    if (flag)
                        map1.set(0, 0);
                }

                //Confirmada
                if (rowsCdr[j].cdr_status_consulta == "CONFIRMADA") {
                    map1.set(1, rowsCdr[j].status_consulta);
                    flag = false;
                } else {
                    if (flag)
                        map1.set(1, 0);
                }

                //Reagendada
                if (rowsCdr[j].cdr_status_consulta == "REAGENDADA") {
                    map1.set(2, rowsCdr[j].status_consulta);
                    flag = false;
                } else {
                    if (flag)
                        map1.set(2, 0);
                }
                contCdr = j + 1
            }

            //Cancelada
            var cancelada = newRow.insertCell(count);
            var canceladaValue = document.createTextNode(String(map1.get(0)));
            cancelada.appendChild(canceladaValue);
            count++;

            //Confirmada
            var confirmada = newRow.insertCell(count);
            var confirmadaValue = document.createTextNode(String(map1.get(1)));
            confirmada.appendChild(confirmadaValue);
            count++;

            //Reagendada
            var reagendada = newRow.insertCell(count);
            var reagendadaValue = document.createTextNode(String(map1.get(2)));
            reagendada.appendChild(reagendadaValue);
            count++;

            //Consultas restantes
            totalRestantes = totalConsultaConfirmar - parseInt(map1.get(0)) - parseInt(map1.get(1)) - parseInt(map1.get(2));
            var restantes = newRow.insertCell(count);
            var restantesValue = document.createTextNode(totalRestantes);
            restantes.appendChild(restantesValue);
            count++;

        }
    }
}

function montarExportarCSV(rowsCdr, rowsLog, rowsStatusDia) {
    var csv = 'Data/Hora dashboard, Total consultas a confirmar, Canceladas, Confirmadas, Reagendada, Consultas restantes\n';

    //Incrementar em CDR, porque ele sempre será maior que log e é preciso obter todos os registros até o final
    var contCdr = 0;

    for (var i = 0; i < rowsLog.length; i++) {
        var totalRestantes = 0;

        //Data/Hora chamada
        var date = new Date(rowsLog[i].log_data_hora_exe_query);
        csv += (date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear();

        //Total de consultas a confirmar
        csv += ',' + rowsLog[i].log_total_consultas;

        //Obtendo data de cdr para comparar com log para executar a operação de soma
        var totalConsultaConfirmar = rowsLog[i].log_total_consultas;
        var date = new Date(rowsStatusDia[i].cdr_data_hora_chamada)
        var dataCdr = (`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}`);

        var date = new Date(rowsLog[i].log_data_hora_exe_query);
        var dataLog = (`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}`);

        //Quantidade de registros para o dia do cdr
        var statusCdrDia = parseInt(rowsStatusDia[i].count_status_consulta);

        if (dataCdr == dataLog) {
            var map1 = new Map();
            //Flag usada para controlar a inserção no mapa, para não sobrescrever os valores
            var flag = true;

            //Pega o que tem do dia do cdr mais o quanto percorreu anteriomente
            var incrementa = parseInt(statusCdrDia) + parseInt(contCdr);

            for (var j = contCdr; j < incrementa; j++) {
                //Cancelada
                if (rowsCdr[j].cdr_status_consulta == "CANCELADA") {
                    map1.set(0, rowsCdr[j].status_consulta);
                    flag = false;
                } else {
                    if (flag)
                        map1.set(0, 0);
                }

                //Confirmada
                if (rowsCdr[j].cdr_status_consulta == "CONFIRMADA") {
                    map1.set(1, rowsCdr[j].status_consulta);
                    flag = false;
                } else {
                    if (flag)
                        map1.set(1, 0);
                }

                //Reagendada
                if (rowsCdr[j].cdr_status_consulta == "REAGENDADA") {
                    map1.set(2, rowsCdr[j].status_consulta);
                    flag = false;
                } else {
                    if (flag)
                        map1.set(2, 0);
                }
                contCdr = j + 1
            }

            //Cancelada
            csv += ',' + String(map1.get(0));

            //Confirmada
            csv += ',' + String(map1.get(1));

            //Reagendada
            csv += ',' + String(map1.get(2));

            //Consultas restantes
            totalRestantes = totalConsultaConfirmar - parseInt(map1.get(0)) - parseInt(map1.get(1)) - parseInt(map1.get(2));
            csv += ',' + totalRestantes;
            csv += '\n';
        }
    }

    try {
        var date = new Date();
        var dateExport = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "_" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "_" + date.getFullYear() + "_" + ((date.getHours() < 10 ? '0' : '') + date.getHours()) + "_" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

        //Montar parametros para download do arquivo CSV
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_blank';
        hiddenElement.download = 'historico_' + dateExport + '.csv';
        hiddenElement.click();

    } catch (error) {
        //Mostrar o erro ao usuário
        console.log("Error: " + error);
        dangerSwal('Erro inesperado, contate o administrador');
    }
}

function gatilhoContMenos() {
    $('#contMais').attr('disabled', false);

    var paginationAtual = parseInt($('#atual').val());

    if (paginationAtual > 0) {
        var atual = paginationAtual - 1;
        $('#atual').val(atual);
    }

    if (paginationAtual == 1) {
        $('#atual').val(1);
        $('#contMenos').attr('disabled', true);
    }

    atualizarHistorico();
}

function gatilhoContMais() {
    $('#contMenos').attr('disabled', false);
    var valorMaximo = $('#valorMaximo').val();
    var paginationAtual = parseInt($('#atual').val());

    if (paginationAtual < valorMaximo) {
        var atual = paginationAtual + 1;
        $('#atual').val(atual);
    }

    if (paginationAtual == valorMaximo) {
        $('#contMais').attr('disabled', true);
        $('#atual').val(valorMaximo);
    }

    atualizarHistorico();
}

function gatilhoPaginacaoProximo() {
    $('#contMenos').attr('disabled', false);
    var valorMaximo = $('#valorMaximo').val();
    var paginationAtual = parseInt($('#atual').val());

    if (paginationAtual < valorMaximo) {
        var atual = paginationAtual + 1;
        $('#atual').val(atual);
    }

    if (paginationAtual == valorMaximo) {
        $('#atual').val(valorMaximo);
        $('#contMais').attr('disabled', true);
    }

    atualizarHistorico();
}

function valorMaximoPag(page) {
    var totalRegistros = $('#totalRegistros');
    totalRegistros.val(page + " registros.");

    page /= 10;
    if (page % 1 == 0) {
        page = page;
    } else {
        page = Math.ceil(page);
    }

    var valorMaximo = $('#valorMaximo');

    if (page == 0) {
        valorMaximo.val(1);
    } else {
        valorMaximo.val(page);
    }

    if ($('#atual').val() > page) {
        $('#atual').val(1);
        $('#contMenos').click();
    }
}

function alertSwal(message) {
    swal({
        title: "Ops :(",
        text: message,
        type: "error",
        showConfirmButton: true
    });
}

