function setAudioName(element) {
  var div = element.parentElement;
  var childs = div.childNodes;

  var label = undefined;
  var file = element.files[0];

  //Verifica se contem algum caracter especial no nome do audio.
  //Letras minusculas e maiusculas, ponto, underscore, e o numero 3 pode passar na validação
  if (file.name.match(/[^a-zA-Z._\S3]/g)) {
    alertSwal("Nome do áudio não é válido, talvez contenha caracteres especiais");
    return false;
  } else {
    //Verifica o tamanho do arquivo e vê se é maior que 3 MB
    if (element.files[0].size / 1024 / 1024 > 3) {
      alertSwal("Tamanho do arquivo de áudio não pode exceder 3 MB");
      return false;
    } else {
      //Caso o nome e o tamanho estejam OK
      for (var i = 0; i < childs.length; i++) {
        if (childs[i].nodeName === 'LABEL') {
          label = childs[i];
          break;
        }
      }

      if (element.files[0] === undefined) {
        return label.innerHTML = 'Não selecionado';
      }

      if (element.files[0].name.split('.')[0].length > 20) {
        alertSwal('Nome do arquivo de áudio não deve passar de 20 caracteres');
        label.innerHTML = 'Não selecionado';
        element.value = '';
        return;
      }

      try {
        (label && file && (file.type.includes('gsm') ||
          file.type.includes('wav') ||
          file.type.includes('mp3')))

        label.innerHTML = element.files[0].name;

      } catch (error) {
        console.log(error)

        alertSwal('Por favor, selecione apenas arquivos de áudios ' +
          'com o formato de gsm, mp3 ou wav.');
        label.innerHTML = 'Não selecionado';
        element.value = '';
      }
    }
  }
}

function validarAudios() {
  var audioInforma = $('#audioInforma');
  var audioConfirma = $('#audioConfirma');
  var audioTentativas = $('#audioTentativas');
  var audioAgradece = $('#audioAgradece');
  var audioNovamente = $('#audioNovamente');
  var audioInvalida = $('#audioInvalida');
  var audioConfirmada = $('#audioConfirmada');
  var audioAgradecePart = $('#audioAgradecePart');
  var audioCancelada = $('#audioCancelada');
  var audioReagendar = $('#audioReagendar');
  var audioAlo = $('#audioAlo');

  var formData = new FormData();

  if (audioInforma.get(0).files[0]) {
    formData.append('audios', audioInforma.get(0).files[0], audioInforma.get(0).files[0].name);
    formData.append(audioInforma.get(0).files[0].name, 'audio_informa');
  }

  if (audioConfirma.get(0).files[0]) {
    formData.append('audios', audioConfirma.get(0).files[0], audioConfirma.get(0).files[0].name);
    formData.append(audioConfirma.get(0).files[0].name, 'audio_confirma');
  }

  if (audioTentativas.get(0).files[0]) {
    formData.append('audios', audioTentativas.get(0).files[0], audioTentativas.get(0).files[0].name);
    formData.append(audioTentativas.get(0).files[0].name, 'audio_tentativas');
  }

  if (audioAgradece.get(0).files[0]) {
    formData.append('audios', audioAgradece.get(0).files[0], audioAgradece.get(0).files[0].name);
    formData.append(audioAgradece.get(0).files[0].name, 'audio_agradece');
  }

  if (audioNovamente.get(0).files[0]) {
    formData.append('audios', audioNovamente.get(0).files[0], audioNovamente.get(0).files[0].name);
    formData.append(audioNovamente.get(0).files[0].name, 'audio_novamente');
  }

  if (audioInvalida.get(0).files[0]) {
    formData.append('audios', audioInvalida.get(0).files[0], audioInvalida.get(0).files[0].name);
    formData.append(audioInvalida.get(0).files[0].name, 'audio_invalida');
  }

  if (audioConfirmada.get(0).files[0]) {
    formData.append('audios', audioConfirmada.get(0).files[0], audioConfirmada.get(0).files[0].name);
    formData.append(audioConfirmada.get(0).files[0].name, 'audio_confirmada');
  }

  if (audioAgradecePart.get(0).files[0]) {
    formData.append('audios', audioAgradecePart.get(0).files[0], audioAgradecePart.get(0).files[0].name);
    formData.append(audioAgradecePart.get(0).files[0].name, 'audio_agradece_part');
  }

  if (audioCancelada.get(0).files[0]) {
    formData.append('audios', audioCancelada.get(0).files[0], audioCancelada.get(0).files[0].name);
    formData.append(audioCancelada.get(0).files[0].name, 'audio_cancelada');
  }

  if (audioReagendar.get(0).files[0]) {
    formData.append('audios', audioReagendar.get(0).files[0], audioReagendar.get(0).files[0].name);
    formData.append(audioReagendar.get(0).files[0].name, 'audio_reagendar');
  }

  if (audioAlo.get(0).files[0]) {
    formData.append('audios', audioAlo.get(0).files[0], audioAlo.get(0).files[0].name);
    formData.append(audioAlo.get(0).files[0].name, 'audio_alo');
  }

  var xhttp = new XMLHttpRequest()

  xhttp.open('POST', '/audio/insert', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && (this.status == 200 || this.status == 304)) {
      if (JSON.parse(this.response).houveAlteracao == 0) {
        carregarAudios();
        setTimeout(() => {
          sucessSwal("Áudio(s) mantido(s).");
        }, 1500);

      } else {
        alertChangeInfo("Dados salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
      }
    } else if (this.readyState == 4 && (this.status != 200 || this.status != 304)) {
      carregarAudios();
      alertSwal(JSON.parse(this.response).message);
    }
  }

  xhttp.send(formData);
}

function carregarAudios() {
  var xhttp = new XMLHttpRequest();

  xhttp.open('GET', '/audio/select', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          if (JSON.parse(this.response).houveAlteracao == 0) {
            setLabelsName(JSON.parse(this.response).rows[0]);
          } else {
            setLabelsName(JSON.parse(this.response).rows[0]);
            alertChangeInfo("Os dados já estão salvos no banco de dados!\nMas é necessário aplicar as alterações para que o sistema funcione de maneira adequeada.\n\nDeseja aplicar as configurações agora?");
          }
          break;

        case 304:
          if (JSON.parse(this.response).houveAlteracao == 0) {
            setLabelsName(JSON.parse(this.response).rows[0]);
          } else {
            setLabelsName(JSON.parse(this.response).rows[0]);
            alertChangeInfo("Os dados já estão salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
          }
          break;

        case 401:
          alertSwal('Usuário ou senha inválidos');
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        case 404:
          alertSwal('Não foi possível alcançar o servidor');
          break;

        case 200:
          window.open("/", "_self");
          break;
        default:
          alertSwal('Erro inesperado, contate o administrador');
      }
    }
  }
  xhttp.send();
}

function setLabelsName(items) {
  var labels = document.getElementsByClassName('custom-file-label')
  labels[0].innerHTML = items.audio_informa;
  labels[1].innerHTML = items.audio_confirma;
  labels[2].innerHTML = items.audio_tentativas;
  labels[3].innerHTML = items.audio_agradece;
  labels[4].innerHTML = items.audio_novamente;
  labels[5].innerHTML = items.audio_invalida;
  labels[6].innerHTML = items.audio_confirmada;
  labels[7].innerHTML = items.audio_agradece_part;
  labels[8].innerHTML = items.audio_cancelada;
  labels[9].innerHTML = items.audio_reagendar;
  labels[10].innerHTML = items.audio_alo;
}

function alertSwal(message) {
  swal({
    title: "Ops :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}

function sucessSwal(message) {
  swal({
    title: "Sucesso :)",
    text: message,
    type: "success",
    timer: 4500
  },
    function () {
      swal.close();
    });
}

function alertChangeInfo(message) {
  swal({
    title: "Atenção!",
    text: message,
    type: "warning",
    showCancelButton: true,
    showLoaderOnConfirm: true,
    confirmButtonColor: "#DD6B55",
    confirmButtonText: "Sim",
    cancelButtonText: "Não",
    closeOnConfirm: true
  },
    function (isConfirm) {
      if (isConfirm) {
        executeRestartSystem();
      } else {
        // Store
        localStorage.setItem("houveAlteracao", "1");
      }
    });
}

function executeRestartSystem() {
  var xhttp = new XMLHttpRequest()

  xhttp.open('GET', '/audio/restart', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          carregarAudios();
          setTimeout(() => {
            sucessSwal("Configurações aplicadas!");
          }, 1500);
          break;

        case 304:
          carregarAudios();
          setTimeout(() => {
            sucessSwal("Configurações aplicadas!");
          }, 1500);
          break;

        case 401:
          alertSwal('Usuário ou senha inválidos');
          break;

        case 500:
          alertSwal('Erro interno com o servidor');
          break;

        case 404:
          alertSwal('Não foi possível alcançar o servidor');
          break;

        case 200:
          window.open("/", "_self");
          break;
        default:
          alertSwal('Erro inesperado, contate o administrador');
      }
    }
  }
  xhttp.send();
}