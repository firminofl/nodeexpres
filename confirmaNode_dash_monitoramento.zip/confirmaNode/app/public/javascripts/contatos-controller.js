function exportarCSV() {
  //*****************************Data de consulta*************************************/
  var inputDataInicioConsultaContatos = $('#dataInicioConsultaContatos').val();
  var inputDataFimDiscConsultaContatos = $('#dataFimConsultaContatos').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioConsultaContatoss = null;
  if (!inputDataInicioConsultaContatos.length == 0) {
    inputDataInicioConsultaContatoss =
      inputDataInicioConsultaContatos[3] + inputDataInicioConsultaContatos[4] + //mes
      "/" + inputDataInicioConsultaContatos[0] + inputDataInicioConsultaContatos[1] + // dia
      "/" + inputDataInicioConsultaContatos[6] + inputDataInicioConsultaContatos[7] + inputDataInicioConsultaContatos[8] + inputDataInicioConsultaContatos[9]; //ano
  } else {
    inputDataInicioConsultaContatoss = '';
  }

  var inputDataFimDiscConsultaContatoss = null;
  if (!inputDataFimDiscConsultaContatos.length == 0) {
    var inputDataFimDiscConsultaContatoss =
      inputDataFimDiscConsultaContatos[3] + inputDataFimDiscConsultaContatos[4] + //mes
      "/" + inputDataFimDiscConsultaContatos[0] + inputDataFimDiscConsultaContatos[1] + // dia
      "/" + inputDataFimDiscConsultaContatos[6] + inputDataFimDiscConsultaContatos[7] + inputDataFimDiscConsultaContatos[8] + inputDataFimDiscConsultaContatos[9]; //ano
  } else {
    inputDataFimDiscConsultaContatoss = '';
  }
  //****************************Fim data de consulta**********************************/

  var inputHoraInicioConsultaContatos = $('#horaInicioConsultaContatos').val();
  var inputHoraFimConsultaContatos = $('#horaFimConsultaContatos').val();

  //paciente
  var inputNomePacienteContatos = $('#nomePacienteContatos').val();
  var inputTel1PacienteContatos = $('#tel1PacienteContatos').val();
  var inputTel2PacienteContatos = $('#tel2PacienteContatos').val();

  //medico
  var inputNomeMedicoContatos = $('#nomeMedicoContatos').val();

  //status
  var inputStatusChamadaContatos = $('#statusChamadaContatos').val();
  var inputStatusConsultaContatos = $('#statusConsultaContatos').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoContatos = $('#tipoAtendimentoContatos').val();
  var inputTelDiscadoContatos = $('#telDiscadoContatos').val();

  //Id consulta
  var inputIdConsultaContatos = $('#idConsultaContatos').val();

  //Validar datas para não sobrecarregar o servidor
  validarDatas();

  //criando um objeto para passar como referencia na rota
  var object = {
    dataInicioConsultaContatos: inputDataInicioConsultaContatoss,
    dataFimConsultaContatos: inputDataFimDiscConsultaContatoss,

    horaInicioConsultaContatos: inputHoraInicioConsultaContatos,
    horaFimConsultaContatos: inputHoraFimConsultaContatos,

    nomePacienteContatos: inputNomePacienteContatos,
    tel1PacienteContatos: inputTel1PacienteContatos,
    tel2PacienteContatos: inputTel2PacienteContatos,

    nomeMedicoContatos: inputNomeMedicoContatos,

    statusChamadaContatos: inputStatusChamadaContatos,
    statusConsultaContatos: inputStatusConsultaContatos,

    tipoAtendimentoContatos: inputTipoAtendimentoContatos,
    telDiscadoContatos: inputTelDiscadoContatos,

    idConsultaContatos: inputIdConsultaContatos,

    exportarCSVTrueFalse: true
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          infoSwal()
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 304:
          infoSwal()
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        default:
          alertSwal('Erro inesperado, contate o administrador.');
          break;
      }
    }
  }
  xhttp.open('POST', '/contato/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function montarExportarTabelaCSV(rows) {
  var csv = 'Data/Hora Consulta,Status Consulta,Paciente,Telefone 1,Telefone 2,' +
    'Status Chamada,Tel discado,Id consulta\n';

  for (var i = 0; i < rows.length; i++) {
    var date = new Date(rows[i].contato_consulta_data_hora);
    csv += (date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : ((date.getMonth() + 1))) + "/" + date.getFullYear() + " " + (date.getHours() < 10 ? '0' : '') + date.getHours() + ":" + (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();

    csv += ',' + rows[i].cdr_status_consulta;
    csv += ',' + rows[i].contato_paciente_nome;
    csv += ',' + rows[i].contato_paciente_tel1;
    csv += ',' + rows[i].contato_paciente_tel2;
    csv += ',' + rows[i].cdr_status_chamada;
    csv += ',' + rows[i].cdr_tel_discado;
    csv += ',' + rows[i].contato_consulta_id;
    csv += '\n';
  }

  try {
    var date = new Date();
    var dateExport = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "_" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "_" + date.getFullYear() + "_" + ((date.getHours() < 10 ? '0' : '') + date.getHours()) + "_" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

    //Montar parametros para download do arquivo CSV
    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'contatos' + dateExport + '.csv';
    hiddenElement.click();

  } catch (error) {
    //Mostrar o erro ao usuário
    console.log("Error: " + error);
    alertSwal('Erro inesperado, contate o administrador');
  }
}

function alertSwal(message) {
  swal({
    title: "Ops :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}

function infoSwal() {
  swal({
    title: "Exportar CSV",
    text: "Este processo pode demorar um tempo!",
    timer: 4000,
    showConfirmButton: true
  });
}

function gatilhoContMenos() {
  $('#contMaisContatos').attr('disabled', false);
  var valorMaximo = $('#valorMaximoContatos').val();

  var paginationAtual = parseInt($('#atualContatos').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atualContatos').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atualContatos').val(1);
    $('#contMenosContatos').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaContatos();
  } else if (selectORsearch == 2) {
    buscarContatos();
  }
}

function gatilhoContMais() {
  $('#contMenosContatos').attr('disabled', false);
  var valorMaximo = $('#valorMaximoContatos').val();
  var paginationAtual = parseInt($('#atualContatos').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atualContatos').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMaisContatos').attr('disabled', true);
    $('#atualContatos').val(valorMaximo);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaContatos();
  } else if (selectORsearch == 2) {
    buscarContatos();
  }
}

function gatilhoPaginacaoProximo() {
  $('#contMenosContatos').attr('disabled', false);
  var valorMaximo = $('#valorMaximoContatos').val();
  var paginationAtual = parseInt($('#atualContatos').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atualContatos').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atualContatos').val(valorMaximo);
    $('#contMaisContatos').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaContatos();
  } else if (selectORsearch == 2) {
    buscarContatos();
  }
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximoContatos');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atualContatos').val() > page) {
    $('#atualContatos').val(1);
    $('#contMenosContatos').click();
  }
}

function atualizaContatos() {
  var xhttp = new XMLHttpRequest();

  var paginationAtual = $('#atualContatos').val();

  var object = {
    pagination: paginationAtual
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          valorMaximoPag(JSON.parse(this.response).contador.resultado);
          addContatosNaTabela(JSON.parse(this.response).result);
          break;
        case 304:
          valorMaximoPag(JSON.parse(this.response).contador.resultado);
          addContatosNaTabela(JSON.parse(this.response).result);
          break;
        case 500:
          console.log("Erro interno com o servidor.");
          break;
        default:
          console.log("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }

  xhttp.open('POST', '/contato/select')
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addContatosNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaContatos tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //Data/Hora Consulta
    var consultaCell = newRow.insertCell(count);
    var date = new Date(rows[i].contato_consulta_data_hora)
    var consultaValue = document.createTextNode(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${(date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : ((date.getMonth() + 1))}/${date.getFullYear()}` + ` ${(date.getHours() < 10 ? '0' : '') + date.getHours()}:${(date.getMinutes() < 10 ? '0' : '') + date.getMinutes()}`);
    consultaCell.appendChild(consultaValue);
    count++;

    //Status consulta
    var statusConsultaCell = newRow.insertCell(count);
    var statusConsultaValue = document.createTextNode(rows[i].cdr_status_consulta);
    statusConsultaCell.appendChild(statusConsultaValue);
    count++;

    //Paciente
    var pacienteCell = newRow.insertCell(count);
    var pacienteValue = document.createTextNode(rows[i].contato_paciente_nome);
    pacienteCell.appendChild(pacienteValue);
    count++;

    //Telefone 1
    var tel1Cell = newRow.insertCell(count);
    var tel1Value = document.createTextNode(rows[i].contato_paciente_tel1);
    tel1Cell.appendChild(tel1Value);
    count++;

    //Telefone 2
    var tel2Cell = newRow.insertCell(count);
    var tel2Value = document.createTextNode(rows[i].contato_paciente_tel2);
    tel2Cell.appendChild(tel2Value);
    count++;

    //Status chamada
    var statusClienteCell = newRow.insertCell(count);
    var statusClienteValue = document.createTextNode(rows[i].cdr_status_chamada);
    statusClienteCell.appendChild(statusClienteValue);
    count++;

    //Telefone discado
    var telDiscadoCell = newRow.insertCell(count);
    var telDiscadoValue = document.createTextNode(rows[i].cdr_tel_discado);
    telDiscadoCell.appendChild(telDiscadoValue);
    count++;

    //Id consulta
    var idConsultaCell = newRow.insertCell(count);
    var idConsultaValue = document.createTextNode(rows[i].contato_consulta_id);
    idConsultaCell.appendChild(idConsultaValue);
    count++;
  }
}

function buscarContatos() {
  $('#selectORsearch').val('2');

  //*****************************Data de consulta*************************************/
  var inputDataInicioConsultaContatos = $('#dataInicioConsultaContatos').val();
  var inputDataFimDiscConsultaContatos = $('#dataFimConsultaContatos').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioConsultaContatoss = null;
  if (!inputDataInicioConsultaContatos.length == 0) {
    inputDataInicioConsultaContatoss =
      inputDataInicioConsultaContatos[3] + inputDataInicioConsultaContatos[4] + //mes
      "/" + inputDataInicioConsultaContatos[0] + inputDataInicioConsultaContatos[1] + // dia
      "/" + inputDataInicioConsultaContatos[6] + inputDataInicioConsultaContatos[7] + inputDataInicioConsultaContatos[8] + inputDataInicioConsultaContatos[9]; //ano
  } else {
    inputDataInicioConsultaContatoss = '';
  }

  var inputDataFimDiscConsultaContatoss = null;
  if (!inputDataFimDiscConsultaContatos.length == 0) {
    var inputDataFimDiscConsultaContatoss =
      inputDataFimDiscConsultaContatos[3] + inputDataFimDiscConsultaContatos[4] + //mes
      "/" + inputDataFimDiscConsultaContatos[0] + inputDataFimDiscConsultaContatos[1] + // dia
      "/" + inputDataFimDiscConsultaContatos[6] + inputDataFimDiscConsultaContatos[7] + inputDataFimDiscConsultaContatos[8] + inputDataFimDiscConsultaContatos[9]; //ano
  } else {
    inputDataFimDiscConsultaContatoss = '';
  }
  //****************************Fim data de consulta**********************************/

  var inputHoraInicioConsultaContatos = $('#horaInicioConsultaContatos').val();
  var inputHoraFimConsultaContatos = $('#horaFimConsultaContatos').val();

  //paciente
  var inputNomePacienteContatos = $('#nomePacienteContatos').val();
  var inputTel1PacienteContatos = $('#tel1PacienteContatos').val();
  var inputTel2PacienteContatos = $('#tel2PacienteContatos').val();

  //medico
  var inputNomeMedicoContatos = $('#nomeMedicoContatos').val();

  //status
  var inputStatusChamadaContatos = $('#statusChamadaContatos').val();
  var inputStatusConsultaContatos = $('#statusConsultaContatos').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoContatos = $('#tipoAtendimentoContatos').val();
  var inputTelDiscadoContatos = $('#telDiscadoContatos').val();

  //Id consulta
  var inputIdConsultaContatos = $('#idConsultaContatos').val();

  var red_alert_modal = document.getElementById('red-alert_modal');
  red_alert_modal.style.visibility = 'none';

  //Paginação atual da página
  var paginationAtual = $('#atualContatos').val();

  //Não desperdiçar processamento do servidor, validando os campos
  if (inputDataInicioConsultaContatos.length == 0 &&
    inputDataFimDiscConsultaContatos.length == 0 &&

    inputHoraInicioConsultaContatos.length == 0 &&
    inputHoraFimConsultaContatos.length == 0 &&

    inputNomePacienteContatos.length == 0 &&
    inputTel1PacienteContatos.length == 0 &&
    inputTel2PacienteContatos.length == 0 &&

    inputNomeMedicoContatos.length == 0 &&

    inputStatusChamadaContatos.length == 0 &&

    inputTelDiscadoContatos.length == 0 &&

    inputIdConsultaContatos.length == 0) {
    return alertSwal('Nenhum filtro aplicado.')

  } else {
    //Validar datas para não sobrecarregar o servidor
    validarDatas();

    //criando um objeto para passar como referencia na rota
    var object = {
      dataInicioConsultaContatos: inputDataInicioConsultaContatoss,
      dataFimConsultaContatos: inputDataFimDiscConsultaContatoss,

      horaInicioConsultaContatos: inputHoraInicioConsultaContatos,
      horaFimConsultaContatos: inputHoraFimConsultaContatos,

      nomePacienteContatos: inputNomePacienteContatos,
      tel1PacienteContatos: inputTel1PacienteContatos,
      tel2PacienteContatos: inputTel2PacienteContatos,

      nomeMedicoContatos: inputNomeMedicoContatos,

      statusChamadaContatos: inputStatusChamadaContatos,
      statusConsultaContatos: inputStatusConsultaContatos,

      tipoAtendimentoContatos: inputTipoAtendimentoContatos,
      telDiscadoContatos: inputTelDiscadoContatos,

      idConsultaContatos: inputIdConsultaContatos,

      exportarCSVTrueFalse: false,

      pagination: paginationAtual
    }

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            if (JSON.parse(this.response).contador == 0) {
              $("#totalRegistros").val('0 registros.')
            } else {
              valorMaximoPag(JSON.parse(this.response).contador);
              addContatosNaTabela(JSON.parse(this.response).result);
            }
            break;

          case 304:
            if (JSON.parse(this.response).contador == 0) {
              $("#totalRegistros").val('0 registros.')
            } else {
              valorMaximoPag(JSON.parse(this.response).contador);
              addContatosNaTabela(JSON.parse(this.response).result);
            }
            break;

          case 500:
            $("#totalRegistros").val('0 registros.')
            alertSwal(JSON.parse(this.response).message);
            break;

          default:
            alertSwal('Erro inesperado, contate o administrador.');
            break;
        }
      }
    }
    xhttp.open('POST', '/contato/search', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
  }
}

function limparCampos() {
  //Datas e horas referentes ao filtro
  $('#dataInicioConsultaContatos').val('');
  $('#dataFimConsultaContatos').val('');

  $('#horaInicioConsultaContatos').val('');
  $('#horaFimConsultaContatos').val('');

  //paciente
  $('#nomePacienteContatos').val('');
  $('#tel1PacienteContatos').val('');
  $('#tel2PacienteContatos').val('');

  //medico
  $('#nomeMedicoContatos').val('');

  //status
  $('#statusChamadaContatos').val('');
  $('#statusConsultaContatos').val('');

  //tipo de atendimento e telefone discado
  $('#tipoAtendimentoContatos').val('');
  $('#telDiscadoContatos').val('');

  //Id consulta
  $('#idConsultaContatos').val('');

  //Valor de paginacao
  $('#valorMaximoContatos').val(1);

  atualizaContatos();
}

function validarDatas() {
  //************************************* CONSULTA ***********************************/
  //Datas e horas referentes ao filtro
  var dataInicioConsultaContatos = $('#dataInicioConsultaContatos').val();
  var dataFimConsultaContatos = $('#dataFimConsultaContatos').val();

  var horaInicioConsultaContatos = $('#horaInicioConsultaContatos').val();
  var horaFimConsultaContatos = $('#horaFimConsultaContatos').val();

  //VVVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaContatos == '' && horaFimConsultaContatos != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaContatos == '' && dataFimConsultaContatos == '') {
      alertSwal('É necessário informar ao menos a data de início e hora início!');
      return;
    }
  }

  //VVPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaContatos != '' && horaFimConsultaContatos == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaContatos == '' && dataFimConsultaContatos == '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VVPP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaContatos != '' && horaFimConsultaContatos != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaContatos == '' && dataFimConsultaContatos == '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaContatos == '' && horaFimConsultaContatos == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaContatos == '' && dataFimConsultaContatos != '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaContatos != '' && horaFimConsultaContatos == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaContatos == '' && dataFimConsultaContatos != '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaContatos == '' && horaFimConsultaContatos != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaContatos == '' && dataFimConsultaContatos != '') {
      alertSwal('É necessário informar ao menos a data de início e hora!');
      return;
    }
  }
  //************************************* FIM CONSULTA *******************************/
}