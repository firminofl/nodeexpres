function validarCredencial() {

  var username = document.getElementById('inputUsernameCadastro').value;
  var password = document.getElementById('inputPasswordCadastro').value;

  if (username == '' || password == '') {
      return;
  }

  var object = new Object();
  object.username = username;
  object.password = password;

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
          switch (this.status) {
              case 200:
                  atualizaUsuarios();
                  sucessSwal(JSON.parse(this.response).message)
                  break;

              case 304:
                  atualizaUsuarios();
                  sucessSwal(JSON.parse(this.response).message)
                  break;

              case 401:
                  alertSwal('Usuário já existente no sistema.');

                  break;

              case 500:
                  alertSwal('Erro interno com o servidor.');
                  break;

              case 404:
                  alertSwal('Não foi possível alcançar o servidor.');
                  break;

              default:
                  alertSwal('Erro inesperado, contate o administrador.');
                  break;
          }
      }
  }
  xhttp.open("POST", '/users/insercao', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function atualizaUsuarios() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/users/select')

  xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
          switch (this.status) {
              case 200:
                  addElementsToTable(JSON.parse(this.response))
                  break;
              case 304:
                  addElementsToTable(JSON.parse(this.response))
                  break;
              case 500:
                  console.log("Erro interno com o servidor.");
                  break;
              default:
                  console.log("Erro inesperado, contate o administrador.");
                  break;
          }
      }
  }

  xhttp.send()
}

function addElementsToTable(rows) {
  //Pegar referencia da tabela de usuários
  const table = document.querySelector('#tabelaUsuarios tbody');

  while (table.hasChildNodes()) {
      table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
      var newRow = table.insertRow(i)
      var count = 0

      var actionCell = newRow.insertCell(count)

      var usuarioCell = newRow.insertCell(count)
      var usuarioValue = document.createTextNode(rows[i].usuario_login)
      usuarioCell.appendChild(usuarioValue)
      count++;

      if (usuarioCell.innerHTML == 'admin') {
          // botao editar
          var editarCell = newRow.insertCell(count)
          var editarElement = document.createElement('input')
          editarElement.setAttribute('type', 'button')
          editarElement.setAttribute('value', 'Editar')
          editarElement.setAttribute('data-toggle', "modal")
          editarElement.setAttribute('data-target', "#myModal2")
          editarElement.classList.add('btn')
          editarElement.classList.add('btn-outline')
          editarElement.classList.add('btn-warning')
          editarElement.onclick = editItem(rows[i])
          editarCell.appendChild(editarElement)
          count++;
      } else {

          // botao editar
          var editarCell = newRow.insertCell(count)
          var editarElement = document.createElement('input')
          editarElement.setAttribute('type', 'button')
          editarElement.setAttribute('value', 'Editar')
          editarElement.setAttribute('data-toggle', "modal")
          editarElement.setAttribute('data-target', "#myModal2")
          editarElement.classList.add('btn')
          editarElement.classList.add('btn-outline')
          editarElement.classList.add('btn-warning')
          editarElement.onclick = editItem(rows[i])
          editarCell.appendChild(editarElement)
          count++;

          // botao excluir
          var excluirCell = newRow.insertCell(count)
          var excluirElement = document.createElement('input')
          excluirElement.setAttribute('type', 'button')
          excluirElement.setAttribute('value', 'Excluir')
          excluirElement.classList.add('btn')
          excluirElement.classList.add('btn-outline')
          excluirElement.classList.add('btn-danger')
          excluirElement.classList.add('dim')
          excluirElement.onclick = deleteItem(rows[i])
          excluirCell.appendChild(excluirElement)
          count++;
      }
  }
}
var itemEditar;

function editItem(item) {
  return function () {
      itemEditar = item;
      document.getElementById('inputUsernameEditar').value = item.usuario_login
  }
}

function deleteItem(item) {
  return function () {

      var xhttp = new XMLHttpRequest();
      xhttp.open('POST', '/users/delete')

      var object = new Object()
      object.id = item.usuario_id

      xhttp.onreadystatechange = function () {
          if (this.readyState == 4) {
              switch (this.status) {
                  case 200:
                      atualizaUsuarios();
                      sucessSwal(JSON.parse(this.response).message)
                      break;

                  case 304:
                      atualizaUsuarios();
                      sucessSwal(JSON.parse(this.response).message)
                      break;
              }
          }
      }
      xhttp.setRequestHeader('Content-Type', 'application/json')
      xhttp.send(JSON.stringify(object));
  }
}

function alert(message) {
  if (!message.localeCompare('Impossível excluir o usuário com a sessão aberta!')) {
      alertSwal(message + ' Contate o administrador.');

  } else {
      sucessSwal(message)
  }
}

function sucessSwal(message) {
  swal({
      title: "Sucesso :)",
      text: message,
      type: "success",
      timer: 4500
  },
      function () {
          swal.close();
      });
}

function alertSwal(message) {
  swal({
      title: "Ops :-(",
      text: message,
      type: "error",
      showConfirmButton: true
  });
}

function sucessSwalOk() {
  swal({
      title: "Salvo",
      type: "success",
      timer: 1200,
      showConfirmButton: false
  },
      function () {
          swal.close();
          location.reload();
      });
}

function validarCredencialEdicao() {

  var password = document.getElementById('inputPasswordEditar').value;

  if (password == '') {
      alertSwal('Campo senha vazio.');
      return;
  }

  var xhttp = new XMLHttpRequest();

  var object = new Object()
  object.id = itemEditar.usuario_id
  object.password = password

  xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
          switch (this.status) {
              case 200:
                  atualizaUsuarios();
                  sucessSwalOk();
                  password.innerHTML = ''
                  $('#myModal2').modal('hide');
                  break;

              case 304:
                  atualizaUsuarios();
                  sucessSwalOk();
                  password.innerHTML = ''
                  $('#myModal2').modal('hide');
                  break;

              case 500:
                  password.innerHTML = ''
                  alertSwal('Erro interno com o servidor.');
                  break;

              case 404:
                  password.innerHTML = ''
                  alertSwal('Não foi possível alcançar o servidor.');
                  break;

              default:
                  password.innerHTML = ''
                  alertSwal('Erro inesperado, contate o administrador.');
                  break;
          }
      }
  }
  xhttp.open('POST', '/users/update');
  xhttp.setRequestHeader('Content-Type', 'application/json');
  xhttp.send(JSON.stringify(object));
}
