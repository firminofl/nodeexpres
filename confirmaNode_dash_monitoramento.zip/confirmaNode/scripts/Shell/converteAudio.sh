#!/bin/bash
#|+----------------------------------------------------------------------------------------------------------------------------------------------+
#| Autor: Evaldo de Oliveira                                                                                                                     |
#| Data : 21/03/19                                                                                                                               |
#|-----------------------------------------------------------------------------------------------------------------------------------------------|
#| Script responsável por:                                                                                                                       |
#| - Converter os arquivos de áudios .wav e .mp3 em sln                                                                                          |
#| - Forma de teste: executar o comando convertAudio.sh                                                                                          |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+
#| Histórico:                                                                                                                                    |
#| Versão: v1.0                                                                                                                                  |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+

cd /opt/leucotron/confirmaNode/sounds/

for input in *
do
	if [ "${input##*.}" = wav ]
	then
		ffmpeg -i ${input} -ar 8000 -ac 1 -acodec pcm_s16le -f s16le ${input%%.*}.sln
	elif [ "${input##*.}" = mp3 ]
	then
		ffmpeg -i ${input} -ar 8000 -ac 1 -acodec pcm_s16le -f s16le ${input%%.*}.sln
	elif [ "${input##*.}" = gsm ]
	then
		echo "Conversao para gsm ainda nao implementado!"
	else
		exit 0
	fi
done
rm -rf /var/lib/asterisk/sounds/pt_BR/custom/*
mv *.sln /var/lib/asterisk/sounds/pt_BR/custom/
