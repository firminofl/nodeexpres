#!/bin/bash
#Header
export PGPASSWORD="sml3uc0"
DBUSER="postgres"
DBNAME="confirma_aux"
DBTABLECONTATO="contato"
HOST="192.168.9.226"

echo "SELECT * FROM ${DBTABLECONTATO};" | psql -t -d ${DBNAME} -h ${HOST} -U ${DBUSER} | while read NUMBER
do
	echo "${NUMBER}"
done
