#!/bin/bash
#+---------------------------------------------------------------------------------------------------------------+
#|Descrição: Mover todos os arquivos, pastas para os diretorios de projeto     |
#+---------------------------------------------------------------------------------------------------------------+
#|Autor: Filipe Firmino                                                                                          |
#|Data: 18/04/2019                                                                                               |
#+---------------------------------------------------------------------------------------------------------------+

#Remover pasta confirmaNode do diretorio /opt/leucotron/
rm -rf /opt/leucotron/confirmaNode/

#Copia a pasta confirmaNode que foi enviada para o servidor
cp -r /home/leucotron/confirmaNode/ /opt/leucotron/

#Faz um backup local do arquivo sip.conf na pasta do asterisk para uma possível consulta futura
cp /etc/asterisk/sip.conf /etc/asterisk/sip_original.conf
cp /opt/leucotron/confirmaNode/scripts/Asterisk/sip.conf /etc/asterisk/

#Faz um backup local do arquivo extensions.conf na pasta do asterisk para uma possível consulta futura
cp /etc/asterisk/extensions.conf /etc/asterisk/extensions_original.conf
cp /opt/leucotron/confirmaNode/scripts/Asterisk/extensions.conf /etc/asterisk/

#Mover o dialer sem o SH para /etc/init.d/
cp /opt/leucotron/confirmaNode/scripts/Shell/dialer /etc/init.d/

#Mover insert,numDiscar, call, converteData e updateContato, update_bd_remoto para /opt/leucotron/confirmaNode/Scripts
cp /opt/leucotron/confirmaNode/scripts/Shell/call.sh /opt/leucotron/confirmaNode/scripts/
cp /opt/leucotron/confirmaNode/scripts/Shell/converteData.sh /opt/leucotron/confirmaNode/scripts/
cp /opt/leucotron/confirmaNode/scripts/Shell/insert.sh /opt/leucotron/confirmaNode/scripts/
cp /opt/leucotron/confirmaNode/scripts/Shell/numDiscar.sh /opt/leucotron/confirmaNode/scripts/
cp /opt/leucotron/confirmaNode/scripts/Shell/update_bd_remoto.sh /opt/leucotron/confirmaNode/scripts/
cp /opt/leucotron/confirmaNode/scripts/Shell/updateContato.sh /opt/leucotron/confirmaNode/scripts/

#Dando permissao de execução aos scripts
chmod +x /opt/leucotron/confirmaNode/scripts/call.sh
chmod +x /opt/leucotron/confirmaNode/scripts/converteData.sh
chmod +x /opt/leucotron/confirmaNode/scripts/insert.sh
chmod +x /opt/leucotron/confirmaNode/scripts/numDiscar.sh
chmod +x /opt/leucotron/confirmaNode/scripts/update_bd_remoto.sh
chmod +x /opt/leucotron/confirmaNode/scripts/updateContato.sh

#Mover conveteAudio, Dialer.sh, select_bd_remoto para /usr/bin/
cp /opt/leucotron/confirmaNode/scripts/Shell/conveteAudio.sh /usr/bin/
cp /opt/leucotron/confirmaNode/scripts/Shell/dialer.sh /usr/bin/
cp /opt/leucotron/confirmaNode/scripts/Shell/select_bd_remoto.sh /usr/bin/

#Dando permissao de execução aos scripts
chmod +x /usr/bin/conveteAudio.sh
chmod +x /usr/bin/dialer.sh
chmod +x /usr/bin/select_bd_remoto.sh

#Criando diretorios usados durante a execucao da aplicacao
mkdir /opt/leucotron/confirmaNode/call
mkdir /opt/leucotron/confirmaNode/log
mkdir /opt/leucotron/confirmaNode/sounds

#Remover pasta confirmaNode do diretorio
#rm -rf /opt/leucotron/Teste/

#Copia a pasta que foi enviada para o servidor
#cp -r /home/filipe/Documentos/Teste /opt/leucotron/

#Descobrir permissoes do arquivo
#ls -lh /opt/leucotron/Teste/fafa/login.js

#Alterando a permissao do arquivo para o modo de execucao
#chmod +x /opt/leucotron/Teste/fafa/login.js

#ls -lh /opt/leucotron/Teste/fafa/login.js
