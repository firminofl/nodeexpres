var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate')

router.get('/', authenticate.auth, function(req, res) {
  res.render('index');
});

router.get('/login', function(req, res) {
  if (req.session.userid) {
    res.redirect('index')
  } else {
    res.render('login');
  }
});

router.get('/usuario', authenticate.auth, function(req, res) {
  res.render('usuario');
});

module.exports = router;
