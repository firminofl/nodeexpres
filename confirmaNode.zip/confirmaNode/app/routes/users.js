var express = require('express');
var router = express.Router();
var login_controller = require('../controller/login');
var usuario_controller = require('../controller/usuario');

router.post('/signin', login_controller.validate_user);

router.get('/signout', login_controller.signout)

router.post('/insercao', usuario_controller.validar_usuario);

router.get('/select', usuario_controller.select);

router.post('/delete', usuario_controller.delete);

router.post('/update', usuario_controller.update);

module.exports = router;
