function exportarCSV(){
  //Datas e horas referentes ao filtro
  var inputDataInicioDiscagemBilhetes = $('#dataInicioDiscagemBilhetes').val();
  var inputDataFimDiscagemBilhetes = $('#dataFimDiscagemBilhetes').val();

  var inputHoraInicioDiscagemBilhetes = $('#horaInicioDiscagemBilhetes').val();
  var inputHoraFimDiscagemBilhetes = $('#horaFimDiscagemBilhetes').val();

  //contato, tel1 e tel2, telefone discado
  var inputnomeContatoBilhetes = $('#nomeContatoBilhetes').val();
  var inputTel1ContatoBilhetes = $('#tel1ContatoBilhetes').val();
  var inputTel2ContatoBilhetes = $('#tel2ContatoBilhetes').val();

  var inputTelDiscadoBilhetes = $('#telDiscadoBilhetes').val();

  //status da chamada
  var inputStatusChamadaBilhetes = $('#statusChamadaBilhetes').val();

  //DTMF
  var inputDtmfDiscadoBilhetes = $('#dtmfDiscadoBilhetes').val();

  //tipo de atendimento
  var inputTipoAtendimentoBilhetes = $('#tipoAtendimentoBilhetes').val();

  //Vezes discado
  var inputVezesDiscadoBilhetes = $('#vezesDiscadoBilhetes').val();

  //criando um objeto para passar como referencia na rota
  var object = {
    //Datas e horas referentes ao filtro
    dataInicioDiscagemBilhetes: inputDataInicioDiscagemBilhetes,
    dataFimDiscagemBilhetes: inputDataFimDiscagemBilhetes,

    horaInicioDiscagemBilhetes: inputHoraInicioDiscagemBilhetes,
    horaFimDiscagemBilhetes: inputHoraFimDiscagemBilhetes,

    //contato e telefone discado
    nomeContatoBilhetes: inputnomeContatoBilhetes,
    tel1ContatoBilhetes: inputTel1ContatoBilhetes,
    tel2ContatoBilhetes: inputTel2ContatoBilhetes,

    telDiscadoBilhetes: inputTelDiscadoBilhetes,

    //status da chamada
    statusChamadaBilhetes: inputStatusChamadaBilhetes,

    //DTMF
    dtmfDiscadoBilhetes: inputDtmfDiscadoBilhetes,

    //tipo de atendimento
    tipoAtendimentoBilhetes: inputTipoAtendimentoBilhetes,

    //vezes discado
    vezesDiscadoBilhetes: inputVezesDiscadoBilhetes,

    exportarCSVTrueFalse: true
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        montarExportarTabelaCSV(JSON.parse(this.response));
        break;

        case 304:
        montarExportarTabelaCSV(JSON.parse(this.response));
        break;

        case 500:
        alert(JSON.parse(this.response).message);
        break;

        default:
        alert('Erro inesperado, contate o administrador.');
        break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function montarExportarTabelaCSV(rows){
  var csv = 'Data/Hora Chamada, Contato, Telefone 1, Telefone 2, Tel discado , Status Chamada , DTMF discado , Tipo Atendimento , Vezes discado, \n';

  for (var i = 0; i < rows.length; i++) {
    csv += rows[i].cdr_data_hora_chamada;
    csv += ','+ rows[i].contato_nome;
    csv += ','+ rows[i].contato_tel1;
    csv += ','+ rows[i].contato_tel2;
    csv += ','+ rows[i].cdr_tel_discado;
    csv += ','+ rows[i].cdr_status_chamada;
    csv += ','+ rows[i].cdr_dtmf;
    csv += ','+ rows[i].cdr_tipo_atendimento;
    csv += ','+ rows[i].contato_cont_discagem;
    csv += '\n';
  }

  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'bilhetes.csv';
  hiddenElement.click();
}

function gatilhoContMenos(){
  $('#contMais').attr('disabled', false);
  var valorMaximo  = $('#valorMaximo').val();

  var paginationAtual  = parseInt($('#atual').val());

  if (paginationAtual > 0){
    var atual = paginationAtual - 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == 1){
    $('#atual').val(1);
    $('#contMenos').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1){
    atualizaBilhetes();
  }else if (selectORsearch == 2){
    buscarBilhetes();
  }
}

function gatilhoContMais(){
  $('#contMenos').attr('disabled', false);
  var valorMaximo  = $('#valorMaximo').val();
  var paginationAtual  = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo){
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo){
    $('#contMais').attr('disabled', true);
    $('#atual').val(valorMaximo);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1){
    atualizaBilhetes();
  }else if (selectORsearch == 2){
    buscarBilhetes();
  }
}

function gatilhoPaginacaoProximo(){
  $('#contMenos').attr('disabled', false);
  var valorMaximo  = $('#valorMaximo').val();
  var paginationAtual  = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo){
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo){
    $('#atual').val(valorMaximo);
    $('#contMais').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1){
    atualizaBilhetes();
  }else if (selectORsearch == 2){
    buscarBilhetes();
  }
}

function valorMaximoPag(page){
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val( page + " registros.");

  page /= 10;
  if (page % 1 == 0){
    page = page;
  }else{
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximo');

  if (page == 0){
    valorMaximo.val(1);
  }else{
    valorMaximo.val(page);
  }

  if ($('#atual').val() > page){
    $('#atual').val(1);
    $('#contMenos').click();
  }
}

function atualizaBilhetes() {
  var xhttp = new XMLHttpRequest();

  var paginationAtual  = $('#atual').val();

  var object = {
    pagination: paginationAtual
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        valorMaximoPag(JSON.parse(this.response).contador.resultado);
        addBilhetesNaTabela(JSON.parse(this.response).result);
        break;

        case 304:
        valorMaximoPag(JSON.parse(this.response).contador.resultado);
        addBilhetesNaTabela(JSON.parse(this.response).result);
        break;

        case 500:
        console.log("Erro interno com o servidor.");
        break;

        default:
        console.log("Erro inesperado, contate o administrador.");
        break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/select', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addBilhetesNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaBilhetes tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //Data/Hora chamada
    var chamadaCell = newRow.insertCell(count);
    var date = new Date(rows[i].cdr_data_hora_chamada)
    var chamadaValue = document.createTextNode(`${(date.getDate()<10?'0':'') + date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}` + ` ${(date.getHours()<10?'0':'') + date.getHours()}:${(date.getMinutes()<10?'0':'') + date.getMinutes()}`);
    chamadaCell.appendChild(chamadaValue);
    count++;

    //Contato
    var contatoCell = newRow.insertCell(count);
    var contatoValue = document.createTextNode(rows[i].contato_nome);
    contatoCell.appendChild(contatoValue);
    count++;

    //Telefone 1
    var tel1Cell = newRow.insertCell(count);
    var tel1Value = document.createTextNode(rows[i].contato_tel1);
    tel1Cell.appendChild(tel1Value);
    count++;

    //Telefone 2
    var tel2Cell = newRow.insertCell(count);
    var tel2Value = document.createTextNode(rows[i].contato_tel2);
    tel2Cell.appendChild(tel2Value);
    count++;

    //Telefone discado
    var telDiscadoCell = newRow.insertCell(count);
    var telDiscadoValue = document.createTextNode(rows[i].cdr_tel_discado);
    telDiscadoCell.appendChild(telDiscadoValue);
    count++;

    //DTMF
    var dtmfCell = newRow.insertCell(count);
    var dtmfValue = document.createTextNode(rows[i].cdr_dtmf);
    dtmfCell.appendChild(dtmfValue);
    count++;

    //Status Chamada
    var statusClienteCell = newRow.insertCell(count);
    var statusClienteValue = document.createTextNode(rows[i].cdr_status_chamada);
    statusClienteCell.appendChild(statusClienteValue);
    count++;

    //Tipo atendimento
    var tipoCell = newRow.insertCell(count);
    var tipoValue = document.createTextNode(rows[i].cdr_tipo_atendimento);
    tipoCell.appendChild(tipoValue);
    count++;

  }
}

function buscarBilhetes() {
  $('#selectORsearch').val('2');
  var red_alert_modal = document.getElementById('red-alert_modal');
  red_alert_modal.style.visibility = 'none';
  var paginationAtual  = $('#atual').val();

  //Datas e horas referentes ao filtro
  var inputDataInicioDiscagemBilhetes = $('#dataInicioDiscagemBilhetes').val();
  var inputDataFimDiscagemBilhetes = $('#dataFimDiscagemBilhetes').val();

  var inputHoraInicioDiscagemBilhetes = $('#horaInicioDiscagemBilhetes').val();
  var inputHoraFimDiscagemBilhetes = $('#horaFimDiscagemBilhetes').val();

  //contato, tel1 e tel2, telefone discado
  var inputnomeContatoBilhetes = $('#nomeContatoBilhetes').val();
  var inputTel1ContatoBilhetes = $('#tel1ContatoBilhetes').val();
  var inputTel2ContatoBilhetes = $('#tel2ContatoBilhetes').val();

  var inputTelDiscadoBilhetes = $('#telDiscadoBilhetes').val();

  //status da chamada
  var inputStatusChamadaBilhetes = $('#statusChamadaBilhetes').val();

  //DTMF
  var inputDtmfDiscadoBilhetes = $('#dtmfDiscadoBilhetes').val();

  //tipo de atendimento
  var inputTipoAtendimentoBilhetes = $('#tipoAtendimentoBilhetes').val();

  //Vezes discado
  var inputVezesDiscadoBilhetes = $('#vezesDiscadoBilhetes').val();

  //criando um objeto para passar como referencia na rota
  var object = {
    //Datas e horas referentes ao filtro
    dataInicioDiscagemBilhetes: inputDataInicioDiscagemBilhetes,
    dataFimDiscagemBilhetes: inputDataFimDiscagemBilhetes,

    horaInicioDiscagemBilhetes: inputHoraInicioDiscagemBilhetes,
    horaFimDiscagemBilhetes: inputHoraFimDiscagemBilhetes,

    //contato e telefone discado
    nomeContatoBilhetes: inputnomeContatoBilhetes,
    tel1ContatoBilhetes: inputTel1ContatoBilhetes,
    tel2ContatoBilhetes: inputTel2ContatoBilhetes,

    telDiscadoBilhetes: inputTelDiscadoBilhetes,

    //status da chamada
    statusChamadaBilhetes: inputStatusChamadaBilhetes,

    //DTMF
    dtmfDiscadoBilhetes: inputDtmfDiscadoBilhetes,

    //tipo de atendimento
    tipoAtendimentoBilhetes: inputTipoAtendimentoBilhetes,

    //vezes discado
    vezesDiscadoBilhetes: inputVezesDiscadoBilhetes,

    exportarCSVTrueFalse: false,

    pagination: paginationAtual
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        valorMaximoPag(JSON.parse(this.response).contador.resultado);
        addBilhetesNaTabela(JSON.parse(this.response).result);
        break;

        case 304:
        valorMaximoPag(JSON.parse(this.response).contador.resultado);
        addBilhetesNaTabela(JSON.parse(this.response).result);
        break;

        case 500:
        redAlert(JSON.parse(this.response).message);
        break;

        default:
        redAlert('Erro inesperado, contate o administrador.');
        break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function redAlert(message) {
  var success = document.getElementById('red-alert_modal');
  success.innerHTML = message
  success.classList.add('show');
  setTimeout(() => {
    success.classList.remove('show');
  }, 3000);
}

function limparCampos(){
  //Datas e horas referentes ao filtro
  $('#dataInicioDiscagemBilhetes').val('');
  $('#dataFimDiscagemBilhetes').val('');

  $('#horaInicioDiscagemBilhetes').val('');
  $('#horaFimDiscagemBilhetes').val('');

  //contato, tel1 e tel2, telefone discado
  $('#nomeContatoBilhetes').val('');
  $('#tel1ContatoBilhetes').val('');
  $('#tel2ContatoBilhetes').val('');
  $('#telDiscadoBilhetes').val('');

  //status da chamada
  $('#statusChamadaBilhetes').val('');

  //DTMF
  $('#dtmfDiscadoBilhetes').val('');

  //tipo de atendimento
  $('#tipoAtendimentoBilhetes').val('');

  //Vezes discado
  $('#vezesDiscadoBilhetes').val('');

  //Valor de paginacao
  $('#valorMaximo').val(1);
}
