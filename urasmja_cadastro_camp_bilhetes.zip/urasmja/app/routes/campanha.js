var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate');
var campanha_controller = require('../controller/campanha')

router.use(authenticate.apiAuth);

//Cadastrar campanha
router.post('/insert', campanha_controller.insert);

//Cadastrar audio campanha
router.post('/insertAudio', campanha_controller.insertAudio);

//Buscar campanha
router.post('/select', campanha_controller.select);

//Deletar campanha
router.post('/delete', campanha_controller.delete);

//Deletar campanha
router.get('/export', campanha_controller.export);

module.exports = router;
