var express = require('express');
var router = express.Router();
var login_controller = require('../controller/login');

router.post('/signin', login_controller.validate_user);

router.get('/signout', login_controller.signout);

module.exports = router;
