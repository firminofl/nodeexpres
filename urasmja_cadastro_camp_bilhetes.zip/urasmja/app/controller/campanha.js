const pg = require('../db')

module.exports = {
  insertAudio: async (req, res) => {
    files = req.files;
    filesName = req.body;

    if (!files) {
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum arquivo de áudio enviado'
      });
    }
    var nomeAudio = files.audioCampanha.name.split('.')[0];

    try{
      //Verificar se existe o audio cadastrado com o mesmo nome que está vindo do front-end
      var queryAudioCampanha = 'SELECT COUNT(campanha_audio) FROM campanha WHERE campanha_audio = '+ "'"+nomeAudio+ "'";

      pg.query(queryAudioCampanha, [], (err,ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Caso não tenha campanha cadastrada com o nome vindo do front-end
          var temOuNaoAudio = ans.rows[0].count;

          if (temOuNaoAudio > 0){
            console.log("\n\nExiste um áudio cadastrado com este mesmo nome. Verifique!\n\n")
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Existe um áudio cadastrado com este mesmo nome. Verifique!'
            });
          }else if (temOuNaoAudio == 0){
            //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
            var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

            pg.query(sqlUltimaCampanha, [], (err, ans) => {
              if (err) {
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              }else{
                //Resultado do ultimo id de campanha cadastrada
                var ultimoIdCampanha = ans.rows[0].max;

                //Extraindo o nome do audio para montar a query de update
                var nomeAudio = files.audioCampanha.name.split('.')[0];

                var sqlUpdate = 'UPDATE campanha SET campanha_audio = ' +"'"+nomeAudio+"'"+ ' WHERE campanha_id = '+ultimoIdCampanha;

                try {

                  pg.query(sqlUpdate);

                } catch (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro interno, por favor contacte o administrador. Áudio não foi atualizado.'
                  });
                }

                if (files.audioCampanha.length === undefined) {
                  try {
                    //await files.audios.mv('/opt/leucotron/confirma/sounds/' + files.audios.name)
                    files.audioCampanha.mv('/home/filipefirmino/Music/sounds/' + files.audioCampanha.name)
                  } catch (error) {
                    return res.status(500).send({
                      error: 'Upload file',
                      message: 'Erro ao gravar áudio no servidor'
                    })
                  }
                } else {
                  for (var i = 0; i < files.audioCampanha.length; i++) {
                    try {
                      //await files.audios[i].mv('/opt/leucotron/confirma/sounds/' + files.audios[i].name)
                      files.audioCampanha[i].mv('/home/filipefirmino/Music/sounds/' + files.audioCampanha[i].name)
                    } catch (error) {
                      return res.status(500).send({
                        error: 'Upload file',
                        message: 'Erro ao gravar áudio no servidor'
                      });
                    }
                  }
                }
                //execute('sudo converteAudio.sh', (error, stdout) => { });
                //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
                return res.json({
                  success: 'Configurado',
                  message: 'Campanha configurada com sucesso!'
                });
              }
            });
          }
        }
      });
    }catch(err){
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insert: (req,res) => {
    var nomeCampanha = req.body.nomeCampanha;
    //totalcontatos = req.body.totalContatos;
    var tentativasDiscagem = req.body.tentativasDiscagem;
    var intervaloDiscagens = req.body.intervaloDiscagens;
    var chamadaSimultaneas = req.body.chamadaSimultaneas;

    if (!nomeCampanha)
    return res.status(400).send();

    try {
      //Verificar se existe uma campanha cadastrada com o mesmo nome
      var queryNomeCampanha = 'SELECT COUNT(campanha_nome) FROM campanha WHERE campanha_nome = '+ "'"+nomeCampanha+ "'";
      pg.query(queryNomeCampanha, [], (err,ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno, por favor contacte o administrador'
          });
        }else{
          //Caso não tenha campanha cadastrada com o nome vindo do front-end
          temOuNaoCampanha = ans.rows[0].count;

          if (temOuNaoCampanha > 0){
            console.log("\n\nExiste uma campanha cadastrada com este mesmo nome. Verifique!\n\n")
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Existe uma campanha cadastrada com este mesmo nome. Verifique!'
            });
          }else if (temOuNaoCampanha == 0){
            //Modificando o status da campanha para default no Cadastro
            var queryStatus = 'INSERT INTO status(ativado, pausado)VALUES (default, default);';
            pg.query(queryStatus, [], (err, ans) => {
              if (err) {
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              }else{
                //Buscando o id do status para passar no parametro
                var queryUltimoId = 'SELECT MAX(status_id) from status;';
                pg.query(queryUltimoId, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  }else{
                    //Resultado do ultimo id do status
                    var ultimoIdStatus = ans.rows[0].max;

                    //Inserindo agora a campanha
                    var nomeAudio = ultimoIdStatus;
                    var totalContatos = 121;

                    //Query de inserção na tabela de campanha, posteriormente o nomeAudio vai ser alterado para o real.
                    var query = 'INSERT INTO campanha(campanha_nome, campanha_audio, campanha_num_tentativa, campanha_intervalo_discagem, campanha_chamadas_simultaneas, campanha_total_contatos, status_fk)'+
                    'VALUES('+ "'"+nomeCampanha+"'" + "," + "'"+nomeAudio+"'" + "," +tentativasDiscagem+ "," +intervaloDiscagens+ "," +chamadaSimultaneas+ ","+totalContatos+ ","+ultimoIdStatus+")";

                    pg.query(query, [], (err, ans) => {
                      if (err) {
                        return res.status(500).send({
                          error: 'Erro interno',
                          message: 'Erro interno, por favor contacte o administrador'
                        });
                      }else{
                        res.status(200).send({
                          message: 'Campanha configurada com sucesso!'
                        });
                      }
                    });
                  }
                });
              }
            });
          }
        }
      });
    }catch(err){
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  select: (req, res) => {
    //Buscar quantidade de campanhas cadastradas
    var queryQtdCampanha = 'SELECT COUNT(campanha_id) FROM campanha,status WHERE status_fk = status_id';

    pg.query(queryQtdCampanha, [], (err,ans) => {
      if (err) {
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      }else{
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem campanha cadastrada
        if (count.count == 0){
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma campanha cadastrada!'
          });
        }else{
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1){
            pagination = 0;
          }else if (pagination > 1){
            pagination = pagination*10 - 10;
          }

          //Query de busca do id, nome e audio da companha
          var query = 'SELECT campanha_id,campanha_nome,campanha_audio FROM campanha,status WHERE status_fk = status_id ORDER BY campanha_id DESC LIMIT 10 OFFSET '+pagination;

          pg.query(query, [], (err,ans) => {
            if (err) {
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            }else{
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  delete: (req, res) => {
    var campanha_id = req.body.campanha_id;

    var query = 'DELETE FROM campanha WHERE campanha_id = '+campanha_id;

    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        res.json({
          message: 'Campanha excluída com sucesso!'
        });
      }
    });
  },

  export: (req, res) => {
    //Buscar quantidade de campanhas cadastradas
    var queryQtdCampanha = 'SELECT COUNT(campanha_id) FROM campanha,status WHERE status_fk = status_id';

    pg.query(queryQtdCampanha, [], (err,ans) => {
      if (err) {
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      }else{
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem campanha cadastrada
        if (count.count == 0){
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma campanha cadastrada, impossível exportar algo!'
          });
        }else{
          //Query de busca 'da companha
          var query = 'SELECT * FROM campanha,status WHERE status_fk = status_id ORDER BY campanha_id DESC';

          pg.query(query, [], (err,ans) => {
            if (err) {
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            }else{
              res.json(ans.rows);
            }
          });
        }
      }
    });
  }
}
