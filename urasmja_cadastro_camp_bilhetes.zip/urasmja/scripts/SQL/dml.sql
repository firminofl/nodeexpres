﻿--exemplos de inserts

INSERT INTO status(ativado, pausado)
VALUES (default, default);

SELECT MAX(status_id) from status;

INSERT INTO campanha(campanha_nome, campanha_audio, campanha_num_tentativa, campanha_intervalo_discagem, campanha_chamadas_simultaneas, campanha_total_contatos, status_fk)
VALUES ('ISION', 'ision', 3, 1, 4, 100, 1);

INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('evaldo de oliveira', '3534719553', '35991596272', '', 100);
          
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, cdr_tipo_atendimento, contato_fk)
VALUES ('34719553', 'answer', '1', 'human', 2);

--exemplos de selects

SELECT COUNT(campanha_audio) FROM campanha WHERE campanha_audio = 'queue-seconds'

SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY cdr_id DESC LIMIT 10 OFFSET 0
--Tela Campanha
SELECT MAX(campanha_id) FROM campanha

SELECT campanha_nome as nomeCampanha from campanha WHERE campanha_nome = '';
SELECT campanha_audio FROM campanha WHERE campanha_audio = 'queue-seconds'

SELECT campanha_audio FROM campanha;
SELECT campanha_audio FROM campanha WHERE campanha_audio = 'queue-seconds';
SELECT campanha_nome from CAMPANHA WHERE campanha_nome = 'teste3';
SELECT campanha_nome as nomeCampanha from campanha WHERE campanha_nome = 'teste3'
SELECT campanha_audio as nomeAudio FROM campanha WHERE campanha_audio = 'queue-seconds'

SELECT campanha_nome FROM campanha WHERE campanha_nome = 'teste3121'

SELECT * FROM campanha  AS c
LEFT JOIN status AS s ON s.status_id = c.status_fk

SELECT campanha_id,campanha_nome,campanha_audio FROM campanha,status WHERE status_fk = status_id ORDER BY campanha_id DESC LIMIT 10 OFFSET 0;
UPDATE campanha SET campanha_audio = 'testing' WHERE campanha_id = 24

SELECT * FROM contato 
--Tela Contato
SELECT DISTINCT ON (cont.contato_id) cont.contato_id, cdr.cdr_data_hora_chamada, c.campanha_nome, cont.contato_nome FROM contato  AS cont
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cont.contato_id ASC, cdr.cdr_data_hora_chamada DESC

--Tela cdr
SELECT * FROM contato  AS cont
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cdr.cdr_data_hora_chamada DESC

--exemplo delete
DELETE FROM campanha WHERE campanha_id  = 7
DELETE FROM contato  WHERE contato_id = 1