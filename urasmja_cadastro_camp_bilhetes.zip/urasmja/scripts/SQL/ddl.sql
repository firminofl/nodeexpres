﻿-- DROP DATABASE ura;

-- CREATE DATABASE ura;

--DROP TABLE status;
CREATE TABLE status(
	status_id BIGSERIAL NOT NULL,
	status_data_hora_alter TIMESTAMP DEFAULT NOW(),
	ativado BOOLEAN DEFAULT FALSE,
	pausado BOOLEAN DEFAULT FALSE,
	PRIMARY KEY (status_id)
);

--DROP TABLE campanha CASCADE;
CREATE TABLE campanha(
	campanha_id BIGSERIAL NOT NULL,	
	campanha_nome VARCHAR(30) NOT NULL UNIQUE,
	campanha_audio VARCHAR(30) NOT NULL UNIQUE,
	campanha_num_tentativa INT NOT NULL,--Número de tentativas CALL_LIMIT
 	campanha_intervalo_discagem INT NOT NULL,--Intervalo entre discagens
	campanha_chamadas_simultaneas INT NOT NULL, --CHANNLIMIT
	campanha_total_contatos INTEGER,--se csv a app web deve iserir, se integração o script deve atualizar
	campanha_data_hora_criada TIMESTAMP DEFAULT NOW(),
	status_fk BIGINT NOT NULL,
	PRIMARY KEY (campanha_id)
);

--DROP TABLE contato CASCADE;
CREATE TABLE contato(
	contato_id BIGSERIAL NOT NULL,	
	contato_nome VARCHAR(128) NOT NULL,
	contato_tel1 VARCHAR(50) NOT NULL,
	contato_tel2 VARCHAR(50),
	contato_outros VARCHAR(128),
	contato_data_hora_discagem TIMESTAMP DEFAULT NOW(),
	contato_cont_discagem INT DEFAULT 0,
	contato_excluido BOOLEAN DEFAULT FALSE, --quando botão parar da tela campanha for acionado ou o numero de telefone < 8 digitos este campo vira true
	campanha_fk BIGINT NOT NULL,
	PRIMARY KEY (contato_id)
);

--DROP TABLE  cdr CASCADE;
CREATE TABLE cdr(
	cdr_id BIGSERIAL NOT NULL,
	cdr_data_hora_chamada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	cdr_tel_discado VARCHAR(30),
	cdr_status_chamada VARCHAR(15),
	cdr_dtmf VARCHAR(15),
	cdr_tipo_atendimento VARCHAR(30),
	contato_fk BIGINT NOT NULL,
	PRIMARY KEY (cdr_id)
);

ALTER TABLE campanha ADD CONSTRAINT campanha_status_fk FOREIGN KEY (status_fk) REFERENCES status(status_id) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE contato ADD CONSTRAINT contato_campanha_fk FOREIGN KEY (campanha_fk) REFERENCES campanha(campanha_id) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE cdr ADD CONSTRAINT cdr_contato_fk FOREIGN KEY (contato_fk) REFERENCES contato(contato_id) ON UPDATE CASCADE ON DELETE CASCADE;

--DROP TABLE usuario;
CREATE TABLE usuario(
	usuario_id BIGSERIAL NOT NULL,
	usuario_login CHARACTER VARYING(20) NOT NULL UNIQUE,
	usuario_senha CHARACTER VARYING(128) NOT NULL,
	PRIMARY KEY (usuario_id)
);

INSERT INTO usuario(usuario_id,usuario_login,usuario_senha)
VALUES(1,'admin','353ba90f8c0b3e0f355a3d6c960b7caed5f2c1412992277c0669a04a62e7dfd35fba9f4631a7dc6d00fb44d93d305cc0b749c7501d9ce86f26148d05101b8324');
--admin
--master
