#|+----------------------------------------------------------------------------------------------------------------------------------------------+
#| Autor: Evaldo de Oliveira                                                                                                                     |
#| Data : 08/12/15                                                                                                                               |
#|-----------------------------------------------------------------------------------------------------------------------------------------------|
#| Script responsável por:                                                                                                                       |
#| - Converter os arquivos de áudios que estão no diretório /opt/leucotron/avali-e/sounds/ e salvá-los no diretório /var/lib/asterisk/sounds/en/ |
#| - Os arquivos que são salvos no diretorio /opt/leucotron/avali-e/sounds/ são inseridos neste diretório através da interface WEB.              |
#| - Forma de teste: executar o comando convertAudio.sh de qualquer diretorio ou /opt/leucotron/avali-e/scripts/convertAudio.sh.                 |
#| - Script executado pelo script setup_pergunta.sh.                                                                                             |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+
#| Histórico:                                                                                                                                    |
#| Versão: v1.0                                                                                                                                  |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+
#|SGDB: Postgresql 8.4                                                                                                                           |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+

#!/bin/bash
cd /opt/leucotron/avali-e/sounds/

for input in *;
do
 if [ "${input##*.}" = wav ]
 then
  sox ${input%%.*}.wav -r 8000 -c1 ${input%%.*}.gsm
  rm ${input}
  mv ${input%%.*}.gsm /var/lib/asterisk/sounds/en/
 else
  if [ "${input##*.}" = mp3 ]
  then
   mpg123 -w ${input%%.*}.wav ${input%%.*}.mp3    
   sox ${input%%.*}.wav -r 8000 -c1 ${input%%.*}.gsm
   rm ${input%%.*}.wav
   rm ${input}
   mv ${input%%.*}.gsm /var/lib/asterisk/sounds/en/
 else
   if [ "${input##*.}" = gsm ]
   then
    mv ${input%%.*}.gsm /var/lib/asterisk/sounds/en/
 else
    echo -e "\nOs unicos formatos convertidos para .gsm sao, .mp3 e .wav.\n" >> /dev/null
   fi
  fi
 fi
done
