#!/bin/bash
#+---------------------------------------------------------------------------------------------------------------+
#|date +%w: retorna o dia da semana sendo:                                                                       |
#|0-Domingo, 1-Segunda, 2-Terça, 3-Quarta, 4-Quinta, 5-Sexta e 6-Sábado                                          |
#|date +%H%M: retorna hora e minuto do sistema de forma concatenada.                                             |
#+---------------------------------------------------------------------------------------------------------------+
#|Descrição: Discador para Asterisk integrado com banco de dados Postgresql 9.3                                  |
#+---------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                      |
#|Data: 08/01/2019                                                                                               |
#+---------------------------------------------------------------------------------------------------------------+

export PGPASSWORD=sml3uc0

DBUSER='postgres'
DBNAME='ura'
DBTABLECONTATO='contato'
DBTABLECDR='cdr'
DBTABLELOG='log'
DBTABLECAMPANHA='campanha'
DBTABLESTATUS='status'

#Parametros flexiveis. Traz do BD.
CONF=$(echo "SELECT * FROM ${DBTABLECAMPANHA}" | psql -t -d ura -U postgres | xargs)

ID_CAMPANHA=$(echo ${CONF} | awk -F '|' '{ print $1 }' | xargs)
NOME_CAMPANHA=$(echo ${CONF} | awk -F '|' '{ print $2 }' | xargs)
AUDIO_CAMPANHA=$(echo ${CONF} | awk -F '|' '{ print $3 }' | xargs)
#Limite de discagnes para o mesmo contato
CALL_LIMIT=$(echo ${CONF} | awk -F '|' '{ print $4 }' | xargs)
#Intervalo minimo de horas entre discagens
INTERVAL=$(echo ${CONF} | awk -F '|' '{ print $5 }' | xargs)
#Chamadas simultaneas
CHANNLIMIT=$(echo ${CONF} | awk -F '|' '{ print $6 }' | xargs)

case "$1" in
    start)
        sleep 10

        #While true
        while :
        do
		
            #validar se pausado
            #STATUS_CAMPANHA=$(echo "SELECT s.ativado, s.pausado FROM ${DBTABLECAMPANHA}  AS c LEFT JOIN ${DBTABLESTATUS} AS s ON s.status_id = c.status_fk" | psql -t -d ura -U postgres | xargs)
            #ATIVADO_CAMPANHA=$(echo ${STATUS_CAMPANHA} | awk -F '|' '{ print $1 }' | xargs)
            #PAUSADO_CAMPANHA=$(echo ${STATUS_CAMPANHA} | awk -F '|' '{ print $2 }' | xargs)
            PAUSA_CAMPANHA=$(echo "SELECT s.pausado FROM ${DBTABLECAMPANHA}  AS c LEFT JOIN ${DBTABLESTATUS} AS s ON s.status_id = c.status_fk" | psql -t -d ura -U postgres | xargs)
            if [ "${PAUSA_CAMPANHA}" == "f" ]; then                        
                #Pega o total de consultas deverao ser confirmadas, no caso de integracao
                #TOTAL=$(echo `select_bd_remoto.sh | wc -l`)
                #Se TOTAL != numero. Erro de conexao com BD remoto. E I=0 ainda nao executou. Assim executa uma vez ao dia
                #if [[ "${TOTAL}" -gt 0 ]] && [[ "${I}" -eq 0 ]] ; then
                #    echo "INSERT INTO ${DBTABLELOG}(total_consultas) VALUES ('${TOTAL}');" | psql -t -d ${DBNAME} -U ${DBUSER} >> /dev/null
                #    #Le BD remoto e inser no BD local
                #    select_bd_remoto.sh | while read CONTATO; do
                #        #Testa se retona registro do BD, ou seja, CONTATO != NULL
                #        if test -n "${CONTATO}"; then
                #            COD_MED=$(echo "${CONTATO}" | awk -F '|' '{ print $2 }' | xargs)
                #            AGM_LOC=$(echo "${CONTATO}" | awk -F '|' '{ print $3 }' | xargs)
                #            DATA_HORA_CONS=$(echo "${CONTATO}" | awk -F '|' '{ print $4 }' | xargs)
                #            EXT=$(echo "${CONTATO}" | awk -F '|' '{ print $5 }' | xargs)
                #            COD_PAC=$(echo "${CONTATO}" | awk -F '|' '{ print $6 }'| xargs)
                #            NOME_PAC=$(echo "${CONTATO}" | awk -F '|' '{ print $8 }' | xargs)
                #            TEL_1=$(echo "${CONTATO}" | awk -F '|' '{ print $9 }'| xargs)
                #            TEL_2=$(echo "${CONTATO}" | awk -F '|' '{ print $10 }'| xargs)
                #            COD_LOCAL=$(echo "${CONTATO}" | awk -F '|' '{ print $3 }' | xargs)
                #            echo "INSERT INTO ${DBTABLECONTATO}(cod_medico, cod_localidade, data_hora_consulta, ext, cod_paciente, nome_paciente, tel_1, tel_2, nome_medico, nome_servico, agm_loc) VALUES ('${COD_MED}', '${COD_LOCAL}', '${DATA_HORA_CONS}', '${EXT}', '${COD_PAC}', '${NOME_PAC}', '${TEL_1}', '${TEL_2}', '${NOME_MED}', '${NOME_SRV}', '${AGM_LOC}');" | psql -t -d ${DBNAME} -U ${DBUSER} >> /dev/null
                #        #Fim de teste CONTATO != NULL
                #        fi
                #    #Fim do while que lê o BD remoto.
                #    done
                ##Fim teste conexao BD remoto e transferencia de dados entre BD remoto e local
                #fi
            
                #Le BD local em busca de contatos que nao atingiram o limite de discagem estipulado
                echo "SELECT * FROM ${DBTABLECONTATO} WHERE contato_excluido IS FALSE AND campanha_fk = ${ID_CAMPANHA} AND contato_cont_discagem <= ${CALL_LIMIT} ORDER BY contato_data_hora_discagem ASC, contato_cont_discagem ASC;" | psql -t -d ${DBNAME} -U ${DBUSER} | while read NUMBER; do
                    #testa se pausado
                    PAUSA_CAMPANHA=$(echo "SELECT s.pausado FROM ${DBTABLECAMPANHA}  AS c LEFT JOIN ${DBTABLESTATUS} AS s ON s.status_id = c.status_fk" | psql -t -d ura -U postgres | xargs)
                    if [ "${PAUSA_CAMPANHA}" == "f" ]; then                            
                        #Testa se NUMBER eh diferente de  NULL. Ultima linha do BD local.
                        if test -n "${NUMBER}"; then
                            CONTATO_TEL_1=$(echo "${NUMBER}" | awk -F '|' '{ print $3 }' | xargs | sed 's/[^0-9]//g')
                            CONTATO_TEL_2=$(echo "${NUMBER}" | awk -F '|' '{ print $4 }' | xargs | sed 's/[^0-9]//g')
                            
                            #Testa se o numero do tel1 e tel2 possui numero de digitos >= 8
                            if [ ${#CONTATO_TEL_1} -ge 8 -o ${#CONTATO_TEL_2} -ge 8 ]; then
                                #Testa qtd de canais utilizado pelo Confirmador
                                NCALLSLOCAL=`sudo asterisk -rx "group show channels DISCADOR" | egrep "active" | awk '{ print $1 }'`

                                if test "${NCALLSLOCAL}" -le "${CHANNLIMIT}"; then
                                    CONTATO_ID=$(echo "${NUMBER}" | awk -F '|' '{ print $1 }' | xargs )                                    
                                    CONTATO_CONT=$(echo "${NUMBER}" | awk -F '|' '{ print $7 }' | xargs)                                    
                                            
                                    #DIF recebe a hora da ultima discagem para o paciente em questao
                                    DIF=$(echo "SELECT TO_CHAR(CURRENT_TIMESTAMP - contato_data_hora_discagem, 'HH24') FROM ${DBTABLECONTATO} WHERE contato_id = '${CONTATO_ID}';" | psql -t -d ${DBNAME} -U ${DBUSER})
                                    #Verifica o intervalo de horas entre discagem para o contato em questao
                                    if [ \( "${DIF}" -ge "${INTERVAL}" \) -o \( "${CONTATO_CONT}" -eq "0" \) ];then

                                        #Testa se atingiu limite de discagem disponivel
                                        if [ "${CONTATO_CONT}" -eq "${CALL_LIMIT}" ];then
                                            DIALSTATUS='LIMITE ATINGIDO'
										else
										    DIALSTATUS=''
                                        fi
                                        
                                        CONTATO_NOME=$(echo "${NUMBER}" | awk -F '|' '{ print $2 }' | xargs)                               
      
                                        ABSOLUTE_FILE_NAME='/opt/leucotron/call/'$(date +"%d%m%Y%H%M%S")_${CONTATO_TEL_1}'.call'
                                        echo "Channel: Local/${CONTATO_TEL_1}@outbound-call"           > ${ABSOLUTE_FILE_NAME}
                                        echo "Callerid: "5999" 5999"                                   >> ${ABSOLUTE_FILE_NAME}
                                        echo "MaxRetries: 0"                                           >> ${ABSOLUTE_FILE_NAME}
                                        echo "WaitTime: 180"                                           >> ${ABSOLUTE_FILE_NAME}
                                        echo "Context: inbound-call"                                   >> ${ABSOLUTE_FILE_NAME}
                                        echo "Extension: ${CONTATO_TEL_1}"                             >> ${ABSOLUTE_FILE_NAME}
                                        echo "Priority: 1"                                             >> ${ABSOLUTE_FILE_NAME}
                                        echo "Set: CONTATO_ID=${CONTATO_ID}"                           >> ${ABSOLUTE_FILE_NAME}                                        
                                        echo "Set: CONTATO_NOME=${CONTATO_NOME}"                       >> ${ABSOLUTE_FILE_NAME}                                       
                                        echo "Set: CONTATO_TEL_1=${CONTATO_TEL_1}"                     >> ${ABSOLUTE_FILE_NAME}
                                        echo "Set: CONTATO_TEL_2=${CONTATO_TEL_2}"                     >> ${ABSOLUTE_FILE_NAME}                                       
                                        echo "Set: CONTATO_CONT=${CONTATO_CONT}"                       >> ${ABSOLUTE_FILE_NAME}                                        
#                                        echo "Set: DIALSTATUS=ANSWER"                                  >> ${ABSOLUTE_FILE_NAME}
                                        echo "Set: DIALSTATUS=${DIALSTATUS}"                           >> ${ABSOLUTE_FILE_NAME}
										echo "Set: AUDIO_CAMPANHA=${AUDIO_CAMPANHA}"                   >> ${ABSOLUTE_FILE_NAME}
                                        echo "Archive: yes"                                            >> ${ABSOLUTE_FILE_NAME}                                    
                                        echo "$(date +"%d-%m-%Y_%H:%M:%S") Chamando ${CONTATO_TEL_1}"  >> /opt/leucotron/log/confirmaConsulta.log 
                                        mv ${ABSOLUTE_FILE_NAME} /var/spool/asterisk/outgoing/                        

                                        #Atualiza o numero de discagem realizada para o contato em questao
                                        echo "UPDATE ${DBTABLECONTATO} SET contato_cont_discagem = contato_cont_discagem +  1, contato_data_hora_discagem = now() WHERE contato_id = '${CONTATO_ID}';" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null

                                        #sleep usado para otimizar o processo de discagem para segundo tel. Tentando evitar congestion qnd usa Neogate
                                        sleep 10
                                    #Fim validacao de intervalo de discagem
                                    fi 
                                else
                                    sleep 25
                                    #Fim teste numero de canais disponivel
                                fi
                            #Tel1 e tel2 qtd digitos < 8
                            else
                                #nao apagar o contato, apenas nao discar e informar na base que o numero esta errado
                                echo "UPDATE ${DBTABLECONTATO} SET contato_excluido = true WHERE contato_id = '${CONTATO_ID}';" | psql -d ${DBNAME} -U ${DBUSER}
                                #Fim testa qtd digitos tel1 e tel2
                            fi
                        #chegou na ultima linha do select no bd local.
                        fi
                    else
                        break
                    #Fim teste pausado
                    fi
                #Fim do while que lê o BD local.
                done
                    sleep 60
            else
                sleep 60
            #Fim do teste se pausado
            fi
        #Fim While true.
        done & echo $! > /opt/leucotron/script/.pid
        if [ $? -ne 0 ];then
            echo "Programa não pode ser inicializado! Verifique se esta executando como root."
            sudo kill -9 `ps -aux | egrep dialer.sh | awk '{ print $2 }'| grep -v PID`
            exit
        fi
    ;;
    stop)
        echo "UPDATE ${DBTABLECONTATO} SET contato_excluido = true WHERE campanha_fk = ${ID_CAMPANHA}" | psql -d ${DBNAME} -U ${DBUSER}
        rm /opt/leucotron/script/.pid >> /dev/null
        sudo kill -9 `ps -aux | egrep dialer.sh | awk '{ print $2 }'| grep -v PID`
        exit
    ;;
    *)
        echo "Use start|stop"
        exit 0
    ;;
esac
