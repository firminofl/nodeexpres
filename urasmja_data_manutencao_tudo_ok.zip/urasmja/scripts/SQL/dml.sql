﻿--exemplos de inserts

INSERT INTO status(ativado, pausado,parado)
VALUES (default, default,default);

SELECT MAX(status_id) from status;

INSERT INTO campanha(campanha_nome, campanha_audio, campanha_num_tentativa, campanha_intervalo_discagem, campanha_chamadas_simultaneas, campanha_total_contatos, status_fk)
VALUES ('ISION', 'ision', 3, 1, 4, 100, 1);

INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('evaldo de oliveira', '3534719553', '35991596272', '', 100);

INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('Filipe Firmino', '3532414541', '35984693042', '', 100);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, cdr_tipo_atendimento, contato_fk)
VALUES ('35988853042', 'answer', '2', 'machine', 37);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, cdr_tipo_atendimento, contato_fk)
VALUES ('984693042', 'no response', '', '', 3);

--exemplos de selects

SELECT COUNT(campanha_audio) FROM campanha WHERE campanha_audio = 'queue-seconds'

SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY cdr_id DESC LIMIT 10 OFFSET 0
--Tela Campanha
SELECT MAX(campanha_id) FROM campanha

SELECT campanha_nome as nomeCampanha from campanha WHERE campanha_nome = '';
SELECT campanha_audio FROM campanha WHERE campanha_audio = 'queue-seconds'

SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND cdr_data_hora_chamada > '2019-01-12 00:00'

SELECT campanha_audio FROM campanha;
SELECT campanha_audio FROM campanha WHERE campanha_audio = 'queue-seconds';
SELECT campanha_nome from CAMPANHA WHERE campanha_nome = 'teste3';
SELECT campanha_nome as nomeCampanha from campanha WHERE campanha_nome = 'teste3'
SELECT campanha_audio as nomeAudio FROM campanha WHERE campanha_audio = 'queue-seconds'

SELECT campanha_nome FROM campanha WHERE campanha_nome = 'teste3121'

SELECT * FROM campanha  AS c
LEFT JOIN status AS s ON s.status_id = c.status_fk

SELECT campanha_id,campanha_nome,campanha_audio FROM campanha,status WHERE status_fk = status_id ORDER BY campanha_id DESC LIMIT 10 OFFSET 0;
UPDATE campanha SET campanha_audio = 'testing' WHERE campanha_id = 24

SELECT * FROM contato 
INSERT INTO contato(contato_nome,contato_tel1,contato_tel2, campanha_fk) VALUES ('Filipe Firmino', '35984693042', '3532414541',107)

UPDATE status SET pausado = FALSE FROM campanha WHERE status_fk = status_id AND ativado = TRUE AND campanha_nome = 'Teste3'

--Tela Contato
SELECT DISTINCT ON (cont.contato_id) cont.contato_id, cdr.cdr_data_hora_chamada, c.campanha_nome, cont.contato_nome FROM contato  AS cont 
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cont.contato_id ASC, cdr.cdr_data_hora_chamada DESC

--Tela cdr
SELECT * FROM contato  AS cont
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cdr.cdr_data_hora_chamada DESC

--exemplo delete
DELETE FROM contato 
DELETE FROM status
DELETE FROM cdr 
DELETE FROM campanha 

INSERT INTO contato(contato_nome,contato_tel1,contato_tel2, campanha_fk) VALUES ('Filipe Firmino', '35984693042', '3532414541', 154), ('Filipe Fir', '35984693012', '3532414541', 154), ('Firmino', '35984693032', '3532414543', 154), ('Firm', '35984693033', '3532414544', 154), ('Fir', '35984693034', '3532414545', 154), ('Firmi', '35984693035', '3532414546', 154), ('Fi', '35984693036', '3532414547', 154)

SELECT DISTINCT ON (cont.contato_id) cont.contato_id, cdr.cdr_data_hora_chamada, c.campanha_nome, cont.contato_nome, cont.contato_tel1, cont.contato_tel2 
FROM contato  AS cont 
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cont.contato_id ASC, cdr.cdr_data_hora_chamada DESC 
LIMIT 10 OFFSET 0

SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2
            FROM cdr, contato, status, campanha 
            WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id
            ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET 0

SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 
FROM cdr, contato, status, campanha 
WHERE cdr_data_hora_chamada BETWEEN '15/1/2019 16:01' AND '15/1/2019 16:11' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET 0

 SELECT DISTINCT ON (cont.contato_id) cont.contato_id, cdr.cdr_data_hora_chamada, c.campanha_nome, cont.contato_nome, cont.contato_tel1, cont.contato_tel2 
 FROM contato  AS cont 
 LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk 
 LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id 
 ORDER BY cont.contato_id ASC, cdr.cdr_data_hora_chamada DESC LIMIT 10 OFFSET 0

SELECT COUNT(campanha_nome) FROM campanha, status WHERE status_fk = status_id AND parado = FALSE;

SELECT campanha_nome FROM campanha, status WHERE status_fk = status_id ORDER BY campanha_nome ASC;
SELECT COUNT(campanha_nome) FROM campanha, status WHERE status_fk = status_id;

SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 FROM cdr, contato, status, campanha WHERE contato_tel1 ILIKE '%35984693042%' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET 0

SELECT campanha_total_contatos as totalContatos  FROM campanha, status WHERE status_fk = status_id AND parado = FALSE AND campanha_nome = 'Abc'

SELECT COUNT(cdr_dtmf) as dtfm1 FROM campanha, status, cdr,contato WHERE status_fk = status_id AND contato_fk = contato_id AND parado = FALSE AND cdr_dtmf = '1' AND campanha_nome = 'Abc'

SELECT COUNT(cdr_id) FROM campanha, status, cdr,contato WHERE status_fk = status_id AND contato_fk = contato_id AND parado = FALSE AND campanha_nome = 'Abc'

SELECT COUNT(cdr_status_chamada) as totalNaoAtendidas FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND cdr_status_chamada = 'answer' AND campanha_nome = 'Abc'

SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 FROM cdr, contato, status, campanha WHERE contato_nome ILIKE '%%' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET 0

SELECT COUNT(cdr_id) as totalDiscagens FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND campanha_nome = 'Abc'

UPDATE status SET ativado = FALSE FROM campanha WHERE status_fk = status_id AND campanha_nome = 'Script'

UPDATE contato SET contato_excluido = TRUE FROM campanha 
WHERE contato_cont_discagem = 0 AND campanha_fk = campanha_id AND campanha_nome = 'Abc'

--update em duas tabelas
UPDATE contato SET contato_excluido = TRUE FROM campanha WHERE contato_cont_discagem = 0 AND campanha_fk = campanha_id AND campanha_nome = 'Abc'
UPDATE status SET parado = TRUE FROM campanha,contato WHERE contato_excluido = TRUE AND status_fk = status_id AND campanha_nome = 'Abc'
      
UPDATE status SET pausado = TRUE FROM campanha WHERE status_fk = status_id AND ativado = TRUE AND campanha_nome = 'Abc'

SELECT * FROM contato WHERE contato_excluido IS FALSE AND campanha_fk = 21 AND contato_cont_discagem <= 3 ORDER BY contato_data_hora_discagem ASC, contato_cont_discagem ASC;

UPDATE status SET parado = TRUE FROM campanha,contato WHERE contato_excluido = TRUE AND status_fk = status_id AND campanha_nome = 'FDSFS';

SELECT COUNT(campanha_nome) as resultado FROM campanha, status WHERE status_fk = status_id AND parado = FALSE;

SELECT COUNT(ativado) FROM  status,campanha WHERE status_fk = status_id AND ativado = TRUE and campanha_nome = 'Teste'

SELECT ativado,pausado FROM status, campanha WHERE status_fk = status_id AND campanha_nome = 'Teste3'

SELECT ativado FROM status, campanha WHERE status_fk = status_id AND ativado = TRUE
SELECT ativado FROM status, campanha WHERE status_fk = status_id

SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id