var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate')

//Rota padrão criada pelo express para inicialização da aplicação
router.get('/', authenticate.auth, function(req, res) {
  res.render('index');
});

//Verifica se o usuario fez login, em caso afirmativo: entra na pag principal, senão fica em login
router.get('/login', function(req, res) {
  if (req.session.userid) {
    res.redirect('index')
  } else {
    res.render('login');
  }
});

//Abrir tela de cadastro de campanha
router.get('/cadastrar-campanha', authenticate.auth, function(req, res) {
  res.render('campanha_cadastro');
});

//Abrir tela de gerenciamento de campanha
router.get('/gerenciamento-de-campanha', authenticate.auth, function(req, res) {
  res.render('campanha_gerenciamento');
});

//Abrir tela de gerenciamento de campanha
router.get('/historico-de-campanhas', authenticate.auth, function(req, res) {
  res.render('campanha_historico');
});

//Abrir tela de bilhetes
router.get('/bilhetes', authenticate.auth, function(req, res) {
  res.render('bilhetes');
});

//Abrir tela de contatos
router.get('/contatos', authenticate.auth, function(req, res) {
  res.render('contatos');
});

//Abrir tela de usuario
router.get('/usuarios', authenticate.auth, function(req, res) {
  res.render('usuario');
});

//Abrir tela de manutencao
router.get('/manutencao', authenticate.auth, function(req, res) {
  res.render('manutencao');
});

module.exports = router;
