const pg = require('../db');

module.exports = {
  select: (req, res) => {
    console.log("\n\nEntrei para controller\n\n");
    pg.query('SELECT * FROM cdr', [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  }
}
