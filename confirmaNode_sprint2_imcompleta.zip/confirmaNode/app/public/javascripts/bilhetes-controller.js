function atualizaBilhetes() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/bilhete/select')
  console.log("Entrei no atualiza");
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        addBilhetesNaTabela(JSON.parse(this.response))
        break;
        case 304:
        addBilhetesNaTabela(JSON.parse(this.response))
        break;
        case 500:
        console.log("Erro interno com o servidor.");
        break;
        default:
        console.log("Erro inesperado, contate o administrador.");
        break;
      }
    }
  }
  xhttp.send()
}

function addBilhetesNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaBilhetes tbody');

  console.log("Entrei no add bilhetes");
  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //celular de chamada
    var chamadaCell = newRow.insertCell(count);
    var chamadaValue = document.createTextNode(rows[i].cdr_data_hora_chamada);
    chamadaCell.appendChild(chamadaValue);
  }
}
