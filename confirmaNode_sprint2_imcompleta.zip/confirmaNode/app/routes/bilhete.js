var express = require('express');
var router = express.Router();
var bilhetes_controller = require('../controller/bilhetes');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);
console.log("Entrei na rota");
router.get('/select', bilhetes_controller.select);

module.exports = router;
