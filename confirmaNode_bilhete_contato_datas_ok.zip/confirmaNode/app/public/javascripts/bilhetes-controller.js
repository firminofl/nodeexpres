function exportarCSV() {
  //****************************Data de discagem***********************************/
  //Datas e horas referentes ao filtro
  var inputDataInicioDiscagemBilhetes = $('#dataInicioDiscagemBilhetes').val();
  var inputDataFimDiscagemBilhetes = $('#dataFimDiscagemBilhetes').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioDiscagemBilhetess = null;
  if (!inputDataInicioDiscagemBilhetes.length == 0) {
    inputDataInicioDiscagemBilhetess =
      inputDataInicioDiscagemBilhetes[3] + inputDataInicioDiscagemBilhetes[4] + //mes
      "/" + inputDataInicioDiscagemBilhetes[0] + inputDataInicioDiscagemBilhetes[1] + // dia
      "/" + inputDataInicioDiscagemBilhetes[6] + inputDataInicioDiscagemBilhetes[7] + inputDataInicioDiscagemBilhetes[8] + inputDataInicioDiscagemBilhetes[9]; //ano
  } else {
    inputDataInicioDiscagemBilhetess = '';
  }

  var inputDataFimDiscagemBilhetess = null;
  if (!inputDataFimDiscagemBilhetes.length == 0) {
    inputDataFimDiscagemBilhetess =
      inputDataFimDiscagemBilhetes[3] + inputDataFimDiscagemBilhetes[4] + //mes
      "/" + inputDataFimDiscagemBilhetes[0] + inputDataFimDiscagemBilhetes[1] + // dia
      "/" + inputDataFimDiscagemBilhetes[6] + inputDataFimDiscagemBilhetes[7] + inputDataFimDiscagemBilhetes[8] + inputDataFimDiscagemBilhetes[9]; //ano
  } else {
    inputDataFimDiscagemBilhetess = '';
  }
  //****************************Fim data de discagem********************************/

  var inputHoraInicioDiscagemBilhetes = $('#horaInicioDiscagemBilhetes').val();
  var inputHoraFimDiscagemBilhetes = $('#horaFimDiscagemBilhetes').val();

  //*****************************Data de consulta***********************************/
  var inputDataInicioConsultaBilhetes = $('#dataInicioConsultaBilhetes').val();
  var inputDataFimConsultaBilhetes = $('#dataFimConsultaBilhetes').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioConsultaBilhetess = null;
  if (!inputDataInicioConsultaBilhetes.length == 0) {
    inputDataInicioConsultaBilhetess =
      inputDataInicioConsultaBilhetes[3] + inputDataInicioConsultaBilhetes[4] + //mes
      "/" + inputDataInicioConsultaBilhetes[0] + inputDataInicioConsultaBilhetes[1] + // dia
      "/" + inputDataInicioConsultaBilhetes[6] + inputDataInicioConsultaBilhetes[7] + inputDataInicioConsultaBilhetes[8] + inputDataInicioConsultaBilhetes[9]; //ano
  } else {
    inputDataInicioConsultaBilhetess = '';
  }

  var inputDataFimConsultaBilhetess = null;
  if (!inputDataFimConsultaBilhetes.length == 0) {
    var inputDataFimConsultaBilhetess =
      inputDataFimConsultaBilhetes[3] + inputDataFimConsultaBilhetes[4] + //mes
      "/" + inputDataFimConsultaBilhetes[0] + inputDataFimConsultaBilhetes[1] + // dia
      "/" + inputDataFimConsultaBilhetes[6] + inputDataFimConsultaBilhetes[7] + inputDataFimConsultaBilhetes[8] + inputDataFimConsultaBilhetes[9]; //ano
  } else {
    inputDataFimConsultaBilhetess = '';
  }
  //****************************Fim data de consulta********************************/

  var inputHoraInicioConsultaBilhetes = $('#horaInicioConsultaBilhetes').val();
  var inputHoraFimConsultaBilhetes = $('#horaFimConsultaBilhetes').val();

  //paciente
  var inputNomePacienteBilhetes = $('#nomePacienteBilhetes').val();
  var inputTel1PacienteBilhetes = $('#tel1PacienteBilhetes').val();
  var inputTel2PacienteBilhetes = $('#tel2PacienteBilhetes').val();

  //medico
  var inputNomeMedicoBilhetes = $('#nomeMedicoBilhetes').val();

  //status
  var inputStatusChamadaBilhetes = $('#statusChamadaBilhetes').val();
  var inputStatusConsultaBilhetes = $('#statusConsultaBilhetes').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoBilhetes = $('#tipoAtendimentoBilhetes').val();
  var inputTelDiscadoBilhetes = $('#telDiscadoBilhetes').val();

  //Id consulta
  var inputIdConsultaBilhetes = $('#idConsultaBilhetes').val();

  //Validar datas para não sobrecarregar o servidor
  validarDatas();

  //criando um objeto para passar como referencia na rota
  var object = {
    dataInicioDiscagemBilhetes: inputDataInicioDiscagemBilhetess,
    dataFimDiscagemBilhetes: inputDataFimDiscagemBilhetess,

    horaInicioDiscagemBilhetes: inputHoraInicioDiscagemBilhetes,
    horaFimDiscagemBilhetes: inputHoraFimDiscagemBilhetes,

    dataInicioConsultaBilhetes: inputDataInicioConsultaBilhetess,
    dataFimConsultaBilhetes: inputDataFimConsultaBilhetess,

    horaInicioConsultaBilhetes: inputHoraInicioConsultaBilhetes,
    horaFimConsultaBilhetes: inputHoraFimConsultaBilhetes,

    nomePacienteBilhetes: inputNomePacienteBilhetes,
    tel1PacienteBilhetes: inputTel1PacienteBilhetes,
    tel2PacienteBilhetes: inputTel2PacienteBilhetes,

    nomeMedicoBilhetes: inputNomeMedicoBilhetes,

    statusChamadaBilhetes: inputStatusChamadaBilhetes,
    statusConsultaBilhetes: inputStatusConsultaBilhetes,

    tipoAtendimentoBilhetes: inputTipoAtendimentoBilhetes,
    telDiscadoBilhetes: inputTelDiscadoBilhetes,

    idConsultaBilhetes: inputIdConsultaBilhetes,

    exportarCSVTrueFalse: true
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          swal({
            title: "Exportar CSV",
            text: "Este processo pode demorar um tempo!",
            timer: 4000,
            showConfirmButton: true
          });
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 304:
          swal({
            title: "Exportar CSV",
            text: "Este processo pode demorar um tempo!",
            timer: 4000,
            showConfirmButton: true
          });
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 500:
          swal({
            title: "Ops :(",
            text: JSON.parse(this.response).message,
            type: "error",
            timer: 4000,
            showConfirmButton: true
          });
          break;

        default:
          redAlert('Erro inesperado, contate o administrador.');
          break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function montarExportarTabelaCSV(rows) {
  var csv = 'Data/Hora Chamada, Data/Hora Consulta, Paciente,Médico(a), Status Chamada, Status Consulta, Tipo Chamada, Tel discado, Id consulta\n';

  for (var i = 0; i < rows.length; i++) {
    var date = new Date(rows[i].cdr_data_hora_chamada);
    csv += (date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear() + " " + (date.getHours() < 10 ? '0' : '') + date.getHours() + ":" + (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();

    var date2 = new Date(rows[i].contato_consulta_data_hora);
    csv += ',' + (date2.getDate() < 10 ? '0' : '') + date2.getDate() + "/" + ((date2.getMonth() + 1) < 10 ? '0' + (date2.getMonth() + 1) : ((date2.getMonth() + 1))) + "/" + date2.getFullYear() + " " + (date2.getHours() < 10 ? '0' : '') + date2.getHours() + ":" + (date2.getMinutes() < 10 ? '0' : '') + date2.getMinutes();
    csv += ',' + rows[i].contato_paciente_nome;
    csv += ',' + rows[i].contato_medico_nome;
    csv += ',' + rows[i].cdr_status_chamada;
    csv += ',' + rows[i].cdr_status_consulta;
    csv += ',' + rows[i].cdr_tipo;
    csv += ',' + rows[i].cdr_tel_discado;
    csv += ',' + rows[i].contato_consulta_id;
    csv += '\n';
  }

  try {
    var date = new Date();
    var dateExport = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "_" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "_" + date.getFullYear() + "_" + ((date.getHours() < 10 ? '0' : '') + date.getHours()) + "_" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

    //Montar parametros para download do arquivo CSV
    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'bilhetes_' + dateExport + '.csv';
    hiddenElement.click();

  } catch (error) {
    //Mostrar o erro ao usuário
    console.log("Error: " + error);
    swal({
      title: "Ops :(",
      text: 'Erro inesperado, contate o administrador',
      type: "error"
    });
  }
}

function gatilhoContMenos() {
  $('#contMais').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();

  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atual').val(1);
    $('#contMenos').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaBilhetes();
  } else if (selectORsearch == 2) {
    buscarBilhetes();
  }
}

function gatilhoContMais() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMais').attr('disabled', true);
    $('#atual').val(valorMaximo);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaBilhetes();
  } else if (selectORsearch == 2) {
    buscarBilhetes();
  }
}

function gatilhoPaginacaoProximo() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atual').val(valorMaximo);
    $('#contMais').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaBilhetes();
  } else if (selectORsearch == 2) {
    buscarBilhetes();
  }
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximo');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atual').val() > page) {
    $('#atual').val(1);
    $('#contMenos').click();
  }
}

function atualizaBilhetes() {
  var xhttp = new XMLHttpRequest();

  var paginationAtual = $('#atual').val();

  var object = {
    pagination: paginationAtual
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          valorMaximoPag(JSON.parse(this.response).contador.resultado);
          addBilhetesNaTabela(JSON.parse(this.response).result);
          break;

        case 304:
          valorMaximoPag(JSON.parse(this.response).contador.resultado);
          addBilhetesNaTabela(JSON.parse(this.response).result);
          break;

        case 500:
          console.log("Erro interno com o servidor.");
          break;

        default:
          console.log("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/select', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addBilhetesNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaBilhetes tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //Data/Hora chamada
    var chamadaCell = newRow.insertCell(count);
    var date = new Date(rows[i].cdr_data_hora_chamada)
    var chamadaValue = document.createTextNode(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}` + ` ${(date.getHours() < 10 ? '0' : '') + date.getHours()}:${(date.getMinutes() < 10 ? '0' : '') + date.getMinutes()}`);
    chamadaCell.appendChild(chamadaValue);
    count++;

    //Data/Hora Consulta
    var consultaCell = newRow.insertCell(count);
    var date = new Date(rows[i].contato_consulta_data_hora)
    var consultaValue = document.createTextNode(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${(date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : ((date.getMonth() + 1))}/${date.getFullYear()}` + ` ${(date.getHours() < 10 ? '0' : '') + date.getHours()}:${(date.getMinutes() < 10 ? '0' : '') + date.getMinutes()}`);
    consultaCell.appendChild(consultaValue);
    count++;

    //Paciente
    var pacienteCell = newRow.insertCell(count);
    var pacienteValue = document.createTextNode(rows[i].contato_paciente_nome);
    pacienteCell.appendChild(pacienteValue);
    count++;

    //Médico
    var medicoCell = newRow.insertCell(count);
    var medicoValue = document.createTextNode(rows[i].contato_medico_nome);
    medicoCell.appendChild(medicoValue);
    count++;

    //Status Chamada
    var statusClienteCell = newRow.insertCell(count);
    var statusClienteValue = document.createTextNode(rows[i].cdr_status_chamada);
    statusClienteCell.appendChild(statusClienteValue);
    count++;

    //Status consulta
    var statusConsultaCell = newRow.insertCell(count);
    var statusConsultaValue = document.createTextNode(rows[i].cdr_status_consulta);
    statusConsultaCell.appendChild(statusConsultaValue);
    count++;

    //Tipo consulta
    var tipoCell = newRow.insertCell(count);
    var tipoValue = document.createTextNode(rows[i].cdr_tipo);
    tipoCell.appendChild(tipoValue);
    count++;

    //Telefone discado
    var telDiscadoCell = newRow.insertCell(count);
    var telDiscadoValue = document.createTextNode(rows[i].cdr_tel_discado);
    telDiscadoCell.appendChild(telDiscadoValue);
    count++;

    //Id consulta
    var idConsultaCell = newRow.insertCell(count);
    var idConsultaValue = document.createTextNode(rows[i].contato_consulta_id);
    idConsultaCell.appendChild(idConsultaValue);
    count++;
  }
}

function buscarBilhetes() {
  $('#selectORsearch').val('2');

  //****************************Data de discagem*************************************/
  //Datas e horas referentes ao filtro
  var inputDataInicioDiscagemBilhetes = $('#dataInicioDiscagemBilhetes').val();
  var inputDataFimDiscagemBilhetes = $('#dataFimDiscagemBilhetes').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioDiscagemBilhetess = null;
  if (!inputDataInicioDiscagemBilhetes.length == 0) {
    inputDataInicioDiscagemBilhetess =
      inputDataInicioDiscagemBilhetes[3] + inputDataInicioDiscagemBilhetes[4] + //mes
      "/" + inputDataInicioDiscagemBilhetes[0] + inputDataInicioDiscagemBilhetes[1] + // dia
      "/" + inputDataInicioDiscagemBilhetes[6] + inputDataInicioDiscagemBilhetes[7] + inputDataInicioDiscagemBilhetes[8] + inputDataInicioDiscagemBilhetes[9]; //ano
  } else {
    inputDataInicioDiscagemBilhetess = '';
  }

  var inputDataFimDiscagemBilhetess = null;
  if (!inputDataFimDiscagemBilhetes.length == 0) {
    inputDataFimDiscagemBilhetess =
      inputDataFimDiscagemBilhetes[3] + inputDataFimDiscagemBilhetes[4] + //mes
      "/" + inputDataFimDiscagemBilhetes[0] + inputDataFimDiscagemBilhetes[1] + // dia
      "/" + inputDataFimDiscagemBilhetes[6] + inputDataFimDiscagemBilhetes[7] + inputDataFimDiscagemBilhetes[8] + inputDataFimDiscagemBilhetes[9]; //ano
  } else {
    inputDataFimDiscagemBilhetess = '';
  }
  //****************************Fim data de discagem**********************************/

  var inputHoraInicioDiscagemBilhetes = $('#horaInicioDiscagemBilhetes').val();
  var inputHoraFimDiscagemBilhetes = $('#horaFimDiscagemBilhetes').val();

  //*****************************Data de consulta*************************************/
  var inputDataInicioConsultaBilhetes = $('#dataInicioConsultaBilhetes').val();
  var inputDataFimConsultaBilhetes = $('#dataFimConsultaBilhetes').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioConsultaBilhetess = null;
  if (!inputDataInicioConsultaBilhetes.length == 0) {
    inputDataInicioConsultaBilhetess =
      inputDataInicioConsultaBilhetes[3] + inputDataInicioConsultaBilhetes[4] + //mes
      "/" + inputDataInicioConsultaBilhetes[0] + inputDataInicioConsultaBilhetes[1] + // dia
      "/" + inputDataInicioConsultaBilhetes[6] + inputDataInicioConsultaBilhetes[7] + inputDataInicioConsultaBilhetes[8] + inputDataInicioConsultaBilhetes[9]; //ano
  } else {
    inputDataInicioConsultaBilhetess = '';
  }

  var inputDataFimConsultaBilhetess = null;
  if (!inputDataFimConsultaBilhetes.length == 0) {
    var inputDataFimConsultaBilhetess =
      inputDataFimConsultaBilhetes[3] + inputDataFimConsultaBilhetes[4] + //mes
      "/" + inputDataFimConsultaBilhetes[0] + inputDataFimConsultaBilhetes[1] + // dia
      "/" + inputDataFimConsultaBilhetes[6] + inputDataFimConsultaBilhetes[7] + inputDataFimConsultaBilhetes[8] + inputDataFimConsultaBilhetes[9]; //ano
  } else {
    inputDataFimConsultaBilhetess = '';
  }
  //****************************Fim data de consulta**********************************/

  var inputHoraInicioConsultaBilhetes = $('#horaInicioConsultaBilhetes').val();
  var inputHoraFimConsultaBilhetes = $('#horaFimConsultaBilhetes').val();

  //paciente
  var inputNomePacienteBilhetes = $('#nomePacienteBilhetes').val();
  var inputTel1PacienteBilhetes = $('#tel1PacienteBilhetes').val();
  var inputTel2PacienteBilhetes = $('#tel2PacienteBilhetes').val();

  //medico
  var inputNomeMedicoBilhetes = $('#nomeMedicoBilhetes').val();

  //status
  var inputStatusChamadaBilhetes = $('#statusChamadaBilhetes').val();
  var inputStatusConsultaBilhetes = $('#statusConsultaBilhetes').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoBilhetes = $('#tipoAtendimentoBilhetes').val();
  var inputTelDiscadoBilhetes = $('#telDiscadoBilhetes').val();

  //Id consulta
  var inputIdConsultaBilhetes = $('#idConsultaBilhetes').val();

  var red_alert_modal = document.getElementById('red-alert_modal');
  red_alert_modal.style.visibility = 'none';

  //Paginação atual da página
  var paginationAtual = $('#atual').val();

  //Não desperdiçar processamento do servidor, validando os campos
  if (inputDataInicioDiscagemBilhetes.length == 0 &&
    inputDataFimDiscagemBilhetes.length == 0 &&

    inputDataInicioConsultaBilhetes.length == 0 &&
    inputDataFimConsultaBilhetes.length == 0 &&

    inputDataInicioConsultaBilhetes.length == 0 &&
    inputDataFimConsultaBilhetes.length == 0 &&

    inputHoraInicioConsultaBilhetes.length == 0 &&
    inputHoraFimConsultaBilhetes.length == 0 &&

    inputNomePacienteBilhetes.length == 0 &&
    inputTel1PacienteBilhetes.length == 0 &&
    inputTel2PacienteBilhetes.length == 0 &&

    inputNomeMedicoBilhetes.length == 0 &&

    inputStatusChamadaBilhetes.length == 0 &&
    inputStatusConsultaBilhetes.length == 0 &&

    inputTelDiscadoBilhetes.length == 0 &&
    inputTipoAtendimentoBilhetes.length == 0 &&

    inputIdConsultaBilhetes.length == 0) {
    return redAlert('Nenhum filtro aplicado.')

  } else {
    //Validar datas para não sobrecarregar o servidor
    validarDatas();

    //criando um objeto para passar como referencia na rota
    var object = {
      dataInicioDiscagemBilhetes: inputDataInicioDiscagemBilhetess,
      dataFimDiscagemBilhetes: inputDataFimDiscagemBilhetess,

      horaInicioDiscagemBilhetes: inputHoraInicioDiscagemBilhetes,
      horaFimDiscagemBilhetes: inputHoraFimDiscagemBilhetes,

      dataInicioConsultaBilhetes: inputDataInicioConsultaBilhetess,
      dataFimConsultaBilhetes: inputDataFimConsultaBilhetess,

      horaInicioConsultaBilhetes: inputHoraInicioConsultaBilhetes,
      horaFimConsultaBilhetes: inputHoraFimConsultaBilhetes,

      nomePacienteBilhetes: inputNomePacienteBilhetes,
      tel1PacienteBilhetes: inputTel1PacienteBilhetes,
      tel2PacienteBilhetes: inputTel2PacienteBilhetes,

      nomeMedicoBilhetes: inputNomeMedicoBilhetes,

      statusChamadaBilhetes: inputStatusChamadaBilhetes,
      statusConsultaBilhetes: inputStatusConsultaBilhetes,

      tipoAtendimentoBilhetes: inputTipoAtendimentoBilhetes,
      telDiscadoBilhetes: inputTelDiscadoBilhetes,

      idConsultaBilhetes: inputIdConsultaBilhetes,

      exportarCSVTrueFalse: false,

      pagination: paginationAtual
    }

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            if (JSON.parse(this.response).contador == 0) {
              $("#totalRegistros").val('0 registros.')
            } else {
              valorMaximoPag(JSON.parse(this.response).contador);
              addBilhetesNaTabela(JSON.parse(this.response).result);
            }
            break;

          case 304:
            if (JSON.parse(this.response).contador == 0) {
              $("#totalRegistros").val('0 registros.')
            } else {
              valorMaximoPag(JSON.parse(this.response).contador);
              addBilhetesNaTabela(JSON.parse(this.response).result);
            }
            break;

          case 500:
            $("#totalRegistros").val('0 registros.')
            redAlert(JSON.parse(this.response).message);
            break;

          default:
            redAlert('Erro inesperado, contate o administrador.');
            break;
        }
      }
    }
    xhttp.open('POST', '/bilhete/search', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
  }
}

function redAlert(message) {
  var success = document.getElementById('red-alert_modal');
  success.innerHTML = message
  success.classList.add('show');
  setTimeout(() => {
    success.classList.remove('show');
  }, 3000);
}

function limparCampos() {
  //Datas e horas referentes ao filtro
  $('#dataInicioDiscagemBilhetes').val('');
  $('#dataFimDiscagemBilhetes').val('');

  $('#horaInicioDiscagemBilhetes').val('');
  $('#horaFimDiscagemBilhetes').val('');

  $('#dataInicioConsultaBilhetes').val('');
  $('#dataFimConsultaBilhetes').val('');

  $('#horaInicioConsultaBilhetes').val('');
  $('#horaFimConsultaBilhetes').val('');

  //paciente
  $('#nomePacienteBilhetes').val('');
  $('#tel1PacienteBilhetes').val('');
  $('#tel2PacienteBilhetes').val('');

  //medico
  $('#nomeMedicoBilhetes').val('');

  //status
  $('#statusChamadaBilhetes').val('');
  $('#statusConsultaBilhetes').val('');

  //tipo de atendimento e telefone discado
  $('#tipoAtendimentoBilhetes').val('');
  $('#telDiscadoBilhetes').val('');

  //id consulta
  $('#idConsultaBilhetes').val('');

  //Valor de paginacao
  $('#valorMaximo').val(1);

  //Atualizar tabela novamente
  atualizaBilhetes();
}

function validarDatas() {
  //************************************* DISCAGEM ***********************************/
  //Datas e horas referentes ao filtro
  var dataInicioDiscagemBilhete = $('#dataInicioDiscagemBilhetes').val();
  var dataFimDiscagemBilhete = $('#dataFimDiscagemBilhetes').val();

  var horaInicioDiscagemBilhete = $('#horaInicioDiscagemBilhetes').val();
  var horaFimDiscagemBilhete = $('#horaFimDiscagemBilhetes').val();

  //VVVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioDiscagemBilhete == '' && horaFimDiscagemBilhete != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemBilhete == '' && dataFimDiscagemBilhete == '') {
      redAlert('É necessário informar ao menos a data de início e hora início!');
      return;
    }
  }

  //VVPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioDiscagemBilhete != '' && horaFimDiscagemBilhete == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemBilhete == '' && dataFimDiscagemBilhete == '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VVPP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioDiscagemBilhete != '' && horaFimDiscagemBilhete != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemBilhete == '' && dataFimDiscagemBilhete == '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioDiscagemBilhete == '' && horaFimDiscagemBilhete == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemBilhete == '' && dataFimDiscagemBilhete != '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioDiscagemBilhete != '' && horaFimDiscagemBilhete == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemBilhete == '' && dataFimDiscagemBilhete != '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioDiscagemBilhete == '' && horaFimDiscagemBilhete != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemBilhete == '' && dataFimDiscagemBilhete != '') {
      redAlert('É necessário informar ao menos a data de início e hora!');
      return;
    }
  }
  //************************************* FIM DISCAGEM *******************************/

  //************************************* CONSULTA ***********************************/
  //Datas e horas referentes ao filtro
  var dataInicioConsultaBilhetes = $('#dataInicioConsultaBilhetes').val();
  var dataFimConsultaBilhetes = $('#dataFimConsultaBilhetes').val();

  var horaInicioConsultaBilhetes = $('#horaInicioConsultaBilhetes').val();
  var horaFimConsultaBilhetes = $('#horaFimConsultaBilhetes').val();

  //VVVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaBilhetes == '' && horaFimConsultaBilhetes != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaBilhetes == '' && dataFimConsultaBilhetes == '') {
      redAlert('É necessário informar ao menos a data de início e hora início!');
      return;
    }
  }

  //VVPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaBilhetes != '' && horaFimConsultaBilhetes == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaBilhetes == '' && dataFimConsultaBilhetes == '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VVPP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaBilhetes != '' && horaFimConsultaBilhetes != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaBilhetes == '' && dataFimConsultaBilhetes == '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaBilhetes == '' && horaFimConsultaBilhetes == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaBilhetes == '' && dataFimConsultaBilhetes != '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaBilhetes != '' && horaFimConsultaBilhetes == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaBilhetes == '' && dataFimConsultaBilhetes != '') {
      redAlert('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (horaInicioConsultaBilhetes == '' && horaFimConsultaBilhetes != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioConsultaBilhetes == '' && dataFimConsultaBilhetes != '') {
      redAlert('É necessário informar ao menos a data de início e hora!');
      return;
    }
  }
  //************************************* FIM CONSULTA *******************************/
}
