const pg = require('../db');
const exec = require('child_process').exec;

module.exports = {
  select: (req, res) => {
    pg.query('SELECT audio_informa, audio_confirma, audio_tentativas, '+
    'audio_agradece, audio_novamente, audio_invalida, ' +
    'audio_confirmada, audio_agradece_part, audio_cancelada, audio_reagendar, audio_alo FROM audio', [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        if (ans.rowCount > 0) {
          return res.send(ans.rows);
        } else {
          return res.send();
        }
      }
    });
  },

  insert: async (req,res) => {
    files = req.files;
    filesName = req.body;

    if (!files) {
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum áudio enviado'
      });
    }

    var { rows } = await pg.queryAsync('SELECT COUNT(*) FROM audio;');

    if (rows[0].count < 1) {
      if (files.audios.length == 11) {
        values = []
        for (var i = 0; i < files.audios.length; i++) {
          values.push(files.audios[i].name.split('.')[0]);
          try {
            //await files.audios[i].mv('/home/filipefirmino/Music/sounds/' + files.audios[i].name)
            await files.audios[i].mv('/opt/leucotron/confirma/sounds/' + files.audios[i].name)
          } catch (error) {
            console.log("\nErro 1: " +error);
            return res.status(500).send({
              error: 'Upload file',
              message: 'Erro ao gravar áudio no servidor'
            });
          }
        }

        try {
          var { rows } = await pg.queryAsync('INSERT INTO audio(audio_informa, audio_confirma, audio_tentativas, '+
          'audio_agradece, audio_novamente, audio_invalida, ' +
          'audio_confirmada, audio_agradece_part, audio_cancelada, audio_reagendar, audio_alo) ' +
          'VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);', values);

          execute('sudo converteAudio.sh', (stdout) => { });
          //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
          return res.status(200).send({
            success: 'Configurado',
            message: 'Áudios configurados com sucesso'
          });
        } catch (error) {
          console.log("\nErro 2: " +error);
          return res.status(500).send({
            error: 'Upload file',
            message: 'Erro ao gravar áudio no servidor'
          });
        }

      } else {
        return res.status(400).send({
          error: 'First submit',
          message: 'Na primeira utilização é necessário enviar todos os áudios'
        });
      }
    } else {
      var sql = await buildQuery(files.audios, filesName)
      try {

        var { rows } = await pg.query(sql);

      } catch (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro interno, por favor contacte o administrador'
        });
      }

      if (files.audios.length === undefined) {
        try {
          await files.audios.mv('/opt/leucotron/confirma/sounds/' + files.audios.name)
          //await files.audios.mv('/home/filipefirmino/Music/sounds/' + files.audios.name)
        } catch (error) {
          console.log("\nErro 3: " +error);
          return res.status(500).send({
            error: 'Upload file',
            message: 'Erro ao gravar áudio no servidor'
          })
        }
      } else {
        for (var i = 0; i < files.audios.length; i++) {
          try {
            await files.audios[i].mv('/opt/leucotron/confirma/sounds/' + files.audios[i].name)
            //await files.audios[i].mv('/home/filipefirmino/Music/sounds/' + files.audios[i].name)
          } catch (error) {
            console.log("\nErro 4: " +error);
            return res.status(500).send({
              error: 'Upload file',
              message: 'Erro ao gravar áudio no servidor'
            });
          }
        }
      }

      execute('sudo converteAudio.sh', (error, stdout) => { });
      //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
      return res.status(200).send({
        success: 'Configurado',
        message: 'Áudio(s) configurado(s) com sucesso'
      });
    }
  }
}

async function buildQuery(files, filesName) {
  var query = null;
  query = 'UPDATE audio SET '

  if (files.length === undefined) {
    query += `${filesName[files.name]} = '${files.name.split('.')[0]}' `
  } else {
    for (var i = 0; i < files.length; i++) {
      if (i < (files.length - 1)){
        query += `${filesName[files[i].name]} = '${files[i].name.split('.')[0]}', `
      }else{
        query += `${filesName[files[i].name]} = '${files[i].name.split('.')[0]}' `
      }
    }
  }
  return query+ 'WHERE audio_id = 1';
}

function execute(command, callback) {
  exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};