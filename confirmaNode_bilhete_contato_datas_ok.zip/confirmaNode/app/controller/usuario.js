const pg = require('../db')
const crypto = require('crypto');

module.exports = {
  validar_usuario: (req, res) => {

    if (!req.body.username && !req.body.password)
    return res.status(400).send()

    var username = req.body.username
    var password = toHash(req.body.password)

    pg.query('SELECT usuario_login FROM usuario WHERE usuario_login = $1', [username], (err, ans) => {

      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else if (ans.rowCount == 1) {
        res.status(401).send({
          error: 'User not allowed',
          message: 'Usuário já existente no sistema.'
        });
      } else {
        pg.query('INSERT INTO usuario(usuario_login,usuario_senha)' +
        'VALUES ($1, $2);', [username, password], (err, ans) => {

          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro interno, por favor contacte o administrador'
            });
          } else {
            res.status(200).send({
              message: 'Usuário cadastrado com sucesso.'
            });
          }
        });
      }
    });
  },

  select: (req, res) => {
    pg.query('SELECT usuario_id, usuario_login FROM usuario', [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  },

  delete: (req, res) => {
    var id = req.body.id

    if (id == req.session.userid){
      res.json({
        message: 'Impossível excluir o usuário com a sessão aberta!'
      });
    }else{
      pg.query('DELETE FROM usuario WHERE usuario_id = $1', [id], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao deletar dados no servidor'
          });
        } else {
          res.json({
            message: 'Usuário excluído!'
          });
        }
      });
    }
  },

  update: (req, res) => {
    var id = req.body.id
    var password = toHash(req.body.password);

    pg.query('UPDATE usuario SET usuario_senha = $1 WHERE usuario_id = $2', [password, id], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao editar dados no servidor'
        })
      } else {
        res.json({
          message: 'Usuário atualizado!'
        })
      }
    })
  }
}

function toHash(data) {

  const hash = crypto.createHash('sha512');

  hash.update(data);

  return hash.digest('hex');
}
