const pg = require('../db');

module.exports = {
  select: (req, res) => {
    var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr,contato WHERE contato_fk = contato_id';
    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        var count = ans.rows[0];

        var pagination = req.body.pagination;

        if (pagination == null || pagination == 1) {
          pagination = 0;
        } else if (pagination > 1) {
          pagination = pagination * 10 - 10;
        }

        var query =
          'SELECT DISTINCT ON (contato_id) contato_id, cdr_id, contato_consulta_data_hora, contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, ' +
          'contato_especialidade,contato_consulta_id, contato_procedimento, contato_outros, contato_cont_discagem, cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo ' +
          'FROM cdr,contato ' +
          'WHERE contato_fk = contato_id ' +
          'ORDER BY contato_id, cdr_id ' +
          'DESC LIMIT 10 OFFSET ' + pagination;
        pg.query(query, [], (err, ans) => {
          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro ao selecionar dados no servidor'
            });
          } else {
            var data = new Object();
            data.contador = count;
            data.result = ans.rows;
            res.json(data);
          }
        });
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      dataInicioConsultaContato: req.body.dataInicioConsultaContatos,
      dataFimConsultaContato: req.body.dataFimConsultaContatos,

      horaInicioConsultaContato: req.body.horaInicioConsultaContatos,
      horaFimConsultaContato: req.body.horaFimConsultaContatos,

      nomePacienteContato: req.body.nomePacienteContatos,
      tel1PacienteContato: req.body.tel1PacienteContatos,
      tel2PacienteContato: req.body.tel2PacienteContatos,

      nomeMedicoContato: req.body.nomeMedicoContatos,

      statusChamadaContato: req.body.statusChamadaContatos,
      statusConsultaContato: req.body.statusConsultaContatos,

      tipoAtendimentoContato: req.body.tipoAtendimentoContatos,
      telDiscadoContato: req.body.telDiscadoContatos,

      idConsultaContato: req.body.idConsultaContatos,

      exportarCSVTF: req.body.exportarCSVTrueFalse
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;
    var queryConsulta = null;
    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null) {
      if (queryPesquisa == 'Data de início é maior que a atual.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      } else if (queryPesquisa == 'Data de início está vazia.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      } else if (queryPesquisa == 'Insira um período de data para busca.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      } else if (queryPesquisa == 'Hora de início de discagem é maior que a de fim.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de discagem é maior que a de fim.'
        });
      } else if (queryPesquisa == 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'
        });
      } else {

        var query = 'SELECT COUNT(DISTINCT(contato_id)) as resultado FROM cdr, contato ' + queryPesquisa + ' AND contato_fk = contato_id;';
        pg.query(query, [], (err, ans) => {
          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro ao selecionar dados no servidor'
            });
          } else {
            var count = ans.rows[0].resultado;

            //Verificar se não tem contato registrado
            if (count == 0) {
              return res.status(500).send({
                contador: count,
                message: 'Nenhum contato registrado!'
              });
            } else {

              var pagination = req.body.pagination;

              if (pagination == null || pagination == 1) {
                pagination = 0;
              } else if (pagination > 1) {
                pagination = pagination * 10 - 10;
              }

              if (object.exportarCSVTF) {
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_id, contato_consulta_data_hora, ' +
                  'contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, ' +
                  'contato_especialidade, contato_procedimento,contato_consulta_id, contato_outros, contato_cont_discagem, ' +
                  'cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo ' +
                  'FROM cdr, contato ' + queryPesquisa + ' AND contato_fk = contato_id ' +
                  'ORDER BY contato_id, cdr_id ;';

                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    res.json(ans.rows);
                  }
                });
              } else {
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_id, contato_consulta_data_hora, ' +
                  ' contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, ' +
                  'contato_especialidade, contato_procedimento,contato_consulta_id, contato_outros, contato_cont_discagem, ' +
                  'cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo ' +
                  'FROM cdr, contato ' + queryPesquisa + ' AND contato_fk = contato_id ' +
                  'ORDER BY contato_id, cdr_id ' +
                  'DESC LIMIT 10 OFFSET ' + pagination;

                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    var data = new Object();
                    data.contador = count;
                    data.result = ans.rows;
                    res.json(data);
                  }
                });
              }
            }
          }
        });
      }

    } else {
      var query = 'SELECT COUNT(DISTINCT(contato_id)) as resultado FROM cdr, contato WHERE contato_fk = contato_id;';
      pg.query(query, [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao selecionar dados no servidor'
          });
        } else {
          var count = ans.rows[0].resultado;

          //Verificar se não tem contato registrado
          if (count == 0) {
            return res.status(500).send({
              contador: count,
              message: 'Nenhum contato registrado!'
            });
          } else {

            var pagination = req.body.pagination;

            if (pagination == null || pagination == 1) {
              pagination = 0;
            } else if (pagination > 1) {
              pagination = pagination * 10 - 10;
            }

            if (object.exportarCSVTF) {
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_id, contato_consulta_data_hora, ' +
                'contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, ' +
                'contato_especialidade, contato_procedimento,contato_consulta_id, contato_outros, contato_cont_discagem, ' +
                'cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo ' +
                'FROM cdr, contato WHERE contato_fk = contato_id ' +
                'ORDER BY contato_id, cdr_id;';

              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  res.status(200).send(ans.rows);
                }
              });
            } else {
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_id, contato_consulta_data_hora, ' +
                'contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, ' +
                'contato_especialidade, contato_procedimento,contato_consulta_id, contato_outros, contato_cont_discagem, ' +
                'cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo ' +
                'FROM cdr, contato WHERE contato_fk = contato_id ' +
                'ORDER BY contato_id, cdr_id ' +
                'DESC LIMIT 10 OFFSET ' + pagination;

              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  var data = new Object();
                  data.contador = count;
                  data.result = ans.rows;
                  res.json(data);
                }
              });
            }
          }
        }
      });
    }
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item) {
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //*******************************consulta***************************************
  //PVPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato == '') {
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioConsultaContato;
      var date = new Date();
      var horaFim = ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ":" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data fim
      var dataFimConsultaContato = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //PVPP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioConsultaContato;
      var horaFim = item.horaFimConsultaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimConsultaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimConsultaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataHoraFim + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //PPPP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato != '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioConsultaContato;
      var horaFim = item.horaFimConsultaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimConsultaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimConsultaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //PPPV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato != '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioConsultaContato;

      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimConsultaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimConsultaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //PPVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato == '' && item.horaFimConsultaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato != '') {
      //Hora de fim
      var horaFim = item.horaFimConsultaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data Fim
      var dateFim = new Date(item.dataFimConsultaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimConsultaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //PVVP (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato == '' && item.horaFimConsultaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == '') {
      //Hora de fim
      var horaFim = item.horaFimConsultaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data Fim
      var dateFim = new Date();//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimConsultaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //PVVV (Data Inicio, Data Fim, Hora Inicio, Hora Fim)
  if (item.horaInicioConsultaContato == '' && item.horaFimConsultaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == '') {
      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data fim
      var date = new Date();
      var dataFimConsultaContato = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas. (PPVV)
    } else if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato != '') {
      //Data Inicio
      var dateInicio = new Date(item.dataInicioConsultaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioConsultaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data Inicio
      var dateFim = new Date(item.dataFimConsultaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimConsultaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioConsultaContato).valueOf();
      var fim = new Date(dataFimConsultaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        } else {
          query += 'contato_consulta_data_hora BETWEEN ' + "'" + dataInicioConsultaContato + "'" + ' AND ' + "'" + dataFimConsultaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    } else if (item.dataInicioConsultaContato == '' && item.dataFimConsultaContato != '') {
      return 'Data de início está vazia.';
    }
  }
  //********Fim data e hora de consulta do contato******************************

  //Validação Paciente
  if (item.nomePacienteContato != '') {
    if (count > 0) {
      query += ' AND contato_paciente_nome ILIKE ' + "'%" + item.nomePacienteContato + "%'";
    } else {
      query += 'contato_paciente_nome ILIKE ' + "'%" + item.nomePacienteContato + "%'";
    }
    count++;
  }

  //Validação telfone 1
  if (item.tel1PacienteContato != '') {
    if (count > 0) {
      query += ' AND contato_paciente_tel1 ILIKE ' + "'%" + item.tel1PacienteContato + "%'";
    } else {
      query += 'contato_paciente_tel1 ILIKE ' + "'%" + item.tel1PacienteContato + "%'";
    }
    count++;
  }

  //Validação telfone 2
  if (item.tel2PacienteContato != '') {
    if (count > 0) {
      query += ' AND contato_paciente_tel1 ILIKE ' + "'%" + item.tel2PacienteContato + "%'";
    } else {
      query += 'contato_paciente_tel2 ILIKE ' + "'%" + item.tel2PacienteContato + "%'";
    }
    count++;
  }

  //Validação médico
  if (item.nomeMedicoContato != '') {
    if (count > 0) {
      query += ' AND contato_medico_nome ILIKE ' + "'%" + item.nomeMedicoContato + "%'";
    } else {
      query += 'contato_medico_nome ILIKE ' + "'%" + item.nomeMedicoContato + "%'";
    }
    count++;
  }

  //Validação Status chamada
  if (item.statusChamadaContato != '') {
    if (count > 0) {
      query += ' AND cdr_status_chamada ILIKE ' + "'%" + item.statusChamadaContato + "%'";
    } else {
      query += 'cdr_status_chamada ILIKE ' + "'%" + item.statusChamadaContato + "%'";
    }
    count++;
  }

  //Validação Status consulta
  if (item.statusConsultaContato != '') {
    if (count > 0) {
      query += ' AND cdr_status_consulta ILIKE ' + "'%" + item.statusConsultaContato + "%'";
    } else {
      query += 'cdr_status_consulta ILIKE ' + "'%" + item.statusConsultaContato + "%'";
    }
    count++;
  }

  //Validação Telefone Discado
  if (item.telDiscadoContato != '') {
    if (count > 0) {
      query += ' AND cdr_tel_discado ILIKE ' + "'%" + item.telDiscadoContato + "%'";
    } else {
      query += 'cdr_tel_discado ILIKE ' + "'%" + item.telDiscadoContato + "%'";
    }
    count++;
  }

  //Validação id consulta
  if (item.idConsultaContato != '') {
    if (count > 0) {
      query += ' AND contato_consulta_id = ' + "'" + item.idConsultaContato + "'";
    } else {
      query += 'contato_consulta_id = ' + "'" + item.idConsultaContato + "'";
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}
