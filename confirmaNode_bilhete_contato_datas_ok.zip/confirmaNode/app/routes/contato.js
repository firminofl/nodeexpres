var express = require('express');
var router = express.Router();
var contatos_controller = require('../controller/contatos');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Mostrar todos os registros na tabela
router.post('/select', contatos_controller.select);

//Mostrar os registros com filtro na tabela
router.post('/search', contatos_controller.search);
module.exports = router;
