const pg = require('../db');
module.exports = {
    select: (req, res) => {
        //Buscar todas as informações referente as campanhas, contatos e cdr para exportar
        var queryTudo = 'SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id;';

        pg.query(queryTudo, [], (err, ans) => {
            if (err) {
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                });
            } else {
                //Montar um objeto JSON para enviar para o front-end
                var object = {
                    data: ans.rows
                }
                res.json(object);
            }
        });
    },

    delete: (req, res) => {
        //Query para deletar os dados da base
        var queryDeleteTudo =
            'DELETE FROM contato; ' +
            'DELETE FROM cdr; ' +
            'DELETE FROM campanha; ' +
            'DELETE FROM status;';

        pg.query(queryDeleteTudo, [], (err, ans) => {
            if (err) {
                console.log("Error: "+err);
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                });
            } else {
                //Retornar sucesso da exclusao no front-end                
                res.status(200).send();
            }
        });
    }
}