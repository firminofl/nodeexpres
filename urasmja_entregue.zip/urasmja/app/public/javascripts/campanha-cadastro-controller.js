function atualizaCampanha() {
  var xhttp = new XMLHttpRequest();

  var paginationAtual = $('#atual').val();

  var object = {
    pagination: paginationAtual
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          valorMaximoPag(JSON.parse(this.response).contador.count);
          addElementsToTable(JSON.parse(this.response).result);
          break;

        case 304:
          valorMaximoPag(JSON.parse(this.response).contador.count);
          addElementsToTable(JSON.parse(this.response).result);
          break;

        case 500:
          setTimeout(() => {
            $("#totalRegistros").val('0 registros.')
            alertFormTable(JSON.parse(this.response).message);
          }, 2000);
          break;

        default:
          setTimeout(() => {
            $("#totalRegistros").val('0 registros.')
            alertFormTable(JSON.parse(this.response).message);
          }, 2000);
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/select', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addElementsToTable(rows) {
  //Pegar referencia da tabela de campanhas
  const table = document.querySelector('#tabelaCampanha tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i)
    var count = 0

    var actionCell = newRow.insertCell(count)

    //Celula do nome da campanha
    var nomeCampanhaCell = newRow.insertCell(count)
    var nomeCampanhaValue = document.createTextNode(rows[i].campanha_nome)
    nomeCampanhaCell.appendChild(nomeCampanhaValue)
    count++;

    //Celula do nome do audio
    var nomeAudioCell = newRow.insertCell(count)
    var nomeAudioValue = document.createTextNode(rows[i].campanha_audio)
    nomeAudioCell.appendChild(nomeAudioValue)
    count++;

    // botao excluir
    var excluirCell = newRow.insertCell(count)
    var excluirElement = document.createElement('input')
    excluirElement.setAttribute('type', 'button')
    excluirElement.setAttribute('value', 'Excluir')
    excluirElement.classList.add('btn')
    excluirElement.classList.add('btn-outline')
    excluirElement.classList.add('btn-danger')
    excluirElement.classList.add('dim')
    excluirElement.onclick = deleteItem(rows[i])
    excluirCell.appendChild(excluirElement)
    count++;
  }
}

function deleteItem(item) {
  return function () {

    var xhttp = new XMLHttpRequest();
    xhttp.open('POST', '/campanha/delete')

    var object = {
      campanha_id: item.campanha_id
    }

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            sucessFormTable(JSON.parse(this.response).message);
            setTimeout(() => {
              location.reload();
            }, 1200);
            break;

          case 304:
            sucessFormTable(JSON.parse(this.response).message);
            setTimeout(() => {
              location.reload();
            }, 1200);
            break;

          case 400:
            alertFormTable(JSON.parse(this.response).message);
            break;

          case 500:
            alertFormTable(JSON.parse(this.response).message);
            break;

          case 404:
            alertFormTable('Não foi possível alcançar o servidor');
            break;

          default:
            alertFormTable('Erro inesperado, contate o administrador');
            break;
        }
      }
    }
    xhttp.setRequestHeader('Content-Type', 'application/json')
    xhttp.send(JSON.stringify(object));
  }
}

function salvarCampanha(campanha) {

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          //Fazer update na tupla salva do formulario para o nome do audio e  movê-lo para o diretorio interna da BBB
          validarImportacao();
          break;

        case 304:
          //Fazer update na tupla que salva do formulario para o nome do audio e  movê-lo para o diretorio interna da BBB
          validarImportacao();
          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          break;

        case 404:
          alertForm('Não foi possível alcançar o servidor');
          break;

        case 200:
          window.open("/", "_self");
          break;

        default:
          alertForm('Erro inesperado, contate o administrador');
          break;
      }
    }
  }
  xhttp.open("POST", '/campanha/insert', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(campanha));
}

function validarCampanha() {
  var nomeCampanha = $("#nomeCampanha").val();
  var tentativasDiscagem = $("#tentativasDiscagem").val();
  var intervaloDiscagens = $("#intervaloDiscagens").val();
  var chamadaSimultaneas = $("#chamadaSimultaneas").val();
  var red_alert = document.getElementById('red_alert');

  red_alert.style.visibility = 'none';

  //Validando o campo nome da campanha
  if (nomeCampanha == "" || nomeCampanha == null) {
    alertForm('Nome da campanha não pode estar vazio!');
    return false;
  }

  //Tentativas de discagem
  if (tentativasDiscagem == '' || tentativasDiscagem > 9 || tentativasDiscagem < 1) {
    alertForm('Campo de tentativas de discagem não está preenchido corretamente!');
    return false;
  }

  //Intervalo de horas entre discagens
  if (intervaloDiscagens == '' || intervaloDiscagens > 4 || intervaloDiscagens < 1) {
    alertForm('Campo de intervalo de discagens não está preenchido corretamente!');
    return false;
  }

  //Quantidade de chamadas simultaneas
  if (chamadaSimultaneas == '' || chamadaSimultaneas > 8 || chamadaSimultaneas < 1) {
    alertForm('Campo de chamadas simultâneas não está preenchido corretamente!');
    return false;
  }

  var object = {
    nomeCampanha: nomeCampanha,
    tentativasDiscagem: tentativasDiscagem,
    intervaloDiscagens: intervaloDiscagens,
    chamadaSimultaneas: chamadaSimultaneas
  }
  //Salvar os dados de formulario que contem somente textos e numeros
  salvarCampanha(object);
}

function validarImportacao() {

  const importaContatos = document.getElementById('importaContatosExterno');
  var formData = new FormData();

  var audioCampanha = document.getElementById('audioCampanha');

  //Validar se foram enviados os arquivos de áudio e contatos
  if (importaContatos.files[0] === undefined && audioCampanha.files[0] === undefined) {
    alertForm('Nenhum arquivo CSV e de áudio foram escolhidos');
    return false;
    //Validar se enviou o arquivo de áudio
  } else if (audioCampanha.files[0] === undefined) {
    alertForm('Nenhum arquivo de áudio foi escolhido');
    return false;
    //Arquivo de áudio foi enviado
  } else if (audioCampanha.files[0]) {
    formData.append('audioCampanha', audioCampanha.files[0], audioCampanha.files[0].name);
  }

  //Validar se enviou o arquivo de contatos
  if (importaContatos.files[0] === undefined) {
    alertForm('Nenhum arquivo CSV foi escolhido');
    return false;
    //Arquivo de contatos foi enviado
  } else if (importaContatos.files[0]) {
    formData.append('importaContatos', importaContatos.files[0], importaContatos.files[0].name);
  }

  var xhttp = new XMLHttpRequest()

  xhttp.open('POST', '/campanha/insertContatos', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          sucessForm(JSON.parse(this.response).message);
          setTimeout(() => {
            location.reload();
          }, 1200);
          break;

        case 304:
          sucessForm(JSON.parse(this.response).message);
          setTimeout(() => {
            location.reload();
          }, 1200);
          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          break;

        case 408:
          swal("Opss!\n:'(", JSON.parse(this.response).message, "error");
          break;

        case 404:
          alertForm('Não foi possível alcançar o servidor');
          break;

        default:
          alertForm('Erro inesperado, contate o administrador');
          break;
      }
    }
  }

  xhttp.send(formData);
}

function validarAudio() {
  var audioCampanha = document.getElementById('audioCampanha');
  var formData = new FormData();

  if (audioCampanha.files[0]) {
    formData.append('audioCampanha', audioCampanha.files[0], audioCampanha.files[0].name);
    formData.append(audioCampanha.files[0].name, 'campanha_audio');
  }

  var xhttp = new XMLHttpRequest()

  xhttp.open('POST', '/campanha/insertAudio', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && (this.status == 200 || this.status == 304)) {
      sucessForm(JSON.parse(this.response).message);
      setTimeout(() => {
        location.reload();
      }, 1200);
    } else if (this.readyState == 4 && (this.status != 200 || this.status != 304)) {
      alertForm(JSON.parse(this.response).message);
    }
  }

  xhttp.send(formData);
}

function exportarCSV() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/campanha/export', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 304:
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 500:
          alertFormTable(JSON.parse(this.response).message);
          break;

        default:
          alertFormTable('Erro inesperado, contate o administrador.');
          break;
      }
    }
  }
  xhttp.send();
}

function montarExportarTabelaCSV(rows) {
  //Mostrar que o processo pode demorar
  swal({
    title: "Exportar CSV",
    text: "Este processo pode demorar um tempo!"
  });

  var csv = 'Nome campanha, Nome áudio, Tentativas discagem, Intervalo discagem, Chamadas simultâneas, Total contatos, Data/Hora criada\n';

  for (var i = 0; i < rows.length; i++) {
    csv += rows[i].campanha_nome;
    csv += ',' + rows[i].campanha_audio;
    csv += ',' + rows[i].campanha_num_tentativa;
    csv += ',' + rows[i].campanha_intervalo_discagem + " hora(s)";
    csv += ',' + rows[i].campanha_chamadas_simultaneas;
    csv += ',' + rows[i].campanha_total_contatos;

    var date = new Date(rows[i].campanha_data_hora_criada)
    csv += ',' + (date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear() + " " + (date.getHours() < 10 ? '0' : '') + date.getHours() + ":" + (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
    csv += '\n';
  }

  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'campanha.csv';
  hiddenElement.click();
}

function setFileName(element) {
  var div = element.parentElement;
  var childs = div.childNodes;

  var label = undefined;

  for (var i = 0; i < childs.length; i++) {
    if (childs[i].nodeName === 'LABEL') {
      label = childs[i];
      break;
    }
  }

  if (element.files[0] === undefined) {
    return label.innerHTML = 'Não selecionado';
  }

  var file = element.files[0];

  if (element.files[0].name.split('.')[0].length > 20) {
    alertForm('Nome do arquivo CSV para contatos não deve passar de 20 caracteres');
    label.innerHTML = 'Não selecionado';
    element.value = '';
    return;
  }

  if (label && file) {
    label.innerHTML = element.files[0].name;
    swal("Atenção", "Dependendo do tamanho do arquivo, pode demorar um pouco para salvar a campanha", "warning");
  } else {
    alertForm('Por favor, selecione apenas arquivo CSV para importar os contatos ' +
      'com o formato de csv.');
    label.innerHTML = 'Não selecionado';
    element.value = '';
  }
}

function setAudioName(element) {
  var div = element.parentElement;
  var childs = div.childNodes;

  var label = undefined;
  var file = element.files[0];

  //Verifica se contem algum caracter especial no nome do audio.
  //Letras minusculas e maiusculas, ponto, underscore, e o numero 3 pode passar na validação
  if (file.name.match(/[^a-zA-Z._\S3]/g)) {
    alertForm("Nome do áudio não é válido, talvez contenha caracteres especiais");
    return false;
  } else {
    //Verifica o tamanho do arquivo e vê se é maior que 3 MB
    if (element.files[0].size / 1024 / 1024 > 3) {
      alertForm("Tamanho do arquivo de áudio não pode exceder 3 MB");
      return false;
    } else {
      //Caso o nome e o tamanho estejam OK
      for (var i = 0; i < childs.length; i++) {
        if (childs[i].nodeName === 'LABEL') {
          label = childs[i];
          break;
        }
      }

      if (element.files[0] === undefined) {
        return label.innerHTML = 'Não selecionado';
      }

      if (element.files[0].name.split('.')[0].length > 20) {
        alertForm('Nome do arquivo de áudio não deve passar de 20 caracteres');
        label.innerHTML = 'Não selecionado';
        element.value = '';
        return;
      }

      if (label && file && (file.type.includes('gsm') ||
        file.type.includes('wav') ||
        file.type.includes('mp3'))) {

        label.innerHTML = element.files[0].name;

      } else {
        alertForm('Por favor, selecione apenas arquivos de áudios ' +
          'com o formato de gsm, mp3 ou wav.');
        label.innerHTML = 'Não selecionado';
        element.value = '';
      }
    }
  }
}

function alertFormTable(message) {
  var red_alert = document.getElementById('red_alert_table');
  red_alert.style.visibility = 'none';
  red_alert.innerHTML = message;
  red_alert.classList.add('show')
  setTimeout(() => {
    red_alert.classList.remove('show')
  }, 5000);
}

function sucessFormTable(message) {
  var red_alert = document.getElementById('success_campanha_table');
  red_alert.style.visibility = 'none';
  red_alert.innerHTML = message;
  red_alert.classList.add('show')
  setTimeout(() => {
    red_alert.classList.remove('show')
  }, 2200);
}

function alertForm(message) {
  var red_alert = document.getElementById('red_alert');
  red_alert.style.visibility = 'none';
  red_alert.innerHTML = message;
  red_alert.classList.add('show')
  setTimeout(() => {
    red_alert.classList.remove('show')
  }, 5000);
}

function sucessForm(message) {
  var red_alert = document.getElementById('success_campanha');
  red_alert.style.visibility = 'none';
  red_alert.innerHTML = message;
  red_alert.classList.add('show')
  setTimeout(() => {
    red_alert.classList.remove('show')
  }, 5000);
}

function gatilhoContMenos() {
  $('#contMais').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();

  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atual').val(1);
    $('#contMenos').attr('disabled', true);
  }

  atualizaCampanha();
}

function gatilhoContMais() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMais').attr('disabled', true);
    $('#atual').val(valorMaximo);
  }

  atualizaCampanha();
}

function gatilhoPaginacaoProximo() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atual').val(valorMaximo);
    $('#contMais').attr('disabled', true);
  }

  atualizaCampanha();
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximo');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atual').val() > page) {
    $('#atual').val(1);
    $('#contMenos').click();
  }
}
