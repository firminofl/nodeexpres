function sendCredentials() {

  var username = document.getElementById('inputUsername').value;
  var password = document.getElementById('inputPassword').value;
  var alert = document.getElementById('red-alert');

  alert.style.visibility = 'none'

  if (username == '' || password == '') {
    return;
  }

  var object = new Object();
  object.username = username;
  object.password = password;

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 400:
        break;

        case 401:
        alert.innerHTML = 'Usuário ou senha inválidos';
        alert.removeAttribute('hidden');
        break;

        case 500:
        alert.innerHTML = 'Erro interno com o servidor';
        alert.removeAttribute('hidden');
        break;

        case 404:
        alert.innerHTML = 'Não foi possível alcançar o servidor';
        alert.removeAttribute('hidden');
        break;

        case 200:
        window.open("/", "_self");
        break;
        default:
        alert.innerHTML = 'Erro inesperado, contate o administrador'
        alert.removeAttribute('hidden');
      }
    }
  }

  xhttp.open("POST", '/users/signin', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}
