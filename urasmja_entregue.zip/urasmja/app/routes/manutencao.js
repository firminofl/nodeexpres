var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate');
var manutencao_controller = require('../controller/manutencao')

router.use(authenticate.apiAuth);

//Buscar campanha, contato, status, cdr
router.get('/select', manutencao_controller.select);

//Apagar campanha, contato, status, cdr
router.get('/delete', manutencao_controller.delete);

module.exports = router;