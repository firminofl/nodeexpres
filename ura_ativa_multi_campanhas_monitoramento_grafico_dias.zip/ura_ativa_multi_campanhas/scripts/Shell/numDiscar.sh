#!/bin/bash
#+---------------------------------------------------------------------------------------------------------------+
#|Descrição: Recebe o numero do dialplan, trata e retorna ao dialplan                                            |
#+---------------------------------------------------------------------------------------------------------------+
#|Teste: ./numDiscar.sh 'numero'                                                                                 | 
#+---------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                      |
#|Data: 09/01/2019                                                                                               |
#+---------------------------------------------------------------------------------------------------------------+

_8_digitos(){
 if [[ ${TEL:0:1} =~ [6-9] ]]
 then
  echo -n "9${TEL}"
 elif [[ ${TEL:0:1} =~ [2-5] ]]
 then
  echo -n "${TEL}"
 else
  echo -n "${TEL}"
#  echo -n "nok"
 fi
}

_10_digitos(){
 if [[ ${TEL:0:3} =~ 24[6-9] ]]
 then
  echo -n "9${TEL:2}"
 elif [[ ${TEL:0:3} =~ 24[2-5] ]]
 then
  echo -n "${TEL:2}"
 elif [[ ${TEL:0:3} =~ [1-9][1-9][6-9] ]]
 then
  echo -n "0${TEL:0:2}9${TEL:2}"
 elif [[ ${TEL:0:3} =~ [1-9][1-9][2-5] ]]
 then
  echo -n "0${TEL}"
 else
#  echo -n "nok"
  echo -n "${TEL}"
 fi
}

_11_digitos(){
 if test ${TEL:0:3} -eq 249
 then
  echo -n "${TEL:2}"
 elif [[ ${TEL:0:4} =~ 024[6-9] ]]
 then
  echo -n "9${TEL:3}"
 elif [[ ${TEL:0:4} =~ 024[2-5] ]]
 then
  echo -n "${TEL:3}"
 elif [[ ${TEL:0:4} =~ 0[1-9][1-9][6-9] ]]
 then
  #echo -n "031${TEL:1}"
  echo -n "0${TEL:1:2}9${TEL:3}"
 elif [[ ${TEL:0:4} =~ 0[1-9][1-9][2-5] ]]
 then
  echo -n "0${TEL:1}"
 elif [[ ${TEL:0:3} =~ [1-9][1-9][6-9] ]]
 then
  echo -n "0${TEL}"
 else
#  echo -n "nok"
  echo -n "${TEL}"
 fi
}

_12_digitos(){
 if test ${TEL:0:4} -eq 0249
 then
  echo -n "${TEL:3}"
 elif [[ ${TEL:0:4} =~ 0[1-9][1-9][6-9] ]]
 then
  echo -n "0${TEL:1}"
 elif [[ ${TEL:0:4} =~ 0[1-9][1-9][2-5] ]]
 then
  echo -n "0${TEL:1}"
 else
#  echo -n "${TEL}"
  echo -n "${TEL}"
 fi
}

#Programa ao ser executado inicia por aqui
TEL=$(echo "$1" | sed 's/[^0-9]//g')
_main(){
 case ${#TEL} in
      '8')
         _8_digitos
         ;;
      '10')
         _10_digitos
         ;;
      '11')
         _11_digitos
         ;;
      '12')
         _12_digitos
         ;;
      *)
         echo -n "${TEL}"
         exit
         ;;
 esac
}
_main
