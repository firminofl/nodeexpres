#!/bin/bash
#+---------------------------------------------------------------------------------------------------------------+
#|date +%w: retorna o dia da semana sendo:                                                                       |
#|0-Domingo, 1-Segunda, 2-Terça, 3-Quarta, 4-Quinta, 5-Sexta e 6-Sábado                                          |
#|date +%H%M: retorna hora e minuto do sistema de forma concatenada.                                             |
#+---------------------------------------------------------------------------------------------------------------+
#|Descrição: Discador para Asterisk integrado com banco de dados Postgresql 9.3                                  |
#| - Script realiza uma busca diaria ao BD remoto a fim de obter os contatos a serem discadod durante o dia.     |
#+---------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                      |
#|Data: 14/05/2019                                                                                               |
#+---------------------------------------------------------------------------------------------------------------+

#*********************Variaveis globais de controle*********************

#Parâmetro de entrada (start/stop)
OPCAO="$1"

export PGPASSWORD="sml3uc0"
DBUSER="postgres"
DBNAME="ura"
DBTABLECONTATO="contato"
DBTABLEFERIADO="feriado"
DBTABLELOG="log"
DBTABLESEMANA="dia_semana"
DBTABLECAMPANHA="campanha"
DBTABLESTATUS="status"
DBTABLECONFIG="configuracao"
#Quantidade minima de digitos esperado que os tel1 e tel2 possuam
QTD_DG_TEL=8

#Parametros flexiveis. Traz do BD.
CONF=$(echo "SELECT * FROM ${DBTABLECONFIG};" | psql -t -d ura -U postgres | xargs)

#Limite de discagens para o mesmo contato
CALL_LIMIT=$(echo ${CONF} | awk -F '|' '{ print $2 }' | xargs)
#Intervalo minimo de horas entre discagens
INTERVAL=$(echo ${CONF} | awk -F '|' '{ print $3 }' | xargs)
#Chamadas simultaneas
CHANNLIMIT=$(echo ${CONF} | awk -F '|' '{ print $4 }' | xargs)

#*********************Functions*********************

#Se RETURN=1 data analisada esta na tabela de feriado
validaFeriado(){
	local RETURN=0
	local DATA=$(echo "$(date +%m-%d)")
	local FERIADO=$(echo "SELECT * FROM "${DBTABLEFERIADO}" WHERE to_char(feriado_data, 'MM-DD') = '${DATA}';" | psql -t -d "${DBNAME}" -U "${DBUSER}" | xargs)
	
	#-n testa se retorno != null
	if [ -n "${FERIADO}" ]
	then
		RETURN=1
	fi

	echo "${RETURN}"
}

#Se RETURN=1 dia esta ativo e dentro do horario de discagem
validaDiaHora(){
    local RETURN=0
	local DSEMANA=$(echo `date +%w`)
	local HORA=$(echo `date +%H%M`)
	local DADOS_DIA=$(echo "SELECT * FROM ${DBTABLESEMANA} WHERE dia_semana_ativo = TRUE AND dia_semana_dia = '${DSEMANA}';" | psql -t -d ${DBNAME} -U ${DBUSER})

	#-n testa se retorno != null
	if [ -n "${DADOS_DIA}" ]
	then
		local HORA_INI=$(echo "${DADOS_DIA}" | awk -F '|' '{ print $3 }' | xargs)
		local HORA_FIM=$(echo "${DADOS_DIA}" | awk -F '|' '{ print $4 }' | xargs)
		if [ ${HORA} -ge ${HORA_INI} -a ${HORA} -le ${HORA_FIM} ]
		then
			RETURN=1
		fi
	fi

    echo "${RETURN}"
}

#populaTabelaContato(){
#	#Verifica na tabela log se ha registro com a data atual em caso de positivo, nao executa a aplicacao que popula a tabela contato novamente.
#	local DATA=$(echo "$(date +%Y-%m-%d)")
#	local TOTAL=$(echo "SELECT * FROM ${DBTABLELOG} WHERE data_hora_exe_query::DATE = '${DATA}';"| psql -t -d ${DBNAME} -U ${DBUSER})
#	#-z testa se retorno == null
#	if [ -z "${TOTAL}" ]
#	then
#		echo "DELETE FROM ${DBTABLECONTATO};" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
#		local TOTAL=$(bash select_bd_remoto.sh | wc -l)
#		echo "INSERT INTO ${DBTABLELOG}(total_consultas) VALUES ('${TOTAL}');" | psql -t -d ${DBNAME} -U ${DBUSER} >> /dev/null
#		local CONTATO=""
#		bash select_bd_remoto.sh | while read CONTATO
#		do
			#Testa se fim de lista de contatos
			#-n testa se retorno != null
#			if [ -n "${CONTATO}" ]
#			then
#				local ID_CONSULTA=$(echo "${CONTATO}" | awk -F '|' '{ print $2 }' | xargs)
#				local ID_PACIENTE=$(echo "${CONTATO}" | awk -F '|' '{ print $3 }' | xargs)
#				local NOME_PACIENTE=$(echo "${CONTATO}" | awk -F '|' '{ print $4 }' | xargs)
#				local TEL_1=$(echo "${CONTATO}" | awk -F '|' '{ print $5 }'| xargs)
#				local TEL_2=$(echo "${CONTATO}" | awk -F '|' '{ print $6 }'| xargs)
#				local DATA_HORA_CONSULTA=$(echo "${CONTATO}" | awk -F '|' '{ print $7 }' | xargs)
#				local ID_DENTISTA=$(echo "${CONTATO}" | awk -F '|' '{ print $8 }'| xargs)
#				local NOME_DENTISTA=$(echo "${CONTATO}" | awk -F '|' '{ print $9 }' | xargs)
#				echo "INSERT INTO ${DBTABLECONTATO}(id_consulta, id_paciente, nome_paciente, tel_1, tel_2, data_hora_consulta, id_dentista, nome_dentista) VALUES ('${ID_CONSULTA}', '${ID_PACIENTE}', '${NOME_PACIENTE}', '${TEL_1}', '${TEL_2}', '${DATA_HORA_CONSULTA}', '${ID_DENTISTA}', '${NOME_DENTISTA}');" | psql -t -d ${DBNAME} -U ${DBUSER} >> /dev/null
#			fi
#		done
#	fi
#}

dialCore(){
#Testa se ainda esta dentro do dia e horario de discagem
local DIA_HORA=$(validaDiaHora)
if [ "${DIA_HORA}" -eq 1 ]
then
	#Testa qtd de canais utilizado pelo Confirmador
	local NCALLSLOCAL=$(sudo asterisk -rx "group show channels DISCADOR" | egrep "active" | awk '{ print $1 }')
	if [ "${NCALLSLOCAL}" -lt "${CHANNLIMIT}" ]
	then
		local CANAISLIVRES=$(expr ${CHANNLIMIT} - ${NCALLSLOCAL})
		echo "SELECT cont.contato_id, cont.contato_nome, cont.contato_tel1, cont.contato_tel2, cont.contato_outros, TO_CHAR(CURRENT_TIMESTAMP - cont.contato_data_hora_discagem, 'HH24'), cont.contato_cont_discagem, c.campanha_id, c.campanha_nome, c.campanha_audio, c.campanha_op1, c.campanha_op2, c.campanha_op3, c.campanha_op4, c.campanha_op5, c.campanha_op6, c.campanha_op7, c.campanha_op8, c.campanha_op9  from ${DBTABLECAMPANHA} AS c LEFT JOIN ${DBTABLESTATUS} AS s ON c.campanha_id = s.campanha_fk LEFT JOIN ${DBTABLECONTATO} AS cont ON c.campanha_id = cont.campanha_fk WHERE s.ativado IS TRUE AND s.pausado IS FALSE AND s.parado IS FALSE AND cont.contato_excluido IS FALSE AND cont.contato_cont_discagem <= ${CALL_LIMIT} ORDER BY RANDOM() LIMIT ${CANAISLIVRES};" | psql -t -d ${DBNAME} -U ${DBUSER} | while read NUMBER
		do
		#Testa se fim de lista de contatos
        #-n testa se retorno != null
	        if [ -n "${NUMBER}" ]
    	    then
				local CAMPANHA_ID=$(echo "${NUMBER}" | awk -F '|' '{ print $8 }' | xargs)
				#Testa se campanha ativa e nao parada
				CAMPANHA_STATUS=$(echo "SELECT * FROM campanha AS c LEFT JOIN status AS s ON s.status_id = s.campanha_fk WHERE s.ativado IS TRUE AND s.pausado IS FALSE AND s.parado IS FALSE AND campanha_id = ${CAMPANHA_ID};" | psql -t -d ${DBNAME} -U ${DBUSER})
				#-n testa se retorno != null
				if [ -n "${CAMPANHA_STATUS}" ]
				then
					local CONTATO_TEL_1=$(echo "${NUMBER}" | awk -F '|' '{ print $3 }' | xargs | sed 's/[^0-9]//g')
                	local CONTATO_TEL_2=$(echo "${NUMBER}" | awk -F '|' '{ print $4 }' | xargs | sed 's/[^0-9]//g')

                    #Testa se o numero do tel1 e tel2 possui numero de digitos >= 8
                	if [ "${#CONTATO_TEL_1}" -ge "${QTD_DG_TEL}" -o "${#CONTATO_TEL_2}" -ge "${QTD_DG_TEL}" ]
                	then
	                	local CONTATO_ID=$(echo "${NUMBER}" | awk -F '|' '{ print $1 }' | xargs )
                    	local CONTATO_CONT_DISCAGEM=$(echo "${NUMBER}" | awk -F '|' '{ print $7 }' | xargs | sed 's/[^0-9]//g')

	                    #DIF recebe a hora da ultima discagem para o paciente em questao
    		            local CONTATO_DIF=$(echo "${NUMBER}" | awk -F '|' '{ print $6 }' | xargs | sed 's/[^0-9]//g')
        	            #Testa se o intervalo entre discagem para o mesmo contato foi atingido ou se eh a primeira discagem para este contato
            	        if [ \( "${CONTATO_DIF}" -ge "${INTERVAL}" \) -o \( "${CONTATO_CONT_DISCAGEM}" -eq "0" \) ]
                	    then
       	            		#Testa se atingiu limite de discagem
                      		local STATUS='AGENDADA'
	                      	if [ "${CONTATO_CONT_DISCAGEM}" -ge "${CALL_LIMIT}" ]
    	                  	then
        		            	STATUS='LIMITE ATINGIDO'
            	                echo "UPDATE ${DBTABLECONTATO} SET contato_excluido = true WHERE contato_id = '${CONTATO_ID}';" | psql -d ${DBNAME} -U ${DBUSER}
                	        fi

							local CONTATO_NOME=$(echo "${NUMBER}" | awk -F '|' '{ print $2 }' | xargs)
							local CONTATO_OUTROS=$(echo "${NUMBER}" | awk -F '|' '{ print $5 }' | xargs)
							local CAMPANHA_NOME=$(echo "${NUMBER}" | awk -F '|' '{ print $9 }' | xargs)
							local CAMPANHA_AUDIO=$(echo "${NUMBER}" | awk -F '|' '{ print $10 }' | xargs)
							local CAMPANHA_OP1=$(echo "${NUMBER}" | awk -F '|' '{ print $11 }' | xargs)
							local CAMPANHA_OP2=$(echo "${NUMBER}" | awk -F '|' '{ print $12 }' | xargs)
							local CAMPANHA_OP3=$(echo "${NUMBER}" | awk -F '|' '{ print $13 }' | xargs)
							local CAMPANHA_OP4=$(echo "${NUMBER}" | awk -F '|' '{ print $14 }' | xargs)
							local CAMPANHA_OP5=$(echo "${NUMBER}" | awk -F '|' '{ print $15 }' | xargs)
							local CAMPANHA_OP6=$(echo "${NUMBER}" | awk -F '|' '{ print $16 }' | xargs)
							local CAMPANHA_OP7=$(echo "${NUMBER}" | awk -F '|' '{ print $17 }' | xargs)
							local CAMPANHA_OP8=$(echo "${NUMBER}" | awk -F '|' '{ print $18 }' | xargs)
							local CAMPANHA_OP9=$(echo "${NUMBER}" | awk -F '|' '{ print $19 }' | xargs)

							local VET=("${CONTATO_ID}" "${CONTATO_NOME}" "${CONTATO_TEL_1}" "${CONTATO_TEL_2}" "${CONTATO_OUTROS}" "${CONTATO_CONT_DISCAGEM}" "${CAMPANHA_NOME}" "${CAMPANHA_AUDIO}" "${CAMPANHA_OP1}" "${CAMPANHA_OP2}" "${CAMPANHA_OP3}" "${CAMPANHA_OP4}" "${CAMPANHA_OP5}" "${CAMPANHA_OP6}" "${CAMPANHA_OP7}" "${CAMPANHA_OP8}" "${CAMPANHA_OP9}")

							#Chama function createFileCall passando array como parametro
							createFileCall "${VET}"
							#Atualiza o numero de discagem realizada para o contato em questao
							echo "UPDATE ${DBTABLECONTATO} SET contato_cont_discagem = contato_cont_discagem +  1, contato_data_hora_discagem = now() WHERE contato_id = '${CONTATO_ID}';" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
							#sleep usado para otimizar o processo de discagem para segundo tel. Tentando evitar congestion qnd usa Neogate
							sleep 10
						#Fim teste intervalo entre discagens
						fi
					else
						echo "UPDATE ${DBTABLECONTATO} SET contato_excluido = true WHERE contato_id = '${CONTATO_ID}';" | psql -d ${DBNAME} -U ${DBUSER}
					#Fim teste qtd de digitos do tel1
					fi
				#Fim teste se campanha continua ativa e fora de pausa.
				fi
#			else
			#Fim testa ultimo contato da lista
			fi
		#Fim While le tb contato da base local
		done
#	else
	#Fim teste de quantidade de canais livres
	fi
#else
#echo "UPDATE ${DBTABLECONTATO} SET contato_excluido = true WHERE contato_id = '${CONTATO_ID}';" | psql -d ${DBNAME} -U ${DBUSER}
#Fim testa horario de discagem
fi
}
createFileCall(){
	local TEL_1="${VET[2]}"

	local ABSOLUTE_FILE_NAME='/opt/leucotron/call/'$(date +"%d%m%Y%H%M%S")_${TEL_1}'.call'

	echo "Channel: Local/${TEL_1}@outbound-call"	> ${ABSOLUTE_FILE_NAME}
	echo "Callerid: "5999" 5999"					>> ${ABSOLUTE_FILE_NAME}
	echo "MaxRetries: 0"							>> ${ABSOLUTE_FILE_NAME}
	echo "WaitTime: 180"							>> ${ABSOLUTE_FILE_NAME}
	echo "Context: inbound-call"					>> ${ABSOLUTE_FILE_NAME}
	echo "Extension: ${TEL_1}"						>> ${ABSOLUTE_FILE_NAME}
	echo "Priority: 1"								>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CONTATO_ID=${VET[0]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CONTATO_NOME=${VET[1]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CONTATO_TEL_1=${VET[2]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CONTATO_TEL_2=${VET[3]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CONTATO_OUTROS=${VET[4]}"			>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CONTATO_CONT_DISCAGEM=${VET[5]}"		>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_NOME=${VET[6]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_AUDIO=${VET[7]}"			>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP1=${VET[8]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP2=${VET[9]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP3=${VET[10]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP4=${VET[11]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP5=${VET[12]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP6=${VET[13]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP7=${VET[14]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP8=${VET[15]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: CAMPANHA_OP9=${VET[16]}"				>> ${ABSOLUTE_FILE_NAME}
	echo "Set: DIALSTATUS=ANSWER"					>> ${ABSOLUTE_FILE_NAME}
#	echo "Archive: yes"												>> ${ABSOLUTE_FILE_NAME}
#	echo "$(date +"%d-%m-%Y_%H:%M:%S") Chamando ${TEL_1}"			>> /opt/leucotron/log/confirmaConsulta.log
	mv ${ABSOLUTE_FILE_NAME} /var/spool/asterisk/outgoing/

}

main(){
	case "${OPCAO}" in
		start)
		#	sleep 120

			while :
			do
				local FERIADO=$(validaFeriado)
				sleep 1
				if [ "${FERIADO}" -eq 0 ]
				then
					local DIA_HORA=$(validaDiaHora)
					sleep 1
					if [ "${DIA_HORA}" -eq 1 ]
					then
#						populaTabelaContato
						dialCore
					else
#						echo "DELETE FROM ${DBTABLECONTATO};" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
						sleep 300
					#Fim testa se dia e horario de discagem
					fi
				else
					sleep 300
				#Fim testa se feriado
				fi
			#Fim While true.
			done & echo $! > /opt/leucotron/script/.pid	
			if [ $? -ne 0 ]
			then
				echo "Programa não pode ser inicializado! Verifique se esta executando como root."
				sudo kill -9 `ps -aux | egrep dialer.sh | awk '{ print $2 }'| grep -v PID`
				exit
			fi
		;;
		stop)
#			local DATA=$(echo "$(date +%Y-%m-%d)")
#			local TOTAL=$(echo "SELECT * FROM ${DBTABLECONTATO} WHERE data_hora::DATE = '${DATA}';"| psql -t -d ${DBNAME} -U ${DBUSER})
#			#-z testa se retorno == null
#			if [ -z "${TOTAL}" ]
#			then
#				echo "DELETE FROM ${DBTABLECONTATO};" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
#			fi
			rm /opt/leucotron/script/.pid >> /dev/null
			sudo pkill -f dialer.sh
			#sudo kill -9 ps -aux | egrep dialer.sh | awk '{ print $2 }'| grep -v PID
			exit
		;;
		*)
			echo "Use start|stop"
			exit 0
		;;
	esac
}

main
