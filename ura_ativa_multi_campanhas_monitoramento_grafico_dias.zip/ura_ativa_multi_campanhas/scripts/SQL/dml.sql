﻿--exemplos de inserts

--Campanha 1
INSERT INTO status(ativado, pausado,parado)
VALUES (default, default,default);
--SELECT * from status;
INSERT INTO campanha(campanha_nome, campanha_audio, campanha_total_contatos, status_fk)
VALUES ('ISION', 'ision', 100, 1);
--SELECT * from campanha;
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('evaldo de oliveira', '3534719553', '35991596272', '', 1);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('Filipe Firmino', '3532414541', '35984693042', '', 1);
--SELECT * from contato;
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, contato_fk)
VALUES ('03534719553', 'ANSWER', '1', 1);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, contato_fk)
VALUES ('0984693042', 'NOANSWER', '', 2);
--SELECT * from cdr;

--Campanha 2
INSERT INTO status(ativado, pausado,parado)
VALUES (default, default,default);
--SELECT * from status;
INSERT INTO campanha(campanha_nome, campanha_audio, campanha_total_contatos, status_fk)
VALUES ('Flux', 'flux', 200, 4);
--SELECT * from campanha;
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('Evandro de Oliveira', '1234719553', '12991596272', '', 5);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2, contato_outros, campanha_fk)
VALUES ('Filipe', '3132414541', '31984693042', '', 5);
--SELECT * from contato;
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, contato_fk)
VALUES ('034719553', 'BUSY', '', 4);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, cdr_dtmf, contato_fk)
VALUES ('0984693042', 'ANSWER', '', 5);
--SELECT * from cdr;

--exemplos de selects
--Tela Campanha
SELECT * FROM campanha  AS c
LEFT JOIN status AS s ON s.status_id = c.status_fk
--Tela Contato
SELECT DISTINCT ON (cont.contato_id) cont.contato_id, cdr.cdr_data_hora_chamada, c.campanha_nome, cont.contato_nome FROM contato  AS cont 
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cont.contato_id ASC, cdr.cdr_data_hora_chamada DESC

--Tela cdr
SELECT * FROM contato  AS cont
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cdr.cdr_data_hora_chamada DESC

--Tela de contato
SELECT DISTINCT ON (cont.contato_id) cont.contato_id, cdr.cdr_data_hora_chamada, c.campanha_nome, cont.contato_nome, cont.contato_tel1, cont.contato_tel2, cdr.cdr_status_chamada 
FROM contato  AS cont 
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cdr.contato_fk = cont.contato_id
ORDER BY cont.contato_id ASC, cdr.cdr_data_hora_chamada DESC 
LIMIT 10 OFFSET 0

SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 
FROM cdr, contato, status, campanha 
WHERE cdr_data_hora_chamada 
BETWEEN '10/05/2019 10:01' AND '10/05/2019 12:11' 
AND contato_fk = contato_id 
AND campanha_fk = campanha_id 
AND status_fk = status_id 
ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET 0

--Ordenação aleatoria
SELECT * FROM contato  AS cont
LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk
LEFT JOIN status AS s ON s.status_id = c.status_fk 
WHERE cont.contato_excluido IS FALSE AND s.ativado IS TRUE AND s.pausado IS FALSE AND s.parado IS FALSE AND cont.contato_cont_discagem <= 1
ORDER BY RANDOM()

SELECT cont.contato_id, cont.contato_nome, cont.contato_tel1, cont.contato_tel2, cont.contato_outros, TO_CHAR(CURRENT_TIMESTAMP - cont.contato_data_hora_discagem, 'HH24'), cont.contato_cont_discagem, c.campanha_nome, c.campanha_audio, c.campanha_op1, c.campanha_op2, c.campanha_op3, c.campanha_op4, c.campanha_op5, c.campanha_op6, c.campanha_op7, c.campanha_op8, c.campanha_op9 FROM contato  AS cont LEFT JOIN campanha AS c ON c.campanha_id = cont.campanha_fk LEFT JOIN status AS s ON s.status_id = c.status_fk WHERE cont.contato_excluido IS FALSE AND s.ativado IS TRUE AND s.pausado IS FALSE AND s.parado IS FALSE AND cont.contato_cont_discagem <= 4 ORDER BY RANDOM() LIMIT 2

SELECT * from dia_semana  
--exemplo delete
--DELETE FROM contato 
--DELETE FROM status
--DELETE FROM cdr 
--DELETE FROM campanha 


