function exportarCSV() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/manutencao/select')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    montarArquivoBackup(JSON.parse(this.response).data);
                    break;

                case 304:
                    montarArquivoBackup(JSON.parse(this.response).data);
                    break;

                case 400:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor');
                    break;

                default:
                    alertSwal('Erro inesperado, contate o administrador');
                    break;
            }
        }
    }
    xhttp.send();
}

function montarArquivoBackup(rows) {
    //Titulo para nortear os campos do backup
    var csv = 'Data/Hora Chamada,Campanha, Contato, Telefone 1, Telefone 2, Tel discado , Status Chamada , DTMF discado , Tipo Atendimento , Vezes discado, \n';

    for (var i = 0; i < rows.length; i++) {
        var date = new Date(rows[i].cdr_data_hora_chamada)

        csv += (date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear() + " " + (date.getHours() < 10 ? '0' : '') + date.getHours() + ":" + (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
        csv += ',' + rows[i].campanha_nome;
        csv += ',' + rows[i].contato_nome;
        csv += ',' + rows[i].contato_tel1;
        csv += ',' + rows[i].contato_tel2;
        csv += ',' + rows[i].cdr_tel_discado;
        csv += ',' + rows[i].cdr_status_chamada;
        csv += ',' + rows[i].cdr_dtmf;
        csv += ',' + rows[i].cdr_tipo_atendimento;
        csv += ',' + rows[i].contato_cont_discagem;
        csv += '\n';
    }

    try {
        var date = new Date();
        var dataExport = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "_" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "_" + date.getFullYear() + "_" + ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

        //Montar parametros para download do arquivo CSV
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_blank';
        hiddenElement.download = 'Backup_Ura_' + dataExport + '.csv';
        document.body.appendChild(hiddenElement);
        hiddenElement.click();
        document.body.removeChild(hiddenElement);

        //Executar comando de delete no banco de dados
        apagarDadosManutencao();
    } catch (error) {
        //Mostrar o erro ao usuário
        console.log("Error: " + error);
        alertSwal('Erro inesperado, contate o administrador');
    }
}

function apagarDadosManutencao() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/manutencao/delete')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    setTimeout(() => {
                        //Mostrar um sweat-alert informando que o processo pode demorar caso tenha muito log e o banco apagado
                        swal({
                            title: "Concluído!",
                            text: "Banco de dados apagado e backup gerado!",
                            type: "success",
                            timer: 2500,
                            showConfirmButton: false
                        },
                            function () {
                                swal.close();
                            });

                    }, 1500);

                    break;

                case 304:
                    setTimeout(() => {
                        //Mostrar um sweat-alert informando que o processo pode demorar caso tenha muito log e o banco apagado
                        swal({
                            title: "Concluído!",
                            text: "Banco de dados apagado e backup gerado!",
                            type: "success",
                            timer: 2500,
                            showConfirmButton: false
                        },
                            function () {
                                swal.close();
                            });

                    }, 1500);

                    break;

                case 400:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor');
                    break;

                default:
                    alertSwal('Erro inesperado, contate o administrador');
                    break;
            }
        }
    }
    xhttp.send();
}
function informarProcesso() {
    //Mostrar mensagem de que a campanha será finalizada mesmo sem ter iniciado e isso é irreversível  
    swal({
        title: `Apagar base de dados`,
        text: `Os logs de bilhetes, contatos, campanhas serão apagados e esta ação é permanente!\n\n Vamos prosseguir então?`,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Sim",
        cancelButtonText: "Não",
        closeOnConfirm: false,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm) {
                exportarCSV();
                swal.close();
            }
        });
}

function alertSwal(message) {
    swal({
        title: "Ops :-(",
        text: message,
        type: "error",
        showConfirmButton: true
    });
}