function getDataAjax() {
  $.ajax({
    contentType: 'application/json',
    data:
      JSON.stringify({
        nome: "ura",
        pagination: $('#atual').val()
      })
    ,
    dataType: 'json',
    success: function (data) {
      //console.log(data)
      //console.log("Sucesso na busca");
      if (data.totalCampanhas == 0) {
        $("#totalRegistros").val('0 registros.');
      } else {
        valorMaximoPag(data.totalCampanhas);
      }
      addCampanhaNaTabela(data);
    },
    error: function () {
      console.log("Falha na busca");
      rota();
    },
    processData: false,
    type: 'POST',
    url: '/campanha/selectDadosCampanhaVigente'
  });
}

function graficoCampanha(opcao1, opcao2, opcao3, opcao4, opcao5, opcao6, opcao7, opcao8, opcao9, nomeCampanha, totalContatos, totalDiscagens, totalAtendidas, totalNaoAtendidas) {
  return function () {
    $('#modalGraficoOpcoes').on('shown.bs.modal', function () {
      var barData = {
        labels: ["Opção 1", "Opção 2", "Opção 3", "Opção 4", "Opção 5", "Opção 6", "Opção 7", "Opção 8", "Opção 9"],
        datasets: [
          {
            label: "Total",
            backgroundColor: 'rgba(26,179,148,0.5)',
            borderColor: "rgba(26,179,148,0.7)",
            pointBackgroundColor: "rgba(26,179,148,1)",
            pointBorderColor: "#fff",
            data: [opcao1, opcao2, opcao3, opcao4, opcao5, opcao6, opcao7, opcao8, opcao9]
          }
        ]
      };

      var barOptions = {
        responsive: true
      };

      var ctx1 = document.getElementById("myChart").getContext("2d");
      new Chart(ctx1, { type: 'bar', data: barData, options: barOptions });

      $("#modalTitle").text("Campanha: " + nomeCampanha);

      var date = new Date();
      var dataGrafico = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear();
      $("#dataGrafico").val("Hoje: " + dataGrafico);

      var btnCSVGraf = document.getElementById("gerarCSVGrafico");
      btnCSVGraf.addEventListener("click", function (event) {
        //Titulo para nortear os campos do backup
    var csv = 'Campanha, Data, Contatos importados, Discagens realizadas, Chamadas atendidas, Chamadas não atendidas, Opção 1, Opção 2, Opção 3, Opção 4, Opção 5, Opção 6, Opção 7, Opção 8, Opção 9, \n';

        csv += nomeCampanha;
        csv += ',' + dataGrafico;
        csv += ',' + totalContatos;
        csv += ',' + totalDiscagens;
        csv += ',' + totalAtendidas;
        csv += ',' + totalNaoAtendidas;
        csv += ',' + opcao1;
        csv += ',' + opcao2;
        csv += ',' + opcao3;
        csv += ',' + opcao4;
        csv += ',' + opcao5;
        csv += ',' + opcao6;
        csv += ',' + opcao7;
        csv += ',' + opcao8;
        csv += ',' + opcao9;
        csv += '\n';

    try {
        var date = new Date();
        var dataExport = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "_" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "_" + date.getFullYear() + "_" + ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

        //Montar parametros para download do arquivo CSV
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_blank';
        hiddenElement.download = nomeCampanha +"_dados_" + dataExport + '.csv';
        document.body.appendChild(hiddenElement);
        hiddenElement.click();
        document.body.removeChild(hiddenElement);

    } catch (error) {
        //Mostrar o erro ao usuário
        console.log("Error: " + error);
        alertSwal('Erro inesperado, contate o administrador');
    }
      })
    });
  }
}

function addCampanhaNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaCampanhas tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.nomeCampanha.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    //Status
    var statusCell = newRow.insertCell(count)
    var statusElement = document.createElement('input');
    statusElement.setAttribute('type', 'button');
    statusElement.setAttribute('id', `status_${rows.nomeCampanha[i]}`);
    statusElement.setAttribute('disabled', 'true');
    statusElement.classList.add('btn');
    statusElement.classList.add('btn-outline');

    if (rows.ativado[i] && rows.pausado[i]) { //Iniciou e está pausado
      statusElement.setAttribute('value', 'Pausado');
      statusElement.classList.add('btn-warning');

    } else if (!rows.ativado[i] && rows.pausado[i]) { //Não iniciou mas está pausado (ERROR)
      statusElement.setAttribute('value', 'Pausado');
      statusElement.classList.add('btn-warning');
      console.log("Erro com o evento de pausa e início da campanha");

    } else if (!rows.ativado[i]) { //Ainda não foi iniciado
      statusElement.setAttribute('value', 'Aguardando início');
      statusElement.classList.add('btn-danger');

    } else { //Já foi iniciado
      statusElement.setAttribute('value', 'Em execução');
      statusElement.classList.add('btn-primary');
    }
    statusCell.appendChild(statusElement);
    count++;

    //Campanha
    var campanhaCell = newRow.insertCell(count);
    var campanhaValue = document.createTextNode(rows.nomeCampanha[i]);
    campanhaCell.appendChild(campanhaValue);
    count++;

    //Contatos importados
    var qtdImportadoCell = newRow.insertCell(count);
    var qtdImportadoValue = document.createTextNode(rows.totalContatos[i]);
    qtdImportadoCell.appendChild(qtdImportadoValue);
    count++;

    //Discagens realizadas
    var discRealizadasCell = newRow.insertCell(count);
    var discRealizadasValue = document.createTextNode(rows.totalDiscagens[i]);
    discRealizadasCell.appendChild(discRealizadasValue);
    count++;

    //Discagens realizadas
    var atendidasCell = newRow.insertCell(count);
    var atendidasValue = document.createTextNode(rows.totalAtendidas[i]);
    atendidasCell.appendChild(atendidasValue);
    count++;

    //Discagens não realizadas
    var naoAtendidasCell = newRow.insertCell(count);
    var naoAtendidasValue = document.createTextNode(rows.totalNaoAtendidas[i]);
    naoAtendidasCell.appendChild(naoAtendidasValue);
    count++;

    //Grafico
    var statusCell = newRow.insertCell(count);
    //Botão do grafico
    var icone = document.createElement('span');
    icone.setAttribute('class', 'btn btn-outline btn-success fa fa-bar-chart-o');
    icone.setAttribute('id', rows.nomeCampanha[i]);
    icone.setAttribute('data-toggle', "modal");
    icone.setAttribute('data-target', "#modalGraficoOpcoes");
    icone.setAttribute('title', "Gráfico das opções de 1 a 9");
    icone.onclick = graficoCampanha(
      rows.opcao1[i], rows.opcao2[i], rows.opcao3[i],
      rows.opcao4[i], rows.opcao5[i], rows.opcao6[i],
      rows.opcao7[i], rows.opcao8[i], rows.opcao9[i],
      rows.nomeCampanha[i], rows.totalContatos[i], rows.totalDiscagens[i], rows.totalAtendidas[i], rows.totalNaoAtendidas[i] );
    statusCell.appendChild(icone);

    //Ações
    if (rows.ativado[i]) {
      var statusCell = newRow.insertCell(count);
      //Botão de stop
      var icone = document.createElement('span');
      icone.setAttribute('class', 'btn btn-outline btn-danger fa fa-stop');
      icone.setAttribute('id', rows.nomeCampanha[i]);
      icone.setAttribute('title', "Parar campanha");
      icone.onclick = stopCamp(rows.nomeCampanha[i]);
      statusCell.appendChild(icone);
    }

    var statusCell = newRow.insertCell(count);
    //Botão de play
    var icone = document.createElement('span');
    if (!rows.ativado[i] && !rows.pausado[i]) { //Ativado = FALSE e Pausado = FALSE
      icone.setAttribute('class', 'btn btn-outline btn-primary fa fa-play');
      icone.setAttribute('title', "Iniciar campanha");
    }
    if (rows.ativado[i]) { //Ativado = TRUE
      if (rows.pausado[i]) {  //Pausado = TRUE
        icone.setAttribute('class', 'btn btn-outline btn-primary fa fa-play');
        icone.setAttribute('title', "Reiniciar campanha");
      } else {
        icone.setAttribute('class', 'btn btn-outline btn-warning fa fa-pause');
        icone.setAttribute('title', "Pausar campanha");
      }
    }

    icone.setAttribute('id', rows.nomeCampanha[i]);
    icone.onclick = initCamp(rows.nomeCampanha[i], rows.ativado[i], rows.pausado[i]);
    statusCell.appendChild(icone);

    count++;
    //Ordenar a tabela e mostra-las stripada
    $("#cabecalhoStatusGerenciamento").click();
  }
}

function stopCamp(campanha) {
  return function () {
    pararCampanha(campanha)
  }
}

function initCamp(campanha, ativado, pausado) {
  return function () {
    if (!ativado) {
      iniciarCampanha(campanha);
    } else {
      if (!pausado) {
        pausarCampanha(campanha);
      } else {
        iniciarCampanha(campanha);
      }
    }
  }
}

function iniciarCampanha(campanha) {
  //Buscando o nome da campanha clicada
  var xhttp = new XMLHttpRequest();

  var object = {
    campanhaVigente: campanha
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          console.log("Campanha iniciou!");
          document.getElementById(`status_${campanha}`).setAttribute('value', 'Em execução');
          document.getElementById(`status_${campanha}`).setAttribute('class', 'btn btn-outline btn-primary');
          document.getElementById(campanha).setAttribute('class', 'btn btn-outline btn-warning fa fa-pause');
          break;

        case 400:
          dangerSwal(JSON.parse(this.response).message);
          break;

        case 500:
          dangerSwal(JSON.parse(this.response).message);
          break;

        default:
          dangerSwal("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/iniciarCampanha', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function pausarCampanha(campanha) {
  //Buscando o nome da campanha clicada
  var xhttp = new XMLHttpRequest();

  var object = {
    campanhaVigente: campanha
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          document.getElementById(`status_${campanha}`).setAttribute('value', 'Pausado');
          document.getElementById(campanha).setAttribute('class', 'btn btn-outline btn-primary fa fa-play');
          break;

        case 400:
          dangerSwal(JSON.parse(this.response).message);
          break;

        case 500:
          dangerSwal(JSON.parse(this.response).message);
          break;

        default:
          dangerSwal("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/pausarCampanha', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function pararCampanha(campanha) {
  //Mostrar mensagem de que a campanha será finalizada mesmo sem ter iniciado e isso é irreversível  
  swal({
    title: `Parar campanha: ${campanha}`,
    text: 'Ao parar esta campanha, seus dados serão visualizados somente em histórico ok?',
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: "btn-danger",
    confirmButtonText: "Sim",
    cancelButtonText: "Cancelar",
    closeOnConfirm: false,
    closeOnCancel: true
  },
    function (isConfirm) {
      if (isConfirm) {
        //Abrir requisicao HTTP para acessar o servidor.
        var xhttp = new XMLHttpRequest();

        //Buscando o nome da campanha clicada
        var object = {
          campanhaVigente: campanha
        }

        xhttp.onreadystatechange = function () {
          if (this.readyState == 4) {
            switch (this.status) {
              case 200:
                swal({
                  title: "Feito!",
                  text: "Campanha parada com sucesso!",
                  type: "success",
                  timer: 3000,
                  showConfirmButton: true
                });
                break;

              case 304:
                swal({
                  title: "Feito!",
                  text: "Campanha parada com sucesso!",
                  type: "success",
                  timer: 3000,
                  showConfirmButton: true
                });
                break;

              case 400:
                dangerSwal(JSON.parse(this.response).message);
                break;

              case 500:
                dangerSwal(JSON.parse(this.response).message);
                break;

              default:
                dangerSwal("Erro inesperado, contate o administrador.");
                break;
            }
          }
        }
        xhttp.open('POST', '/campanha/pararCampanha', true);
        xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.send(JSON.stringify(object));
      }
    });
}

function dangerSwal(message) {
  swal({
    title: "Opss :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}

function infoSwal() {
  swal({
    title: "Exportar CSV",
    text: "Este processo pode demorar um tempo!",
    timer: 4000,
    showConfirmButton: true
  });
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximo');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atual').val() > page) {
    $('#atual').val(1);
    $('#contMenos').click();
  }
}

function gatilhoContMenos() {
  $('#contMais').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();

  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atual').val(1);
    $('#contMenos').attr('disabled', true);
  }

  rota();
}

function gatilhoContMais() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMais').attr('disabled', true);
    $('#atual').val(valorMaximo);
  }

  rota();
}

function gatilhoPaginacaoProximo() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atual').val(valorMaximo);
    $('#contMais').attr('disabled', true);
  }

  rota();
}
