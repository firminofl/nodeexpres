function carregaConfiguracoes() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/configuracao/select')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    //if (JSON.parse(this.response).houveAlteracao == 0) {
                    setaValores(JSON.parse(this.response).rows);
                    //} else {
                    //alertChangeInfo("Os dados já estão salvos no banco de dados!\nMas é necessário aplicar as alterações para que o sistema funcione de maneira adequeada.\n\nDeseja aplicar as configurações agora?");
                    //}
                    break;
                case 304:
                    //if (JSON.parse(this.response).houveAlteracao == 0) {
                    setaValores(JSON.parse(this.response).rows);
                    //} else {
                    //alertChangeInfo("Os dados já estão salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
                    //} 
                    break;
                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;
                default:
                    console.log("Erro inesperado, contate o administrador.");
                    break;
            }
        }
    }

    xhttp.send()
}

function setaValores(item) {
    $('#tentativasDiscagem').val(item.conf_num_tentativa);
    $('#intervaloDiscagens').val(item.conf_intervalo_discagem);
    $('#chamadaSimultaneas').val(item.conf_chamadas_simultaneas);
    /*$('#antecedenciaFeriado').val(item.conf_dias_antes);
    if (item.conf_amd.toString() == 'true') {
        document.getElementById('amd').checked = true;
    } else if (item.conf_amd.toString() == 'false') {
        document.getElementById('amd').checked = false;
    }
    */
}

function validarConfiguracoes() {
    var tentativasDiscagem = $('#tentativasDiscagem').val();
    var intervaloDiscagens = $('#intervaloDiscagens').val();
    var chamadaSimultaneas = $('#chamadaSimultaneas').val();
    /*var antecedenciaFeriado = $('#antecedenciaFeriado').val();
    var amd;
    if ($('#amd').is(':checked')) {
        amd = 'true';
    } else {
        amd = 'false';
    }
    */

    var object = {
        tentativasDiscagem: tentativasDiscagem,
        intervaloDiscagens: intervaloDiscagens,
        chamadaSimultaneas: chamadaSimultaneas
        //,antecedenciaFeriado: antecedenciaFeriado
    }

    if (tentativasDiscagem == '' || tentativasDiscagem > 9 || tentativasDiscagem < 1) {
        alertSwal('Campo de tentativas de discagem não está preenchido corretamente!');
        return false;
    }

    if (intervaloDiscagens == '' || intervaloDiscagens > 3 || intervaloDiscagens < 1) {
        alertSwal('Campo de intervalo de discagens não está preenchido corretamente!');
        return false;
    }

    if (chamadaSimultaneas == '' || chamadaSimultaneas > 8 || chamadaSimultaneas < 1) {
        alertSwal('Campo de chamadas simultâneas não está preenchido corretamente!');
        return false;
    }

    /*if (antecedenciaFeriado == '' || antecedenciaFeriado > 7 || antecedenciaFeriado < 1) {
        alertSwal('Campo dias com antecedência de feriado não está preenchido corretamente!');
        return false;
    }*/

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    //if (JSON.parse(this.response).houveAlteracao == 0) {
                    carregaConfiguracoes();
                    sucessSwalOk();
                    /*setTimeout(() => {
                     sucessSwal("Configurações mantidas!");
                    }, 1000);
                    } else {
                    carregaConfiguracoes();
                    alertChangeInfo("Dados salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
            }*/
                    break;

                case 304:
                    //if (JSON.parse(this.response).houveAlteracao == 0) {
                    carregaConfiguracoes();
                    /*setTimeout(() => {
                     sucessSwal("Configurações mantidas!");
                    }, 1000);
                    } else {
                    carregaConfiguracoes();
                    alertChangeInfo("Dados salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
            }*/
                    break;

                case 401:
                    alertSwal('Erro ao atualizar informações no sistema.');
                    break;

                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor.');
                    break;

                default:
                    alertSwal('Erro inesperado, contate o administrador.');
                    break;
            }
        }
    }
    xhttp.open("POST", '/configuracao/update', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
}

function alertSwal(message) {
    swal({
        title: "Ops :(",
        text: message,
        type: "error",
        showConfirmButton: true
    });
}

function sucessSwal(message) {
    swal({
        title: "Sucesso :)",
        text: message,
        type: "success",
        timer: 4500,
    },
        function () {
            swal.close();
        });
}

function sucessSwalOk(message) {
    swal({
        title: "Salvo",
        type: "success",
        timer: 1200,
        showConfirmButton: false
    },
        function () {
            swal.close();
        });
}
/*
function alertChangeInfo(message) {
    swal({
        title: "Atenção!",
        text: message,
        type: "warning",
        showCancelButton: true,
        showLoaderOnConfirm: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Sim",
        cancelButtonText: "Não",
        closeOnConfirm: true
    },
        function (isConfirm) {
            if (isConfirm) {
                executeRestartSystem();
            }
        });
}

function executeRestartSystem() {
    var xhttp = new XMLHttpRequest()

    xhttp.open('GET', '/configuracao/restart', true);

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    carregaConfiguracoes();
                    setTimeout(() => {
                        sucessSwal("Configurações aplicadas!");
                    }, 1500);
                    break;

                case 304:
                    carregaConfiguracoes();
                    setTimeout(() => {
                        sucessSwal("Configurações aplicadas!");
                    }, 1500);
                    break;

                case 401:
                    alertSwal('Usuário ou senha inválidos');
                    break;

                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor');
                    break;

                default:
                    alertSwal('Erro inesperado, contate o administrador');
            }
        }
    }
    xhttp.send();
}
*/