var express = require('express');
var router = express.Router();
var diasdasemana_controller = require('../controller/diasdasemana');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Atualizar dias da semana
router.post('/update', diasdasemana_controller.update);

//Buscar dias da semana
router.get('/select', diasdasemana_controller.select);

//restart do dialer
//router.get('/restart', diasdasemana_controller.restart);
module.exports = router;
