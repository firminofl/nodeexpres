const pg = require('../db');
const exec = require('child_process').exec;

var totalContatos = [];
var totalDiscagens = [];
var totalAtendidas = [];
var totalNaoAtendidas = [];
var ativado = [];
var pausado = [];
var parado = [];
var campanha = [];
var opcao1 = [];
var opcao2 = [];
var opcao3 = [];
var opcao4 = [];
var opcao5 = [];
var opcao6 = [];
var opcao7 = [];
var opcao8 = [];
var opcao9 = [];

module.exports = {
  insertContatos: (req, res) => {
    files = req.files.importaContatos;
    files2 = req.files;

    if (!files && !files2) {
      console.log("Error: " + files + "\n" + files2);
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum arquivo CSV e de áudio enviado'
      });
    } else if (!files) {
      console.log("Error: " + files);
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum arquivo CSV enviado'
      });
    } else if (!files2) {
      console.log("Error: " + files2);
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum arquivo de áudio enviado'
      });
    }

    try {
      //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
      var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';
      var ultimoIdCampanha = 0;
      var allRows = null;
      var qtdContatos = 0;

      pg.query(sqlUltimaCampanha, [], (err, ans) => {
        if (err) {
          console.log("Error: " + err);
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Resultado do ultimo id de campanha cadastrada
          ultimoIdCampanha = ans.rows[0].max;

          //Converter arquivo csv para texto e fazer sua analise
          allRows = files.data.toString().split(/\r?\n|\r/);

          //Fazer update na tabela de campanha a quantidade de contatos
          qtdContatos = (allRows.length.valueOf() - 2);

          //Máximo permitido de contatos é de 50000
          if (qtdContatos > 50000) {
            //Buscar a campanha cadastrada por ultimo, para fazer excluí-la, uma vez que foi cadastrada e o arquivo de contatos deu erro.
            var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

            pg.query(sqlUltimaCampanha, [], (err, ans) => {
              if (err) {
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              } else {
                //Resultado do ultimo id de campanha cadastrada
                var ultimoIdCampanha = ans.rows[0].max;

                //Deletar a campanha cadastrada no processo de importação dos contatos
                var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                pg.query(queryDeleteCampanha, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  }
                });
              }
            });

            console.log("\nLimite máximo de contatos foi atingido em 50000");
            //Retorno para o front-end da situação do arquivo e onde foi encontrado o problema
            return res.status(408).send({
              error: 'Erro interno',
              message: 'Limite máximo de contatos foi atingido em 50000'
            });
          } else {

            //Aqui é quando a quantidade de contatos é inferior a 50000 e o sistema irá salvá-los agora.
            var queryUpdate = 'UPDATE campanha SET campanha_total_contatos = ' + qtdContatos + ' WHERE campanha_id = ' + ultimoIdCampanha;
            pg.query(queryUpdate, [], (err, ans) => {
              if (err) {
                console.log("Error: " + err);
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              } else {

                //Construir query para multiplos parametros no insert
                var params = []
                var chunks = []

                //Inicia a partir do dado e desconsidera o titulo das colunas no csv
                for (var singleRow = 1; singleRow <= qtdContatos; singleRow++) {
                  var rowCells = allRows[singleRow].split(',');
                  for (var rowCell = 0; rowCell < rowCells.length; rowCell++) {
                    var valueClause = []
                    //Pegar nome do contato:
                    var nomeContato = rowCells[rowCell];
                    valueClause.push("'" + nomeContato + "'")
                    rowCell++;

                    //Pegar telefone 1
                    var tel1Contato = rowCells[rowCell];
                    valueClause.push("'" + tel1Contato + "'")
                    rowCell++;

                    //Verificar se o nome e telefone 1 do contato está ok
                    if (nomeContato.length == 0 && tel1Contato.length == 0) {

                      //Buscar a campanha cadastrada por ultimo, para fazer excluí-la, uma vez que foi cadastrada e o arquivo de contatos deu erro.
                      var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                      pg.query(sqlUltimaCampanha, [], (err, ans) => {
                        if (err) {
                          return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {

                          //Resultado do ultimo id de campanha cadastrada
                          var ultimoIdCampanha = ans.rows[0].max;

                          //Deletar a campanha cadastrada no processo de importação dos contatos
                          var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                          pg.query(queryDeleteCampanha, [], (err, ans) => {
                            if (err) {
                              return res.status(500).send({
                                error: 'Erro interno',
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            }
                          });
                        }
                      });

                      //Retorno para o front-end da situação do arquivo e onde foi encontrado o problema
                      return res.status(400).send({
                        error: 'Erro interno',
                        message: 'Arquivo CSV, na linha ' + (singleRow + 1) + ' faltou o nome e telefone 1 do contato. Verifique!'
                      });
                    } else if (nomeContato.length == 0 && tel1Contato.length != 0) {

                      //Buscar a campanha cadastrada por ultimo, para fazer excluí-la, uma vez que foi cadastrada e o arquivo de contatos deu erro.
                      var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                      pg.query(sqlUltimaCampanha, [], (err, ans) => {
                        if (err) {
                          return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {

                          //Resultado do ultimo id de campanha cadastrada
                          var ultimoIdCampanha = ans.rows[0].max;

                          //Deletar a campanha cadastrada no processo de importação dos contatos
                          var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                          pg.query(queryDeleteCampanha, [], (err, ans) => {
                            if (err) {
                              return res.status(500).send({
                                error: 'Erro interno',
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            }
                          });
                        }
                      });

                      //Retorno para o front-end da situação do arquivo e onde foi encontrado o problema
                      return res.status(400).send({
                        error: 'Erro interno',
                        message: 'Arquivo CSV, na linha ' + (singleRow + 1) + ' faltou o nome do contato. Verifique!'
                      });
                    } else if (nomeContato.length != 0 && tel1Contato.length == 0) {

                      //Buscar a campanha cadastrada por ultimo, para fazer excluí-la, uma vez que foi cadastrada e o arquivo de contatos deu erro.
                      var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                      pg.query(sqlUltimaCampanha, [], (err, ans) => {
                        if (err) {
                          return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {

                          //Resultado do ultimo id de campanha cadastrada
                          var ultimoIdCampanha = ans.rows[0].max;

                          //Deletar a campanha cadastrada no processo de importação dos contatos
                          var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                          pg.query(queryDeleteCampanha, [], (err, ans) => {
                            if (err) {
                              return res.status(500).send({
                                error: 'Erro interno',
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            }
                          });
                        }
                      });

                      //Retorno para o front-end da situação do arquivo e onde foi encontrado o problema
                      return res.status(400).send({
                        error: 'Erro interno',
                        message: 'Arquivo CSV, na linha ' + (singleRow + 1) + ' faltou o telefone 1 do contato. Verifique!'
                      });
                    }

                    //Pegar Telefone 2
                    var tel2Contato = rowCells[rowCell];
                    valueClause.push("'" + tel2Contato + "'")

                    //Identificacao da campanha que o contato esta inserido
                    valueClause.push(ultimoIdCampanha)

                    //Construindo um array para insercao
                    chunks.push('(' + valueClause.join(', ') + ')')
                  }
                }
                //Query de inserir contato novo na campanha
                var query = 'INSERT INTO contato(contato_nome,contato_tel1,contato_tel2, campanha_fk) ' +
                  'VALUES ' + chunks.join(', ');

                pg.query(query, [], (err, ans) => {
                  if (err) {
                    console.log("Error: " + err)
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  } else {
                    var nomeAudio = files2.audioCampanha.name.split('.')[0];

                    try {

                      //Verificar se existe o audio cadastrado com o mesmo nome que está vindo do front-end
                      var queryAudioCampanha = 'SELECT COUNT(campanha_audio) FROM campanha WHERE campanha_audio = ' + "'" + nomeAudio + "'";

                      pg.query(queryAudioCampanha, [], (err, ans) => {
                        if (err) {
                          return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {
                          //Caso não tenha campanha cadastrada com o nome vindo do front-end
                          var temOuNaoAudio = ans.rows[0].count;

                          if (temOuNaoAudio > 0) {
                            //A campanha foi cadastrada, ela precisa ser excluída para que o usuario apenas atualize o audio
                            //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
                            var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                            pg.query(sqlUltimaCampanha, [], (err, ans) => {
                              if (err) {
                                return res.status(500).send({
                                  error: 'Erro interno',
                                  message: 'Erro interno, por favor contacte o administrador'
                                });
                              } else {
                                //Resultado do ultimo id de campanha cadastrada
                                var ultimoIdCampanha = ans.rows[0].max;

                                //Deletar a campanha cadastrada com o audio que tinha no banco
                                var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                                pg.query(queryDeleteCampanha, [], (err, ans) => {
                                  if (err) {
                                    return res.status(500).send({
                                      error: 'Erro interno',
                                      message: 'Erro interno, por favor contacte o administrador'
                                    });
                                  }
                                });
                              }
                            });

                            console.log("\n\nExiste um áudio cadastrado com este mesmo nome. Verifique!\n\n");
                            return res.status(500).send({
                              error: 'Erro interno',
                              message: 'Existe um áudio cadastrado com este mesmo nome. Verifique!'
                            });

                          } else if (temOuNaoAudio == 0) {
                            //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
                            var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                            pg.query(sqlUltimaCampanha, [], (err, ans) => {
                              if (err) {
                                return res.status(500).send({
                                  error: 'Erro interno',
                                  message: 'Erro interno, por favor contacte o administrador'
                                });
                              } else {
                                //Resultado do ultimo id de campanha cadastrada
                                var ultimoIdCampanha = ans.rows[0].max;

                                //Extraindo o nome do audio para montar a query de update
                                var nomeAudio = files2.audioCampanha.name.split('.')[0];

                                var sqlUpdate = 'UPDATE campanha SET campanha_audio = ' + "'" + nomeAudio + "'" + ' WHERE campanha_id = ' + ultimoIdCampanha;

                                try {

                                  pg.query(sqlUpdate);

                                } catch (err) {
                                  return res.status(500).send({
                                    error: 'Erro interno',
                                    message: 'Erro interno, por favor contacte o administrador. Áudio não foi atualizado.'
                                  });
                                }

                                if (files2.audioCampanha.length === undefined) {
                                  try {
                                    //await files.audios.mv('/opt/leucotron/confirma/sounds/' + files.audios.name)
                                    files2.audioCampanha.mv('/opt/leucotron/sounds/' + files2.audioCampanha.name)
                                    //files.audioCampanha.mv('/home/filipefirmino/Music/sounds' + files.audioCampanha.name)
                                  } catch (error) {
                                    return res.status(500).send({
                                      error: 'Upload file',
                                      message: 'Erro ao gravar áudio no servidor'
                                    })
                                  }
                                } else {
                                  for (var i = 0; i < files2.audioCampanha.length; i++) {
                                    try {
                                      ///home/filipefirmino/Music/sounds/
                                      //await files.audios[i].mv('/opt/leucotron/ura/sounds/' + files.audios[i].name)
                                      files2.audioCampanha[i].mv('/opt/leucotron/sounds/' + files2.audioCampanha[i].name)
                                      //files.audioCampanha[i].mv('/home/filipefirmino/Music/sounds' + files.audioCampanha.name)
                                    } catch (error) {
                                      return res.status(500).send({
                                        error: 'Upload file',
                                        message: 'Erro ao gravar áudio no servidor'
                                      });
                                    }
                                  }
                                }
                                execute('sudo converteAudio.sh', (error, stdout) => { });

                                return res.json({
                                  success: 'Configurado',
                                  message: 'Campanha configurada com sucesso!'
                                });
                              }
                            });
                          }
                        }
                      });
                    } catch (err) {
                      return res.status(500).send({
                        error: 'Erro interno',
                        message: 'Erro interno, por favor contacte o administrador'
                      });
                    }
                  }
                });
              }
            });
          }
        }
      });
    } catch (error) {
      console.log("Error: " + error)
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insert: async (req, res) => {
    var nomeCampanha = req.body.nomeCampanha;
    var opcao1 = req.body.opcao1;
    var opcao2 = req.body.opcao2;
    var opcao3 = req.body.opcao3;
    var opcao4 = req.body.opcao4;
    var opcao5 = req.body.opcao5;
    var opcao6 = req.body.opcao6;
    var opcao7 = req.body.opcao7;
    var opcao8 = req.body.opcao8;
    var opcao9 = req.body.opcao9;

    if (!nomeCampanha)
      return res.status(400).send();

    try {
      //Verificar se existe uma campanha cadastrada com o mesmo nome
      var queryNomeCampanha = 'SELECT COUNT(campanha_nome) FROM campanha WHERE campanha_nome = ' + "'" + nomeCampanha + "'";

      var { rows } = await pg.queryAsync(queryNomeCampanha);

      //Caso não tenha campanha cadastrada com o nome vindo do front-end
      temOuNaoCampanha = rows[0].count;

      if (temOuNaoCampanha > 0) {
        console.log("\n\nExiste uma campanha cadastrada com este mesmo nome. Verifique!\n\n")
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Existe uma campanha cadastrada com este mesmo nome. Verifique!'
        });
      } else if (temOuNaoCampanha == 0) {
        //Inserindo agora a campanha
        var nomeAudio = nomeCampanha;
        var totalContatos = 0;

        //Query de inserção na tabela de campanha, posteriormente o nomeAudio vai ser alterado para o real.
        var query = 'INSERT INTO campanha(campanha_nome, campanha_audio, campanha_total_contatos, campanha_op1, campanha_op2, campanha_op3, campanha_op4, campanha_op5, campanha_op6, campanha_op7, campanha_op8, campanha_op9)' +
          ' VALUES ('
          + "'" + nomeCampanha + "', "
          + "'" + nomeAudio + "', "
          + "'" + totalContatos + "', "
          + "'" + opcao1 + "', "
          + "'" + opcao2 + "', "
          + "'" + opcao3 + "', "
          + "'" + opcao4 + "', "
          + "'" + opcao5 + "', "
          + "'" + opcao6 + "', "
          + "'" + opcao7 + "', "
          + "'" + opcao8 + "', "
          + "'" + opcao9 + "' );";

        var { rows } = await pg.queryAsync(query);

        //Buscando o id da campanha para passar no parametro
        var queryUltimoId = 'SELECT MAX(campanha_id) from campanha;';

        var { rows } = await pg.queryAsync(queryUltimoId);
        //Resultado do ultimo id do status
        var ultimoIdCampanha = rows[0].max;

        //Modificando o status da campanha para default no Cadastro
        var queryStatus = `INSERT INTO status(ativado, pausado,parado, campanha_fk) VALUES (default, default,default, ${ultimoIdCampanha});`;

        var { rows } = await pg.queryAsync(queryStatus);

        res.status(200).send({
          message: 'Campanha configurada com sucesso!'
        });
      }

    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  selectDadosCampanhaVigente: async (req, res) => {
    //Recebendo o nome da campanha
    var campanhaVigente = req.body.nome;

    //Vetor para preencher as campanhas paradas
    var campaing = []

    var query = 'SELECT COUNT(*) as qtdCampanhas FROM campanha, status WHERE status.campanha_fk = campanha.campanha_id AND parado = FALSE';
    var { rows } = await pg.queryAsync(query);
    //quantidade de campanhas
    var qtdCampanha = rows[0].qtdcampanhas;

    if (qtdCampanha == 0) {
      return res.status(200).send({
        totalCampanhas: 0,
        message: 'Nenhuma campanha disponível!'
      });
    } else {
      //paginacao no front-end
      var pagination = req.body.pagination;

      if (pagination == null || pagination == 1) {
        pagination = 0;
      } else if (pagination > 1) {
        pagination = pagination * 10 - 10;
      }

      //Descoberta das campanhas parado = TRUE
      var query = 'SELECT campanha_id,campanha_nome FROM campanha, status WHERE status.campanha_fk = campanha.campanha_id AND parado = FALSE ORDER BY campanha.campanha_id ASC LIMIT 10 OFFSET ' + pagination;
      var { rows } = await pg.queryAsync(query);
      var dadosCampanha = rows;

      var qtdCampanhaLocal = dadosCampanha.length;
      //Executar o processo de preencher o mapa com o nome das campanhas agora
      for (var i = 0; i < qtdCampanhaLocal; i++) {
        campaing[i] = dadosCampanha[i].campanha_nome;
      }

      //Total de campanhas
      var totalCampanhas = qtdCampanha;

      for (var key = 0; key < campaing.length; key++) {
        campanhaVigente = campaing[key];
        campanha[parseInt(key)] = campanhaVigente;

        //Verificar a quantidade de contatos
        var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status, contato WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryQtdContatos)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalContatos[parseInt(key)] = rows[0].campanha_total_contatos;

        //Verificar total discagens
        var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND cdr.contato_fk = contato.contato_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryTotalDiscagens)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalDiscagens[parseInt(key)] = rows[0].count;

        //Verificar total atendidas
        var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND cdr.contato_fk = contato.contato_id AND parado = FALSE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryTotalAtendidas)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalAtendidas[parseInt(key)] = rows[0].count;

        //Verificar total não atendidas
        var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND cdr.contato_fk = contato.contato_id AND parado = FALSE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryTotalNaoAtendidas)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalNaoAtendidas[parseInt(key)] = rows[0].count;

        //Saber o status da campanha
        var statusCampanha = 'SELECT ativado as ativado, pausado as pausado, parado as parado FROM status, campanha,contato WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND campanha_nome = ' + "'" + campanhaVigente + "';"
        var { rows } = await pg.queryAsync(statusCampanha)
        //Pegando o status da campanha para manipulação do front-end
        ativado[parseInt(key)] = rows[0].ativado;
        pausado[parseInt(key)] = rows[0].pausado;
        parado[parseInt(key)] = rows[0].parado;

        var queryPadrao =
          'SELECT  COUNT(cdr_dtmf) ' +
          'FROM cdr, contato, status, campanha WHERE ' +
          'status.campanha_fk = campanha.campanha_id AND ' +
          'contato.campanha_fk = campanha.campanha_id AND ' +
          'cdr.contato_fk = contato.contato_id AND ' +
          'parado = FALSE AND ' +
          'cdr_dtmf <> ' + "''" + ' AND ' +
          'campanha_nome = ' + "'" + campanhaVigente + "'";

        //Total da opcao 1
        var queryOpcao1 = queryPadrao + ' AND campanha.campanha_op1 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao1)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao1[parseInt(key)] = rows[0].count;

        //Total da opcao 2
        var queryOpcao2 = queryPadrao + ' AND campanha.campanha_op2 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao2)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao2[parseInt(key)] = rows[0].count;

        //Total da opcao 3
        var queryOpcao3 = queryPadrao + ' AND campanha.campanha_op3 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao3)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao3[parseInt(key)] = rows[0].count;

        //Total da opcao 4
        var queryOpcao4 = queryPadrao + ' AND campanha.campanha_op4 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao4)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao4[parseInt(key)] = rows[0].count;

        //Total da opcao 5
        var queryOpcao5 = queryPadrao + ' AND campanha.campanha_op5 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao5)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao5[parseInt(key)] = rows[0].count;

        //Total da opcao 6
        var queryOpcao6 = queryPadrao + ' AND campanha.campanha_op6 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao6)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao6[parseInt(key)] = rows[0].count;

        //Total da opcao 7
        var queryOpcao7 = queryPadrao + ' AND campanha.campanha_op7 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao7)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao7[parseInt(key)] = rows[0].count;

        //Total da opcao 8
        var queryOpcao8 = queryPadrao + ' AND campanha.campanha_op8 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao8)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao8[parseInt(key)] = rows[0].count;

        //Total da opcao 9
        var queryOpcao9 = queryPadrao + ' AND campanha.campanha_op9 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao9)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao9[parseInt(key)] = rows[0].count;

      }
      campaing = [];

      //Enviar os dados para o Front-end
      var objectResult;

      //Está ativo sem pausa
      objectResult = {
        nomeCampanha: campanha,
        totalContatos: totalContatos,
        totalDiscagens: totalDiscagens,
        totalAtendidas: totalAtendidas,
        totalNaoAtendidas: totalNaoAtendidas,
        totalCampanhas: totalCampanhas,
        ativado: ativado,
        pausado: pausado,
        parado: parado,
        opcao1: opcao1,
        opcao2: opcao2,
        opcao3: opcao3,
        opcao4: opcao4,
        opcao5: opcao5,
        opcao6: opcao6,
        opcao7: opcao7,
        opcao8: opcao8,
        opcao9: opcao9
      }

      setTimeout(() => {
        campanha = [];
        totalContatos = [];
        totalDiscagens = [];
        totalAtendidas = [];
        totalNaoAtendidas = [];
        totalCampanhas = [];
        ativado = [];
        pausado = [];
        parado = [];
        opcao1 = [];
        opcao2 = [];
        opcao3 = [];
        opcao4 = [];
        opcao5 = [];
        opcao6 = [];
        opcao7 = [];
        opcao8 = [];
        opcao9 = [];
        console.log("\n\n" + JSON.stringify(objectResult))
        //Response enviado para o front-end
        res.status(200).send(objectResult);
        objectResult = {};
      }, 1500);
    }
  },

  selectSomenteCampanhasParadas: async (req, res) => {
    //Recebendo o nome da campanha
    var campanhaVigente = req.body.nome;

    //Vetor para preencher as campanhas paradas
    var campaing = []

    var query = 'SELECT COUNT(*) as qtdCampanhas FROM campanha, status WHERE status.campanha_fk = campanha.campanha_id AND parado = TRUE';
    var { rows } = await pg.queryAsync(query);
    //quantidade de campanhas
    var qtdCampanha = rows[0].qtdcampanhas;

    if (qtdCampanha == 0) {
      return res.status(200).send({
        totalCampanhas: 0,
        message: 'Nenhuma campanha disponível!'
      });
    } else {
      //paginacao no front-end
      var pagination = req.body.pagination;

      if (pagination == null || pagination == 1) {
        pagination = 0;
      } else if (pagination > 1) {
        pagination = pagination * 10 - 10;
      }

      //Descoberta das campanhas parado = TRUE
      var query = 'SELECT campanha_id,campanha_nome FROM campanha, status WHERE status.campanha_fk = campanha.campanha_id AND parado = TRUE ORDER BY campanha.campanha_id ASC LIMIT 10 OFFSET ' + pagination;
      var { rows } = await pg.queryAsync(query);
      var dadosCampanha = rows;

      var qtdCampanhaLocal = dadosCampanha.length;
      //Executar o processo de preencher o mapa com o nome das campanhas agora
      for (var i = 0; i < qtdCampanhaLocal; i++) {
        campaing[i] = dadosCampanha[i].campanha_nome;
      }

      //Total de campanhas
      var totalCampanhas = qtdCampanha;

      for (var key = 0; key < campaing.length; key++) {
        campanhaVigente = campaing[key];
        campanha[parseInt(key)] = campanhaVigente;

        //Verificar a quantidade de contatos
        var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status, contato WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND parado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryQtdContatos)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalContatos[parseInt(key)] = rows[0].campanha_total_contatos;

        //Verificar total discagens
        var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND cdr.contato_fk = contato.contato_id AND parado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryTotalDiscagens)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalDiscagens[parseInt(key)] = rows[0].count;

        //Verificar total atendidas
        var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND cdr.contato_fk = contato.contato_id AND parado = TRUE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryTotalAtendidas)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalAtendidas[parseInt(key)] = rows[0].count;

        //Verificar total não atendidas
        var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND cdr.contato_fk = contato.contato_id AND parado = TRUE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";
        var { rows } = await pg.queryAsync(queryTotalNaoAtendidas)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        totalNaoAtendidas[parseInt(key)] = rows[0].count;

        //Saber o status da campanha
        var statusCampanha = 'SELECT ativado as ativado, pausado as pausado, parado as parado FROM status, campanha,contato WHERE contato.campanha_fk = campanha.campanha_id AND status.campanha_fk = campanha.campanha_id AND campanha_nome = ' + "'" + campanhaVigente + "';"
        var { rows } = await pg.queryAsync(statusCampanha)
        //Pegando o status da campanha para manipulação do front-end
        ativado[parseInt(key)] = rows[0].ativado;
        pausado[parseInt(key)] = rows[0].pausado;
        parado[parseInt(key)] = rows[0].parado;

        var queryPadrao =
          'SELECT  COUNT(cdr_dtmf) ' +
          'FROM cdr, contato, status, campanha WHERE ' +
          'status.campanha_fk = campanha.campanha_id AND ' +
          'contato.campanha_fk = campanha.campanha_id AND ' +
          'cdr.contato_fk = contato.contato_id AND ' +
          'parado = TRUE AND ' +
          'cdr_dtmf <> ' + "''" + ' AND ' +
          'campanha_nome = ' + "'" + campanhaVigente + "'";


        //Total da opcao 1
        var queryOpcao1 = queryPadrao + ' AND campanha.campanha_op1 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao1)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao1[parseInt(key)] = rows[0].count;

        //Total da opcao 2
        var queryOpcao2 = queryPadrao + ' AND campanha.campanha_op2 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao2)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao2[parseInt(key)] = rows[0].count;

        //Total da opcao 3
        var queryOpcao3 = queryPadrao + ' AND campanha.campanha_op3 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao3)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao3[parseInt(key)] = rows[0].count;

        //Total da opcao 4
        var queryOpcao4 = queryPadrao + ' AND campanha.campanha_op4 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao4)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao4[parseInt(key)] = rows[0].count;

        //Total da opcao 5
        var queryOpcao5 = queryPadrao + ' AND campanha.campanha_op5 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao5)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao5[parseInt(key)] = rows[0].count;

        //Total da opcao 6
        var queryOpcao6 = queryPadrao + ' AND campanha.campanha_op6 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao6)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao6[parseInt(key)] = rows[0].count;

        //Total da opcao 7
        var queryOpcao7 = queryPadrao + ' AND campanha.campanha_op7 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao7)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao7[parseInt(key)] = rows[0].count;

        //Total da opcao 8
        var queryOpcao8 = queryPadrao + ' AND campanha.campanha_op8 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao8)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao8[parseInt(key)] = rows[0].count;

        //Total da opcao 9
        var queryOpcao9 = queryPadrao + ' AND campanha.campanha_op9 = cdr_dtmf';
        var { rows } = await pg.queryAsync(queryOpcao9)
        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
        opcao9[parseInt(key)] = rows[0].count;

      }
      campaing = [];

      //Enviar os dados para o Front-end
      var objectResult;

      //Está ativo sem pausa
      objectResult = {
        nomeCampanha: campanha,
        totalContatos: totalContatos,
        totalDiscagens: totalDiscagens,
        totalAtendidas: totalAtendidas,
        totalNaoAtendidas: totalNaoAtendidas,
        totalCampanhas: totalCampanhas,
        ativado: ativado,
        pausado: pausado,
        parado: parado,
        opcao1: opcao1,
        opcao2: opcao2,
        opcao3: opcao3,
        opcao4: opcao4,
        opcao5: opcao5,
        opcao6: opcao6,
        opcao7: opcao7,
        opcao8: opcao8,
        opcao9: opcao9
      }

      setTimeout(() => {
        campanha = [];
        totalContatos = [];
        totalDiscagens = [];
        totalAtendidas = [];
        totalNaoAtendidas = [];
        totalCampanhas = [];
        ativado = [];
        pausado = [];
        parado = [];
        opcao1 = [];
        opcao2 = [];
        opcao3 = [];
        opcao4 = [];
        opcao5 = [];
        opcao6 = [];
        opcao7 = [];
        opcao8 = [];
        opcao9 = [];
        console.log("\n\n" + JSON.stringify(objectResult))
        //Response enviado para o front-end
        res.status(200).send(objectResult);
        objectResult = {};
      }, 1500);
    }
  },

  select: (req, res) => {
    //Buscar quantidade de campanhas cadastradas
    var queryQtdCampanha = 'SELECT COUNT(campanha_id) FROM campanha,status WHERE campanha_fk = campanha_id';

    pg.query(queryQtdCampanha, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem campanha cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma campanha cadastrada!'
          });
        } else {
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }

          //Query de busca do id, nome e audio da companha
          var query = 'SELECT campanha_id,campanha_nome,campanha_audio FROM campanha,status WHERE campanha_fk = campanha_id ORDER BY campanha_id DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  delete: (req, res) => {
    var campanha_id = req.body.campanha_id;

    var query = 'DELETE FROM campanha WHERE campanha_id = ' + campanha_id;

    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        res.json({
          message: 'Campanha excluída com sucesso!'
        });
      }
    });
  },

  export: (req, res) => {
    //Buscar quantidade de campanhas cadastradas
    var queryQtdCampanha = 'SELECT COUNT(campanha_id) FROM campanha,status WHERE campanha_fk = campanha_id';

    pg.query(queryQtdCampanha, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem campanha cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma campanha cadastrada!'
          });
        } else {
          //Query de busca 'da companha
          var query = 'SELECT * FROM campanha,status WHERE campanha_fk = campanha_id ORDER BY campanha_id DESC';

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  },

  selectSomenteCampanhas: (req, res) => {
    //Verificar se existe alguma campanha cadastrada
    var queryVerificaCampanhaCadastrada = 'SELECT COUNT(campanha_nome) as resultado FROM campanha, status WHERE campanha_fk = campanha_id AND parado = FALSE;';
    pg.query(queryVerificaCampanhaCadastrada, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0].resultado;

        //Verificar se não tem campanha cadastrada
        if (count == 0) {
          return res.status(500).send({
            message: 'Nenhuma campanha cadastrada!',
            contador: count
          });
        } else {
          //query para buscar somente os nomes das campanhas e popular o select(combobox) na tela de gerenciamento
          var query = 'SELECT campanha_nome FROM campanha, status WHERE campanha_fk = campanha_id AND parado = FALSE ORDER BY campanha_nome ASC;';
          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  },

  selectDadosCampanhaVigente1: (req, res) => {
    //Recebendo o nome da campanha
    var campanhaVigente = req.body.nome;
    var mapaCampanha = new Map();

    var query = 'SELECT COUNT(*) as qtdCampanhas FROM campanha, status WHERE campanha_fk = campanha_id AND parado = FALSE;';
    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //quantidade de campanhas
        var qtdCampanha = ans.rows[0].qtdcampanhas;

        //Descoberta das campanhas PARADO = FALSE
        var query = 'SELECT campanha_id,campanha_nome FROM campanha, status WHERE campanha_fk = campanha_id AND parado = FALSE;';
        pg.query(query, [], (err, ans) => {
          if (err) {
            console.log("\n\nError: " + err)
            return res.status(500).send({
              message: 'Erro interno, por favor contacte o administrador'
            });
          } else {
            var dadosCampanha = ans.rows;
            //console.log("Dados campanha: "+dadosCampanha+"\n"+JSON.stringify(dadosCampanha[0].campanha_id))
            //Executar o processo de preencher o mapa com o nome das campanhas agora
            mapaCampanha.clear();
            for (var i = 0; i < qtdCampanha; i++) {
              mapaCampanha.set(i, dadosCampanha[i].campanha_nome);
            }

            //Total de campanhas
            var totalCampanhas = mapaCampanha.size;

            for (var [key, value] of mapaCampanha.entries()) {
              campanhaVigente = value;
              campanha[parseInt(key)] = campanhaVigente;
              //console.log("Campanha: " + campanha[parseInt(key)])

              //Verificação de cada campo e incrementar as variaveis e dados
              try {
                //Verificar a quantidade de contatos
                var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status WHERE campanha_fk = campanha_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "'";
                console.log("\n" + queryQtdContatos);

                //Executar comando no banco
                pg.query(queryQtdContatos, [], (err, ans) => {
                  if (err) {
                    console.log("\n\nError: " + err)
                    return res.status(500).send({
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  } else {
                    //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                    totalContatos[parseInt(key)] = ans.rows[0].campanha_total_contatos;

                    //Verificar total discagens
                    var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "'";
                    console.log("\n" + queryTotalDiscagens);

                    //Executar comando no banco
                    pg.query(queryTotalDiscagens, [], (err, ans) => {
                      if (err) {
                        console.log("\n\nError: " + err)
                        return res.status(500).send({
                          message: 'Erro interno, por favor contacte o administrador'
                        });
                      } else {
                        //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                        totalDiscagens[parseInt(key)] = ans.rows[0].count;

                        //Verificar total atendidas
                        var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";
                        console.log("\n" + queryTotalAtendidas);

                        //Executar comando no banco
                        pg.query(queryTotalAtendidas, [], (err, ans) => {
                          if (err) {
                            console.log("\n\nError: " + err)
                            return res.status(500).send({
                              message: 'Erro interno, por favor contacte o administrador'
                            });
                          } else {
                            //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                            totalAtendidas[parseInt(key)] = ans.rows[0].count;

                            //Verificar total não atendidas
                            var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";
                            console.log("\n" + queryTotalNaoAtendidas);

                            //Executar comando no banco
                            pg.query(queryTotalNaoAtendidas, [], (err, ans) => {
                              if (err) {
                                console.log("\n\nError: " + err)
                                return res.status(500).send({
                                  message: 'Erro interno, por favor contacte o administrador'
                                });
                              } else {
                                //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                totalNaoAtendidas[parseInt(key)] = ans.rows[0].count;

                                //Saber o status da campanha
                                var statusCampanha = 'SELECT ativado as ativado, pausado as pausado, parado as parado FROM status, campanha WHERE campanha_id = campanha_fk AND campanha_nome = ' + "'" + campanhaVigente + "';"
                                console.log("\n" + statusCampanha);

                                pg.query(statusCampanha, [], (err, ans) => {
                                  if (err) {
                                    console.log("\n\nError: " + err)
                                    return res.status(500).send({
                                      message: 'Erro interno, por favor contacte o administrador'
                                    });
                                  } else {
                                    //Pegando o status da campanha para manipulação do front-end
                                    ativado[parseInt(key)] = ans.rows[0].ativado;
                                    pausado[parseInt(key)] = ans.rows[0].pausado;
                                    parado[parseInt(key)] = ans.rows[0].parado;
                                  }
                                });
                              }
                            });
                          }
                        });
                      }
                    });
                  }
                });
              } catch (error) {
                console.log("Error: " + error);
                return res.status(500).send({
                  message: 'Erro interno, por favor contacte o administrador'
                });
              }
            }
            //Enviar os dados para o Front-end
            var objectResult;

            //Está ativo sem pausa
            objectResult = {
              nomeCampanha: campanha,
              totalContatos: totalContatos,
              totalDiscagens: totalDiscagens,
              totalAtendidas: totalAtendidas,
              totalNaoAtendidas: totalNaoAtendidas,
              totalCampanhas: totalCampanhas,
              ativado: ativado,
              pausado: pausado,
              parado: parado
            }

            setTimeout(() => {
              console.log("\n\n" + JSON.stringify(objectResult))
              //Response enviado para o front-end
              res.status(200).send(objectResult);
            }, 1500)

          }
        });
      }
    });

    /*
    if (!campanhaVigente) {
      return res.status(400).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }

    //Verificar se a campanha teve seu status alterado para ativado = TRUE, por causa dos botoes de start,pause e stop no front-end


    try {
      var queryStatusAtivado = 'SELECT COUNT(ativado) FROM  status,campanha WHERE campanha_fk = campanha_id ' +
        'AND ativado = TRUE and campanha_nome = ' + "'" + campanhaVigente + "'";

      //Executar comando no banco
      pg.query(queryStatusAtivado, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Pega o resultado obtido da query
          totalAtivado = ans.rows[0].count;

          //Verifica se tem um 1 campanha ativada, se TRUE então não pode mostrar a opção de dar play na campanha
          if (totalAtivado == 0) {
            //Response enviado para o front-end
            res.status(200).send({
              ativado: 0,
              pausado: 0
            });

          } else if (totalAtivado == 1) {
            //Verificação de cada campo e incrementar as variaveis e dados
            try {
              //Verificar a quantidade de contatos
              var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status WHERE campanha_fk = campanha_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "'";

              //Executar comando no banco
              pg.query(queryQtdContatos, [], (err, ans) => {
                if (err) {
                  console.log("\n\nError: " + err)
                  return res.status(500).send({
                    message: 'Erro interno, por favor contacte o administrador'
                  });
                } else {
                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                  totalContatos = ans.rows[0].campanha_total_contatos;

                  //Verificar total discagens
                  var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "'";

                  //Executar comando no banco
                  pg.query(queryTotalDiscagens, [], (err, ans) => {
                    if (err) {
                      console.log("\n\nError: " + err)
                      return res.status(500).send({
                        message: 'Erro interno, por favor contacte o administrador'
                      });
                    } else {
                      //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                      totalDiscagens = ans.rows[0].count;

                      //Verificar total DTMF1
                      var queryTotalDTMF1 = 'SELECT COUNT(cdr_dtmf) as dtfm1 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_dtmf = ' + "'1'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                      //Executar comando no banco
                      pg.query(queryTotalDTMF1, [], (err, ans) => {
                        if (err) {
                          console.log("\n\nError: " + err)
                          return res.status(500).send({
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {
                          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                          totalDTMF1 = ans.rows[0].dtfm1;

                          //Verificar total DTMF2
                          var queryTotalDTMF2 = 'SELECT COUNT(cdr_dtmf) as dtfm2 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_dtmf = ' + "'2'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                          //Executar comando no banco
                          pg.query(queryTotalDTMF2, [], (err, ans) => {
                            if (err) {
                              console.log("\n\nError: " + err)
                              return res.status(500).send({
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            } else {
                              //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                              totalDTMF2 = ans.rows[0].dtfm2;

                              //Verificar total DTMF3
                              var queryTotalDTMF3 = 'SELECT COUNT(cdr_dtmf) as dtfm3 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_dtmf = ' + "'3'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                              //Executar comando no banco
                              pg.query(queryTotalDTMF3, [], (err, ans) => {
                                if (err) {
                                  console.log("\n\nError: " + err)
                                  return res.status(500).send({
                                    message: 'Erro interno, por favor contacte o administrador'
                                  });
                                } else {
                                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                  totalDTMF3 = ans.rows[0].dtfm3;

                                  //Verificar total atendidas
                                  var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                                  //Executar comando no banco
                                  pg.query(queryTotalAtendidas, [], (err, ans) => {
                                    if (err) {
                                      console.log("\n\nError: " + err)
                                      return res.status(500).send({
                                        message: 'Erro interno, por favor contacte o administrador'
                                      });
                                    } else {
                                      //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                      totalAtendidas = ans.rows[0].count;

                                      //Verificar total não atendidas
                                      var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = FALSE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                                      //Executar comando no banco
                                      pg.query(queryTotalNaoAtendidas, [], (err, ans) => {
                                        if (err) {
                                          console.log("\n\nError: " + err)
                                          return res.status(500).send({
                                            message: 'Erro interno, por favor contacte o administrador'
                                          });
                                        } else {
                                          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                          totalNaoAtendidas = ans.rows[0].count;

                                          //Verificar se a campanha está pausada
                                          var campanhaPausada = 'SELECT COUNT(pausado) FROM status,campanha WHERE campanha_fk = campanha_id ' +
                                            'AND pausado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "'";

                                          pg.query(campanhaPausada, [], (err, ans) => {
                                            if (err) {
                                              console.log("\n\nError: " + err)
                                              return res.status(500).send({
                                                message: 'Erro interno, por favor contacte o administrador'
                                              });
                                            } else {
                                              //Pega o resultado obtido da query
                                              statusPausado = ans.rows[0].count;
                                              //Enviar os dados para o Front-end
                                              var objectResult;

                                              if (statusPausado == 0) {
                                                //Está ativo sem pausa
                                                objectResult = {
                                                  totalContatos: totalContatos,
                                                  totalDiscagens: totalDiscagens,
                                                  totalDTMF1: totalDTMF1,
                                                  totalDTMF2: totalDTMF2,
                                                  totalDTMF3: totalDTMF3,
                                                  totalAtendidas: totalAtendidas,
                                                  totalNaoAtendidas: totalNaoAtendidas,
                                                  ativado: 1,
                                                  pausado: 0
                                                }
                                              } else {
                                                //Está ativo com pausa
                                                objectResult = {
                                                  totalContatos: totalContatos,
                                                  totalDiscagens: totalDiscagens,
                                                  totalDTMF1: totalDTMF1,
                                                  totalDTMF2: totalDTMF2,
                                                  totalDTMF3: totalDTMF3,
                                                  totalAtendidas: totalAtendidas,
                                                  totalNaoAtendidas: totalNaoAtendidas,
                                                  ativado: 1,
                                                  pausado: 1
                                                }
                                              }

                                              //Response enviado para o front-end
                                              res.status(200).send(objectResult);
                                            }
                                          });

                                        }
                                      });
                                    }
                                  });
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  });
                }
              });
            } catch (error) {
              console.log("Error: " + error);
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            }
          }
        }
      });

    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
    */
  },

  selectDadosCampanhaVigenteParada: (req, res) => {
    //Recebendo o nome da campanha
    var campanhaVigente = req.body.campanhaVigente;

    if (!campanhaVigente) {
      return res.status(400).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }

    //Verificação de cada campo e incrementar as variaveis e dados
    try {
      //Verificar a quantidade de contatos
      var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status WHERE campanha_fk = campanha_id AND parado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "'";

      //Executar comando no banco
      pg.query(queryQtdContatos, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
          totalContatos = ans.rows[0].campanha_total_contatos;

          //Verificar total discagens
          var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "'";

          //Executar comando no banco
          pg.query(queryTotalDiscagens, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
              totalDiscagens = ans.rows[0].count;

              //Verificar total DTMF1
              var queryTotalDTMF1 = 'SELECT COUNT(cdr_dtmf) as dtfm1 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = TRUE AND cdr_dtmf = ' + "'1'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

              //Executar comando no banco
              pg.query(queryTotalDTMF1, [], (err, ans) => {
                if (err) {
                  console.log("\n\nError: " + err)
                  return res.status(500).send({
                    message: 'Erro interno, por favor contacte o administrador'
                  });
                } else {
                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                  totalDTMF1 = ans.rows[0].dtfm1;

                  //Verificar total DTMF2
                  var queryTotalDTMF2 = 'SELECT COUNT(cdr_dtmf) as dtfm2 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = TRUE AND cdr_dtmf = ' + "'2'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                  //Executar comando no banco
                  pg.query(queryTotalDTMF2, [], (err, ans) => {
                    if (err) {
                      console.log("\n\nError: " + err)
                      return res.status(500).send({
                        message: 'Erro interno, por favor contacte o administrador'
                      });
                    } else {
                      //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                      totalDTMF2 = ans.rows[0].dtfm2;

                      //Verificar total DTMF3
                      var queryTotalDTMF3 = 'SELECT COUNT(cdr_dtmf) as dtfm3 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = TRUE AND cdr_dtmf = ' + "'3'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                      //Executar comando no banco
                      pg.query(queryTotalDTMF3, [], (err, ans) => {
                        if (err) {
                          console.log("\n\nError: " + err)
                          return res.status(500).send({
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {
                          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                          totalDTMF3 = ans.rows[0].dtfm3;

                          //Verificar total atendidas
                          var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = TRUE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                          //Executar comando no banco
                          pg.query(queryTotalAtendidas, [], (err, ans) => {
                            if (err) {
                              console.log("\n\nError: " + err)
                              return res.status(500).send({
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            } else {
                              //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                              totalAtendidas = ans.rows[0].count;

                              //Verificar total não atendidas
                              var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND campanha_fk = campanha_id AND parado = TRUE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "'";

                              //Executar comando no banco
                              pg.query(queryTotalNaoAtendidas, [], (err, ans) => {
                                if (err) {
                                  console.log("\n\nError: " + err)
                                  return res.status(500).send({
                                    message: 'Erro interno, por favor contacte o administrador'
                                  });
                                } else {
                                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                  totalNaoAtendidas = ans.rows[0].count;

                                  //Enviar os dados para o Front-end
                                  var objectResult = {
                                    totalContatos: totalContatos,
                                    totalDiscagens: totalDiscagens,
                                    totalDTMF1: totalDTMF1,
                                    totalDTMF2: totalDTMF2,
                                    totalDTMF3: totalDTMF3,
                                    totalAtendidas: totalAtendidas,
                                    totalNaoAtendidas: totalNaoAtendidas
                                  }

                                  //Response enviado para o front-end
                                  res.status(200).send(objectResult);
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  });
                }
              });
            }
          });
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  iniciarCampanha: (req, res) => {
    //Recebendo o nome da campanha para ativa-la
    var nomeCampanha = req.body.campanhaVigente;

    try {
      //Ativar a campanha atraves da tabela status
      var sqlAtivar = 'UPDATE status SET ativado = TRUE, pausado = FALSE FROM campanha WHERE status.campanha_fk = campanha_id AND campanha_nome = ' + "'" + nomeCampanha + "';";

      pg.query(sqlAtivar, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {

          setTimeout(() => {
            console.log("\n\nSistema de discagem começou para esta campanha: " + nomeCampanha + "!\n\n");
            res.status(200).send();
          }, 1000);
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  reiniciarCampanha: (req, res) => {
    //Recebendo o nome da campanha para reativa-la
    var nomeCampanha = req.body.campanhaVigente;

    //passar o status pausado para FALSE
    var pausadoFalse = 'UPDATE status SET pausado = FALSE FROM campanha WHERE campanha_fk = campanha_id AND ativado = TRUE AND campanha_nome = ' + "'" + nomeCampanha + "';";

    pg.query(pausadoFalse, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        console.log("\n\nSistema de discagem recomecou!\n\n")

        res.status(200).send();
      }
    });
  },

  pararCampanha: (req, res) => {
    //Recebendo o nome da campanha para ativa-la
    var nomeCampanha = req.body.campanhaVigente;

    try {
      //Buscar os contatos com contagem de discagem = 0 e o nome da campanha atrelado
      var sqlBuscaContDiscagem = 'UPDATE contato SET contato_excluido = TRUE FROM campanha, status ' +
        ' WHERE status.campanha_fk = campanha.campanha_id AND campanha.campanha_id = contato.campanha_fk AND campanha_nome = ' + "'" + nomeCampanha + "';";

      pg.query(sqlBuscaContDiscagem, [], (err, ans) => {
        if (err) {
          console.log("\n\nError 1: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Atualizar o status parado = TRUE para os contatos marcados como excluido
          var sqlStatusParado = 'UPDATE status SET parado = TRUE, ativado = FALSE, pausado = FALSE FROM campanha,contato ' +
            'WHERE contato_excluido = TRUE AND status.campanha_fk = campanha.campanha_id AND campanha_nome = ' + "'" + nomeCampanha + "';";

          pg.query(sqlStatusParado, [], (err, ans) => {
            if (err) {
              console.log("\n\nError 2: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {

              setTimeout(() => {
                console.log("\n\NSistema de discagem parou para esta campanha: " + nomeCampanha + "!\n\n");
                res.status(200).send();
              }, 1000);
            }
          });
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  pausarCampanha: (req, res) => {
    //Recebendo o nome da campanha para ativa-la
    var nomeCampanha = req.body.campanhaVigente;

    try {
      //Ativar a campanha atraves da tabela status
      var sqlAtivar = 'UPDATE status SET pausado = TRUE FROM campanha WHERE status.campanha_fk = campanha_id AND ativado = TRUE AND campanha_nome = ' + "'" + nomeCampanha + "';";

      pg.query(sqlAtivar, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          console.log("\n\nSistema de discagem aguardando para continuar!\n")
          res.status(200).send();
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  selectCampanhaAtiva: (req, res) => {
    //Saber se existe campanha ativada atraves do count
    var sqlCampanhaAtivada = 'SELECT COUNT(campanha_nome) FROM campanha, status WHERE campanha_fk = campanha_id AND ativado = TRUE;';

    pg.query(sqlCampanhaAtivada, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Retorno da consulta
        var contador = ans.rows[0].count;
        console.log("Contador: " + contador)
        //Caso nada esteja ativado
        if (contador == 0) {
          res.status(200).send({
            message: 'Nenhuma campanha em execução.',
            contador: contador
          });

        } else if (contador == 1) {
          //Buscar por campanha ativada
          var sqlCampanhaAtivada = 'SELECT campanha_nome FROM campanha, status WHERE campanha_fk = campanha_id AND ativado = TRUE;';

          pg.query(sqlCampanhaAtivada, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              //pegando o nome da campanha

              var nomeCampanhaAtivada = ans.rows[0].campanha_nome;

              res.status(200).send({
                message: 'Em execução: ' + nomeCampanhaAtivada,
                contador: contador,
                campanha: nomeCampanhaAtivada
              })
            }
          });
        }
      }
    });
  }

}

function execute(command, callback) {
  exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};
