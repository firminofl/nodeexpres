const pg = require('../db');
module.exports = {
  select: (req, res) => {
    var query = 'SELECT COUNT(*) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        var count = ans.rows[0].resultado;

        //Verificar se não tem bilhete registrado
        if (count == 0){
          return res.status(500).send({
            contador: count,
            message: 'Nenhum bilhete registrado até o momento!'
          });
        }else{

          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1){
            pagination = 0;
          }else if (pagination > 1){
            pagination = pagination*10 - 10;
          }

          var query = 'SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY cdr_id DESC LIMIT 10 OFFSET '+pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Erro ao selecionar dados no servidor'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      //Data e hora da discagem
      dataInicioDiscagemBilhete: req.body.dataInicioDiscagemBilhetes,
      dataFimDiscagemBilhete: req.body.dataFimDiscagemBilhetes,

      horaInicioDiscagemBilhete: req.body.horaInicioDiscagemBilhetes,
      horaFimDiscagemBilhete: req.body.horaFimDiscagemBilhetes,

      //contato, tel1 e tel2, telefone discado
      nomeContatoBilhete: req.body.nomeContatoBilhetes,
      tel1ContatoBilhete: req.body.tel1ContatoBilhetes,
      tel2ContatoBilhete: req.body.tel2ContatoBilhetes,
      telDiscadoBilhete: req.body.telDiscadoBilhetes,

      //status da chamada
      statusChamadaBilhete: req.body.statusChamadaBilhetes,

      //DTMF
      dtmfDiscadoBilhete: req.body.dtmfDiscadoBilhetes,

      //tipo de atendimento
      tipoAtendimentoBilhete: req.body.tipoAtendimentoBilhetes,

      //vezes discado
      vezesDiscadoBilhete: req.body.vezesDiscadoBilhetes,

      exportarCSVTF: req.body.exportarCSVTrueFalse
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;
    var queryConsulta = null;
    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null){
      if (queryPesquisa == 'Data de início é maior que a atual.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      }else if (queryPesquisa == 'Data de início está vazia.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      }else if (queryPesquisa == 'Insira um período de data para busca.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      }else if (queryPesquisa == 'Hora de início de discagem é maior que a de fim.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de discagem é maior que a de fim.'
        });
      }else if (queryPesquisa == 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'
        });
      }else{

        var query = 'SELECT COUNT(*) as resultado FROM cdr, contato, status, campanha '+ queryPesquisa +' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
        pg.query(query, [], (err, ans) => {
          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro ao selecionar dados no servidor'
            });
          } else {
            var count = ans.rows[0];

            //Verificar se não tem bilhete registrado
            if (count.count == 0){
              return res.status(500).send({
                contador: count,
                message: 'Nenhum bilhete registrado!'
              });
            }else{

              var pagination = req.body.pagination;

              if (pagination == null || pagination == 1){
                pagination = 0;
              }else if (pagination > 1){
                pagination = pagination*10 - 10;
              }

              if (object.exportarCSVTF){
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                queryConsulta = 'SELECT * FROM cdr, contato, status, campanha '+ queryPesquisa +' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    res.json(ans.rows);
                  }
                });
              }else{
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                queryConsulta = 'SELECT * FROM cdr, contato, status, campanha '+ queryPesquisa +' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY cdr_id DESC LIMIT 10 OFFSET '+pagination;
                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    var data = new Object();
                    data.contador = count;
                    data.result = ans.rows;
                    res.json(data);
                  }
                });

              }

            }
          }
        });
      }

    } else {
      var query = 'SELECT COUNT(*) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
      pg.query(query, [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao selecionar dados no servidor'
          });
        } else {
          var count = ans.rows[0];

          //Verificar se não tem bilhete registrado
          if (count.count == 0){
            return res.status(500).send({
              contador: count,
              message: 'Nenhum bilhete registrado!'
            });
          }else{
            var pagination = req.body.pagination;

            if (pagination == null || pagination == 1){
              pagination = 0;
            }else if (pagination > 1){
              pagination = pagination*10 - 10;
            }

            if (object.exportarCSVTF){
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              queryConsulta = 'SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  res.json(ans.rows);
                }
              });
            }else{
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              queryConsulta = 'SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ORDER BY cdr_id DESC LIMIT 10 OFFSET '+pagination;
              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  var data = new Object();
                  data.contador = count;
                  data.result = ans.rows;
                  res.json(data);
                }
              });
            }
          }
        }
      });
    }
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item){
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //**********************************discagem**********************************
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
      //Hora de inicio e fim
      var horaInicio = item.horaInicioDiscagemBilhete;
      var date = new Date();
      var horaFim = ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());

      //Data Inicio
      var dateInicio = new Date(item.dataInicioDiscagemBilhete);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioDiscagemBilhete = dateInicio.getFullYear() + "-" + (dateInicio.getMonth()+1) + "-" + ((dateInicio.getDate()<10?'0':'') +dateInicio.getDate()) +" "+horaInicio;

      //Data fim
      var dataFimDiscagemBilhete = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + ((date.getDate()<10?'0':'') + date.getDate())+ " "+ horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioDiscagemBilhete).valueOf();
      var fim = new Date(dataFimDiscagemBilhete).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'"+dataInicioDiscagemBilhete+ "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ dataInicioDiscagemBilhete + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (preenchido no inicio da hora e data)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
      //Hora de inicio e fim
      var horaInicio = item.horaInicioDiscagemBilhete;
      var horaFim = item.horaFimDiscagemBilhete

      //Data Inicio
      var dateInicio = new Date(item.dataInicioDiscagemBilhete);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioDiscagemBilhete = dateInicio.getFullYear() + "-" + (dateInicio.getMonth()+1) + "-" + ((dateInicio.getDate()<10?'0':'') +dateInicio.getDate()) +" "+horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimDiscagemBilhete);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimDiscagemBilhete = dateFim.getFullYear() + "-" + (dateFim.getMonth()+1) + "-" + ((dateFim.getDate()<10?'0':'') +dateFim.getDate()) +" "+horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioDiscagemBilhete).valueOf();
      var fim = new Date(dataFimDiscagemBilhete).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'"+dataInicioDiscagemBilhete+ "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ dataInicioDiscagemBilhete + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (tudo preenchido - data e hora)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
      //Hora de inicio e fim
      var horaInicio = item.horaInicioDiscagemBilhete;
      var horaFim = item.horaFimDiscagemBilhete

      //Data Inicio
      var dateInicio = new Date(item.dataInicioDiscagemBilhete);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioDiscagemBilhete = dateInicio.getFullYear() + "-" + (dateInicio.getMonth()+1) + "-" + ((dateInicio.getDate()<10?'0':'') +dateInicio.getDate()) +" "+horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimDiscagemBilhete);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimDiscagemBilhete = dateFim.getFullYear() + "-" + (dateFim.getMonth()+1) + "-" + ((dateFim.getDate()<10?'0':'') +dateFim.getDate()) +" "+horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioDiscagemBilhete).valueOf();
      var fim = new Date(dataFimDiscagemBilhete).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'"+dataInicioDiscagemBilhete+ "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ dataInicioDiscagemBilhete + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (hora vazio e data preenchida)
  if (item.horaInicioDiscagemBilhete == '' && item.horaFimDiscagemBilhete == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
      //Data Inicio
      var dateInicio = new Date(item.dataInicioDiscagemBilhete);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioDiscagemBilhete = dateInicio.getFullYear() + "-" + (dateInicio.getMonth()+1) + "-" + ((dateInicio.getDate()<10?'0':'') +dateInicio.getDate()) + " 00:00";

      //Data fim
      var date = new Date();
      var dataFimDiscagemBilhete = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + ((date.getDate()<10?'0':'') +date.getDate()) + " " +
      date.getHours() + ":" + date.getMinutes();

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioDiscagemBilhete).valueOf();
      var fim = new Date(dataFimDiscagemBilhete).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'" +dataInicioDiscagemBilhete+ "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'" +dataInicioDiscagemBilhete+ "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas.
    }else if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
      //Data Inicio
      var dateInicio = new Date(item.dataInicioDiscagemBilhete);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioDiscagemBilhete = dateInicio.getFullYear() + "-" + (dateInicio.getMonth()+1) + "-" + ((dateInicio.getDate()<10?'0':'') +dateInicio.getDate()) + " 00:00";

      //Data Inicio
      var dateFim = new Date(item.dataFimDiscagemBilhete);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimDiscagemBilhete = dateFim.getFullYear() + "-" + (dateFim.getMonth()+1) + "-" + ((dateFim.getDate()<10?'0':'') +dateFim.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioDiscagemBilhete).valueOf();
      var fim = new Date(dataFimDiscagemBilhete).valueOf();

      if (inicio < fim){dataHoraInicio
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'" +dataInicioDiscagemBilhete + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'" +dataInicioDiscagemBilhete + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    }else if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete != ''){
      return 'Data de início está vazia.';
    }
  }

  //Validação horario de discagem (hora preenchida e data vazia)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }else if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete == ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }
  //****************************Fim data e hora de discagem***********************

  //Validação contato
  if (item.nomeContatoBilhete != ''){
    if (count > 0){
      query +=' AND contato_nome ILIKE '+ "'%" +item.nomeContatoBilhete+ "%'";
    }else{
      query +='contato_nome ILIKE '+ "'%" +item.nomeContatoBilhete+ "%'";
    }
    count++;
  }

  //Validação Status chamada
  if (item.statusChamadaBilhete != ''){
    if (count > 0){
      query +=' AND cdr_status_chamada = '+ "'" +item.statusChamadaBilhete+ "'";
    }else{
      query +='cdr_status_chamada = '+ "'" +item.statusChamadaBilhete+ "'";
    }
    count++;
  }

  //Validação dtmf discado
  if (item.dtmfDiscadoBilhete != ''){
    if (count > 0){
      query +=' AND cdr_dtmf ILIKE '+ "'%" +item.dtmfDiscadoBilhete+ "%'";
    }else{
      query +='cdr_dtmf ILIKE '+ "'%" +item.dtmfDiscadoBilhete+ "%'";
    }
    count++;
  }

  //Validação Tipo Atendimento
  if (item.tipoAtendimentoBilhete != ''){
    if (count > 0){
      query +=' AND cdr_tipo_atendimento = '+ "'" +item.tipoAtendimentoBilhete+ "'";
    }else{
      query +='cdr_tipo_atendimento = '+ "'" +item.tipoAtendimentoBilhete+ "'";
    }
    count++;
  }

  //Validação Telefone Discado
  if (item.telDiscadoBilhete != ''){
    if (count > 0){
      query +=' AND cdr_tel_discado ILIKE '+ "'%" +item.telDiscadoBilhete+ "%'";
    }else{
      query +='cdr_tel_discado ILIKE '+ "'%" +item.telDiscadoBilhete+ "%'";
    }
    count++;
  }

  //Validação telfone 1
  if (item.tel1ContatoBilhete != ''){
    if (count > 0){
      query +=' AND contato_tel1 ILIKE '+ "'%" +item.tel1ContatoBilhete+ "%'";
    }else{
      query +='contato_tel1 ILIKE '+ "'%" +item.tel1ContatoBilhete+ "%'";
    }
    count++;
  }

  //Validação telfone 2
  if (item.tel2ContatoBilhete != ''){
    if (count > 0){
      query +=' AND contato_tel2 ILIKE '+ "'%" +item.tel2ContatoBilhete+ "%'";
    }else{
      query +='contato_tel2 ILIKE '+ "'%" +item.tel2ContatoBilhete+ "%'";
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}
