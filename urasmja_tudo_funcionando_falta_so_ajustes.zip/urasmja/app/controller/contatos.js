const pg = require('../db');

module.exports = {
  select: (req, res) => {
    var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        var count = ans.rows[0].resultado;

        //Verificar se existe contatos cadastrados
        if (count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhum contato registrado até o momento!'
          });
        } else {
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }

          var query =
            'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 ' +
            'FROM cdr, contato, status, campanha ' +
            'WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ' +
            'ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET ' + pagination;
          console.log("Query " + query)
          pg.query(query, [], (err, ans) => {
            if (err) {
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Erro ao selecionar dados no servidor'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      dataInicioChamadaContato: req.body.dataInicioChamadaContatos,
      dataFimChamadaContato: req.body.dataFimChamadaContatos,

      horaInicioChamadaContato: req.body.horaInicioChamadaContatos,
      horaFimChamadaContato: req.body.horaFimChamadaContatos,

      nomeContato: req.body.nomeContatos,
      nomeCampanhaContato: req.body.nomeCampanhaContatos,
      tel1Contato: req.body.tel1Contatos,
      tel2Contato: req.body.tel2Contatos,

      exportarCSVTF: req.body.exportarCSVTrueFalse
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;
    var queryConsulta = null;
    console.log("\n\nObjecto: " + object.nomeContato)
    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null) {
      if (queryPesquisa == 'Data de início é maior que a atual.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      } else if (queryPesquisa == 'Data de início está vazia.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      } else if (queryPesquisa == 'Insira um período de data para busca.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      } else if (queryPesquisa == 'Hora de início de consulta é maior que a de fim.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de consulta é maior que a de fim.'
        });
      } else if (queryPesquisa == 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'
        });
      } else {
        var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha ' + queryPesquisa + ' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
        console.log("\n\nQuery count: " + query)
        pg.query(query, [], (err, ans) => {
          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro ao selecionar dados no servidor'
            });
          } else {
            var count = ans.rows[0];

            if (count.resultado == 0) {
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Nenhum dado encontrado!'
              });
            } else {

              var pagination = req.body.pagination;

              if (pagination == null || pagination == 1) {
                pagination = 0;
              } else if (pagination > 1) {
                pagination = pagination * 10 - 10;
              }

              if (object.exportarCSVTF) {
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 ' +
                  'FROM cdr, contato, status, campanha ' + queryPesquisa + ' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ' +
                  'ORDER BY contato_id, cdr_data_hora_chamada ';
                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    res.json(ans.rows);
                  }
                });
              } else {
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 ' +
                  'FROM cdr, contato, status, campanha ' + queryPesquisa + ' AND contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ' +
                  'ORDER BY contato_id, cdr_data_hora_chamada ' +
                  'DESC LIMIT 10 OFFSET ' + pagination;
                console.log("\n\nQuery consult: " + queryConsulta)
                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    var data = new Object();
                    data.contador = count;
                    data.result = ans.rows;
                    res.json(data);
                  }
                });
              }
            }
          }
        });
      }
    } else {
      var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id';
      console.log("\n\nQuery count: " + query)
      pg.query(query, [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao selecionar dados no servidor'
          });
        } else {
          var count = ans.rows[0];

          if (count.resultado == 0) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Nenhum dado encontrado!'
            });
          } else {

            var pagination = req.body.pagination;

            if (pagination == null || pagination == 1) {
              pagination = 0;
            } else if (pagination > 1) {
              pagination = pagination * 10 - 10;
            }

            if (object.exportarCSVTF) {
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 ' +
                'FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ' +
                'ORDER BY contato_id, cdr_data_hora_chamada ';
              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  res.json(ans.rows);
                }
              });
            } else {
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, contato_tel1, contato_tel2 ' +
                'FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id ' +
                'ORDER BY contato_id, cdr_data_hora_chamada ' +
                'DESC LIMIT 10 OFFSET ' + pagination;
              console.log("\n\nQuery consult 12: " + queryConsulta)
              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  var data = new Object();
                  data.contador = count;
                  data.result = ans.rows;
                  res.json(data);
                }
              });
            }
          }
        }
      });
    }
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item) {
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //*******************************consulta***************************************
  if (item.horaInicioChamadaContato != '' && item.horaFimChamadaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {
      var horaInicio = item.horaInicioChamadaContato;

      var dateConverter = new Date(item.dataInicioChamadaContato);
      var dataHoraInicio = (((dateConverter.getDate() + 1) < 10 ? '0' : '') + (dateConverter.getDate() + 1)) + "/" + (dateConverter.getMonth() + 1) + "/" + dateConverter.getFullYear();

      var date = new Date();
      var horaFim = ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ":" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());
      var dataHoraFim = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + (date.getMonth() + 1) + "/" + date.getFullYear() + " " + horaFim;

      var inicio = new Date(item.dataInicioChamadaContato + " " + horaInicio).valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataHoraInicio + " " + horaInicio + "'" + ' AND ' + "'" + dataHoraFim + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataHoraInicio + " " + horaInicio + "'" + ' AND ' + "'" + dataHoraFim + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Preenchido no inicio e fim da hora e na data somente o inicio)
  if (item.horaInicioChamadaContato != '' && item.horaFimChamadaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {
      var horaInicio = item.horaInicioChamadaContato;

      var dateConverter = new Date(item.dataInicioChamadaContato);
      var dataHoraInicio = (((dateConverter.getDate() + 1) < 10 ? '0' : '') + (dateConverter.getDate() + 1)) + "/" + (dateConverter.getMonth() + 1) + "/" + dateConverter.getFullYear();

      var horaFim = item.dataFimChamadaContato

      var date = new Date();
      var dataHoraFim = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();

      var inicio = new Date(item.dataInicioChamadaContato + " " + horaInicio).valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataHoraInicio + " " + horaInicio + "'" + ' AND ' + "'" + dataHoraFim + " " + horaFim + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataHoraInicio + " " + horaInicio + "'" + ' AND ' + "'" + dataHoraFim + " " + horaFim + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação consulta (tudo preenchido - data e hora)
  if (item.horaInicioChamadaContato != '' && item.horaFimChamadaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato != '') {
      var horaInicio = item.horaInicioChamadaContato;

      var dateConverter = new Date(item.dataInicioChamadaContato);
      var dataHoraInicio = (((dateConverter.getDate() + 1) < 10 ? '0' : '') + (dateConverter.getDate() + 1)) + "/" + (dateConverter.getMonth() + 1) + "/" + dateConverter.getFullYear();

      var horaFim = item.horaFimChamadaContato;

      var dateConverterFim = new Date(item.dataFimChamadaContato);
      var dataHoraFim = (((dateConverterFim.getDate() + 1) < 10 ? '0' : '') + (dateConverterFim.getDate() + 1)) + "/" + (dateConverterFim.getMonth() + 1) + "/" + dateConverterFim.getFullYear();

      var dataHoraFimConversao = dateConverterFim.getFullYear() + "-" + (dateConverterFim.getMonth() + 1) + "-" + (((dateConverterFim.getDate() + 1) < 10 ? '0' : '') + (dateConverterFim.getDate() + 1));
      var inicio = new Date(item.dataInicioChamadaContato + " " + horaInicio).valueOf();
      var fim = new Date(dataHoraFimConversao + " " + horaFim).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataHoraInicio + " " + horaInicio + "'" + ' AND ' + "'" + dataHoraFim + " " + horaFim + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataHoraInicio + " " + horaInicio + "'" + ' AND ' + "'" + dataHoraFim + " " + horaFim + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação consulta (hora vazio e data preenchida)
  if (item.horaInicioChamadaContato == '' && item.horaFimChamadaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {

      var dateConverter = new Date(item.dataInicioChamadaContato);
      var dataInicio = (((dateConverter.getDate() + 1) < 10 ? '0' : '') + (dateConverter.getDate() + 1)) + "/" + (dateConverter.getMonth() + 1) + "/" + dateConverter.getFullYear();

      var date = new Date();
      var dataFim = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + (date.getMonth() + 1) + "/" + date.getFullYear() + " " +
        ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ":" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

      var inicio = new Date(item.dataInicioChamadaContato + " 00:00").valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicio + " 00:00" + "'" + ' AND ' + "'" + dataFim + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicio + " 00:00" + "'" + ' AND ' + "'" + dataFim + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas.
    } else if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato != '') {
      var dateConverter = new Date(item.dataInicioChamadaContato);
      var dataInicio = (((dateConverter.getDate() + 1) < 10 ? '0' : '') + (dateConverter.getDate() + 1)) + "/" + (dateConverter.getMonth() + 1) + "/" + dateConverter.getFullYear();

      var dateConverterFim = new Date(item.dataFimChamadaContato);
      var dataHoraFim = (((dateConverterFim.getDate() + 1) < 10 ? '0' : '') + (dateConverterFim.getDate() + 1)) + "/" + (dateConverterFim.getMonth() + 1) + "/" + dateConverterFim.getFullYear();

      var inicio = new Date(item.dataInicioChamadaContato + " 00:00").valueOf();
      var fim = new Date(dateConverterFim).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicio + " 00:00" + "'" + ' AND ' + "'" + dataHoraFim + " 23:59" + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicio + " 00:00" + "'" + ' AND ' + "'" + dataHoraFim + " 23:59" + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    } else if (item.dataInicioChamadaContato == '' && item.dataFimChamadaContato != '') {
      return 'Data de início está vazia.';
    }
  }

  //Validação horario de discagem (hora preenchida e data vazia)
  if (item.horaInicioChamadaContato != '' && item.horaFimChamadaContato != '') {
    //Data de início e fim não está preenchida
    if (item.dataInicioChamadaContato == '' && item.dataFimChamadaContato == '') {
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  } else if (item.horaInicioChamadaContato != '' && item.horaFimChamadaContato == '') {
    //Data de início e fim não está preenchida
    if (item.dataInicioChamadaContato == '' && item.dataFimChamadaContato == '') {
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }
  //**************************Fim data e hora de consulta **********************

  //Validação campanha
  if (item.nomeCampanhaContato != '') {
    if (count > 0) {
      query += ' AND campanha_nome ILIKE ' + "'%" + item.nomeCampanhaContato + "%'";
    } else {
      query += 'campanha_nome ILIKE ' + "'%" + item.nomeCampanhaContato + "%'";
    }
    count++;
  }

  //Validação telfone 1
  if (item.tel1Contato != '') {
    if (count > 0) {
      query += ' AND contato_tel1 ILIKE ' + "'%" + item.tel1Contato + "%'";
    } else {
      query += 'contato_tel1 ILIKE ' + "'%" + item.tel1Contato + "%'";
    }
    count++;
  }

  //Validação telfone 2
  if (item.tel2Contato != '') {
    if (count > 0) {
      query += ' AND contato_tel2 ILIKE ' + "'%" + item.tel2Contato + "%'";
    } else {
      query += 'contato_tel2 ILIKE ' + "'%" + item.tel2Contato + "%'";
    }
    count++;
  }

  //Validação Contato
  if (item.nomeContato != '' || item.nomeContato === undefined) {
    if (count > 0) {
      query += ' AND contato_nome ILIKE ' + "'%" + item.nomeContato + "%'";
    } else {
      query += 'contato_nome ILIKE ' + "'%" + item.nomeContato + "%'";
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}
