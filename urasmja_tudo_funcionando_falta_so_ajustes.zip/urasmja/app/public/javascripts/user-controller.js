function validarCredencial() {

    var username = document.getElementById('inputUsernameCadastro').value;
    var password = document.getElementById('inputPasswordCadastro').value;
    var red_alert = document.getElementById('red-alert');

    red_alert.style.visibility = 'none';

    if (username == '' || password == '') {
        return;
    }

    var object = new Object();
    object.username = username;
    object.password = password;

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    atualizaUsuarios();
                    alert(JSON.parse(this.response).message)
                    break;

                case 304:
                    atualizaUsuarios();
                    alert(JSON.parse(this.response).message)
                    break;

                case 400:
                    break;

                case 401:
                    red_alert.innerHTML = 'Usuário já existente no sistema.';
                    red_alert.classList.add('show')
                    setTimeout(() => {
                        red_alert.classList.remove('show')
                    }, 2000)
                    break;

                case 500:
                    red_alert.innerHTML = 'Erro interno com o servidor.';
                    red_alert.classList.add('show')
                    setTimeout(() => {
                        red_alert.classList.remove('show')
                    }, 2000)
                    break;

                case 404:
                    red_alert.innerHTML = 'Não foi possível alcançar o servidor.';
                    red_alert.classList.add('show')
                    setTimeout(() => {
                        red_alert.classList.remove('show')
                    }, 2000)
                    break;

                case 200:
                    window.open("/", "_self");
                    break;

                default:
                    red_alert.innerHTML = 'Erro inesperado, contate o administrador.'
                    red_alert.classList.add('show')
                    setTimeout(() => {
                        red_alert.classList.remove('show')
                    }, 2000)
                    break;
            }
        }
    }
    xhttp.open("POST", '/users/insercao', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
}

function atualizaUsuarios() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/users/select')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    addElementsToTable(JSON.parse(this.response))
                    break;
                case 304:
                    addElementsToTable(JSON.parse(this.response))
                    break;
                case 500:
                    console.log("Erro interno com o servidor.");
                    break;
                default:
                    console.log("Erro inesperado, contate o administrador.");
                    break;
            }
        }
    }

    xhttp.send()
}

function addElementsToTable(rows) {
    //Pegar referencia da tabela de usuários
    const table = document.querySelector('#tabelaUsuarios tbody');

    while (table.hasChildNodes()) {
        table.removeChild(table.firstChild);
    }

    for (var i = 0; i < rows.length; i++) {
        var newRow = table.insertRow(i)
        var count = 0

        var actionCell = newRow.insertCell(count)

        var usuarioCell = newRow.insertCell(count)
        var usuarioValue = document.createTextNode(rows[i].usuario_login)
        usuarioCell.appendChild(usuarioValue)
        count++;

        if (usuarioCell.innerHTML == 'admin') {
            // botao editar
            var editarCell = newRow.insertCell(count)
            var editarElement = document.createElement('input')
            editarElement.setAttribute('type', 'button')
            editarElement.setAttribute('value', 'Editar')
            editarElement.setAttribute('data-toggle', "modal")
            editarElement.setAttribute('data-target', "#myModal2")
            editarElement.classList.add('btn')
            editarElement.classList.add('btn-outline')
            editarElement.classList.add('btn-warning')
            editarElement.onclick = editItem(rows[i])
            editarCell.appendChild(editarElement)
            count++;
        } else {

            // botao editar
            var editarCell = newRow.insertCell(count)
            var editarElement = document.createElement('input')
            editarElement.setAttribute('type', 'button')
            editarElement.setAttribute('value', 'Editar')
            editarElement.setAttribute('data-toggle', "modal")
            editarElement.setAttribute('data-target', "#myModal2")
            editarElement.classList.add('btn')
            editarElement.classList.add('btn-outline')
            editarElement.classList.add('btn-warning')
            editarElement.onclick = editItem(rows[i])
            editarCell.appendChild(editarElement)
            count++;

            // botao excluir
            var excluirCell = newRow.insertCell(count)
            var excluirElement = document.createElement('input')
            excluirElement.setAttribute('type', 'button')
            excluirElement.setAttribute('value', 'Excluir')
            excluirElement.classList.add('btn')
            excluirElement.classList.add('btn-outline')
            excluirElement.classList.add('btn-danger')
            excluirElement.classList.add('dim')
            excluirElement.onclick = deleteItem(rows[i])
            excluirCell.appendChild(excluirElement)
            count++;
        }
    }
}
var itemEditar;

function editItem(item) {
    return function () {
        itemEditar = item;
        document.getElementById('inputUsernameEditar').value = item.usuario_login
    }
}

function deleteItem(item) {
    return function () {

        var xhttp = new XMLHttpRequest();
        xhttp.open('POST', '/users/delete')

        var object = new Object()
        object.id = item.usuario_id

        xhttp.onreadystatechange = function () {
            if (this.readyState == 4) {
                switch (this.status) {
                    case 200:
                        atualizaUsuarios();
                        alert(JSON.parse(this.response).message)
                        break;

                    case 304:
                        atualizaUsuarios();
                        alert(JSON.parse(this.response).message)
                        break;
                }
            }
        }
        xhttp.setRequestHeader('Content-Type', 'application/json')
        xhttp.send(JSON.stringify(object));
    }
}

function alert(message) {
    if (!message.localeCompare('Impossível excluir o usuário com a sessão aberta!')) {
        var success = document.getElementById('red-alert_sistema')
        success.innerHTML = message + ' Contate o administrador.'
        success.classList.add('show')
        setTimeout(() => {
            success.classList.remove('show');
            location.reload();
        }, 3000);
    } else {
        var success = document.getElementById('success')
        success.innerHTML = message
        success.classList.add('show')
        setTimeout(() => {
            success.classList.remove('show')
            location.reload();
        }, 3000);
    }
}

function validarCredencialEdicao() {

    var password = document.getElementById('inputPasswordEditar').value;
    var red_alert_modal = document.getElementById('red-alert_modal');

    red_alert_modal.style.visibility = 'none';

    if (password == '') {
        red_alert_modal.innerHTML = 'Campo senha vazio.';
        red_alert_modal.classList.add('show')
        setTimeout(() => {
            red_alert_modal.classList.remove('show')
        }, 2000)
        return;
    }

    var xhttp = new XMLHttpRequest();

    var object = new Object()
    object.id = itemEditar.usuario_id
    object.password = password

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    atualizaUsuarios();
                    alert(JSON.parse(this.response).message)
                    password.innerHTML = ''
                    $('#myModal2').modal('hide')
                    break;

                case 304:
                    atualizaUsuarios();
                    alert(JSON.parse(this.response).message)
                    password.innerHTML = ''
                    $('#myModal2').modal('hide')
                    break;

                case 500:
                    password.innerHTML = ''
                    red_alert_modal.innerHTML = 'Erro interno com o servidor.';
                    red_alert_modal.classList.add('show')
                    setTimeout(() => {
                        red_alert_modal.classList.remove('show')
                    }, 2000)
                    break;

                case 404:
                    password.innerHTML = ''
                    red_alert_modal.innerHTML = 'Não foi possível alcançar o servidor.';
                    red_alert_modal.classList.add('show')
                    setTimeout(() => {
                        red_alert_modal.classList.remove('show')
                    }, 2000)
                    break;

                case 200:
                    window.open("/", "_self");
                    break;

                default:
                    password.innerHTML = ''
                    red_alert_modal.innerHTML = 'Erro inesperado, contate o administrador.'
                    red_alert_modal.classList.add('show')
                    setTimeout(() => {
                        red_alert_modal.classList.remove('show')
                    }, 2000)
                    break;
            }
        }
    }
    xhttp.open('POST', '/users/update');
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(JSON.stringify(object));
}
