//Variaveis no escopo global para reduzir suas instancias
var selecionarCampanha = document.getElementById("selecionarCampanha");
var stopCp = document.getElementById("stopCp");
var playCp = document.getElementById("playCp");
var playGrayCp = document.getElementById("playGrayCp");
var pauseCp = document.getElementById("pauseCp");
var pauseGrayCp = document.getElementById("pauseGrayCp");
var restartCp = document.getElementById("restartCp");


var totalContatos = $("#totalContatos");
var totalDiscagens = $("#totalDiscagens");
var totalDTMF1 = $("#totalDTMF1");
var totalDTMF2 = $("#totalDTMF2");
var totalDTMF3 = $("#totalDTMF3");
var totalAtendidas = $("#totalAtendidas");
var totalNaoAtendidas = $("#totalNaoAtendidas");
var emExecucaoGerenciamento = document.getElementById("emExecucaoGerenciamento");

//Variavel global para receber a referencia vinda do BD
var json = null;

var campanhaVigente = null;
var campanhaVigenteValue = null;

function atualizaGerenciamentoCampanhas() {
  var red_alert = document.getElementById('red_alert_gerenciamento');
  red_alert.style.visibility = 'none';

  //Esconder todos os botões quando abrir a tela
  botoesEscondidos();
  dadosZerados();

  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/campanha/selectSomenteCampanhas')

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          if (JSON.parse(this.response).contador == 0) {
            emExecucaoGerenciamento.value = 'Nenhuma campanha em execução.';
          }
          inserirCampanhasSelect(JSON.parse(this.response));
          break;

        case 304:
          if (JSON.parse(this.response).contador == 0) {
            emExecucaoGerenciamento.value = 'Nenhuma campanha em execução.';
          }
          inserirCampanhasSelect(JSON.parse(this.response));
          break;

        case 400:
          if (JSON.parse(this.response).contador == 0) {
            emExecucaoGerenciamento.value = 'Nenhuma campanha em execução.';
          }
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          if (JSON.parse(this.response).contador == 0) {
            emExecucaoGerenciamento.value = 'Nenhuma campanha em execução.';
          }
          alertForm(JSON.parse(this.response).message);
          break;

        case 404:
          alertForm('Não foi possível alcançar o servidor');
          break;

        default:
          alertForm('Erro inesperado, contate o administrador');
          break;
      }
    }
  }
  xhttp.send();
}

function buscarCampanhaAtiva() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/campanha/selectCampanhaAtiva')

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          //Verificação para saber se tem alguma campanha ativa ou não
          if (JSON.parse(this.response).contador == 0) {
            selecionarCampanha.selectedIndex = "0";
          } else if (JSON.parse(this.response).contador == 1) {
            //Existe uma campanha ativa e é necessario já mostrar seus dados.
            document.getElementById(JSON.parse(this.response).campanha.trim()).selected = "true";
            escolherCampanha();
          }

          //Mostrar status da tela
          emExecucaoGerenciamento.value = JSON.parse(this.response).message;
          break;

        case 304:
          //Verificação para saber se tem alguma campanha ativa ou não
          if (JSON.parse(this.response).contador == 0) {
            selecionarCampanha.selectedIndex = "0";
          } else if (JSON.parse(this.response).contador == 1) {
            //Existe uma campanha ativa e é necessario já mostrar seus dados.
            document.getElementById(JSON.parse(this.response).campanha.trim()).selected = "true";
            escolherCampanha();
          }

          //Mostrar status da tela
          emExecucaoGerenciamento.value = JSON.parse(this.response).message;
          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          break;

        case 404:
          alertForm('Não foi possível alcançar o servidor');
          break;

        default:
          alertForm('Erro inesperado, contate o administrador');
          break;
      }
    }
  }
  xhttp.send();
}

function inserirCampanhasSelect(rows) {
  //Pegar referencia do select(combobox) das campanhas
  for (var i = 0; i < rows.length; i++) {
    selecionarCampanha;
    var option = document.createElement("option");
    option.value = i + 1;
    option.text = rows[i].campanha_nome.trim();
    option.id = rows[i].campanha_nome.trim();
    selecionarCampanha.append(option);
  }
  buscarCampanhaAtiva();

}

function botoesEscondidos() {
  playCp.style.display = "none";
  restartCp.style.display = "none";
  playGrayCp.style.display = "none";
  stopCp.style.display = "none";
  pauseCp.style.display = "none";
  pauseGrayCp.style.display = "none";
}

function iniciarBotoes() {
  playCp.style.display = "inline-block";
  restartCp.style.display = "none";
  playGrayCp.style.display = "none";
  stopCp.style.display = "none";
  pauseCp.style.display = "none";
  pauseGrayCp.style.display = "inline-block";
}
function reiniciarCampanha() {
  playCp.style.display = "none";
  restartCp.style.display = "none";
  playGrayCp.style.display = "inline-block";
  stopCp.style.display = "inline-block";
  pauseCp.style.display = "inline-block";
  pauseGrayCp.style.display = "none";

  //Buscando o nome da campanha clicada
  var xhttp = new XMLHttpRequest();

  var object = {
    campanhaVigente: campanhaVigente
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:

          break;

        case 304:

          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          //Iniciar os botoes de maneira mais facil
          iniciarBotoes();

          dadosZerados();
          break;

        default:
          alertForm("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/reiniciarCampanha', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function iniciarCampanha() {
  playCp.style.display = "none";
  restartCp.style.display = "none";
  playGrayCp.style.display = "inline-block";
  stopCp.style.display = "inline-block";
  pauseCp.style.display = "inline-block";
  pauseGrayCp.style.display = "none";

  //Buscando o nome da campanha clicada
  var xhttp = new XMLHttpRequest();

  var object = {
    campanhaVigente: campanhaVigente
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:

          break;

        case 304:

          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          //Iniciar os botoes de maneira mais facil
          iniciarBotoes();

          dadosZerados();
          break;

        default:
          alertForm("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/iniciarCampanha', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function pausarCampanha() {
  playCp.style.display = "none";
  restartCp.style.display = "inline-block";
  playGrayCp.style.display = "none";
  stopCp.style.display = "none";
  pauseCp.style.display = "none";
  pauseGrayCp.style.display = "inline-block";

  //Buscando o nome da campanha clicada
  var xhttp = new XMLHttpRequest();

  var object = {
    campanhaVigente: campanhaVigente
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:

          break;

        case 304:

          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          break;

        default:
          alertForm("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/pausarCampanha', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function pararCampanha() {
  //Fechar o modal aberto para que não tenha sobreposição de mensagens!
  $('#fecharModalGerenciamento').click();

  //Abrir requisicao HTTP para acessar o servidor.
  var xhttp = new XMLHttpRequest();

  //Buscando o nome da campanha clicada
  var object = {
    campanhaVigente: campanhaVigente
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          swal("Deletado!", "Esta campanha estará disponível no histórico apartir de agora.\nEsperamos que ela tenha sido um sucesso com seus contatos. :)", "success");
          setTimeout(() => {
            location.reload();
          }, 4500);
          break;

        case 304:
          swal("Deletado!", "Esta campanha estará disponível no histórico apartir de agora.\nEsperamos que ela tenha sido um sucesso com seus contatos. :)", "success");
          setTimeout(() => {
            location.reload();
          }, 4500);
          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          break;

        default:
          alertForm("Erro inesperado, contate o administrador.");
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/pararCampanha', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));

}

function escolherCampanha() {
  //Inicialmente deixar os botões escondidados até que o usuario escolha a campanha
  botoesEscondidos();

  //Buscando o value da campanha clicada
  campanhaVigenteValue = selecionarCampanha.options[selecionarCampanha.selectedIndex].value;

  if (campanhaVigenteValue == 0) {
    botoesEscondidos();
    dadosZerados();
  } else {
    //Buscando o nome da campanha clicada
    campanhaVigente = selecionarCampanha.options[selecionarCampanha.selectedIndex].text;

    var xhttp = new XMLHttpRequest();

    var object = {
      campanhaVigente: campanhaVigente
    }

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            //Objeto JSON recebido da requisição no servidor
            json = JSON.parse(this.response);

            //Verificar se o retorno foi 1 -> existe campanha em status ativado = TRUE
            if (json.ativado == 1) {
              if (json.pausado == 0) {
                playCp.style.display = "none";
                restartCp.style.display = "none";
                playGrayCp.style.display = "inline-block";
                stopCp.style.display = "inline-block";
                pauseCp.style.display = "inline-block";
                pauseGrayCp.style.display = "none";

              } else if (json.pausado == 1) {
                playCp.style.display = "none";
                restartCp.style.display = "inline-block";
                playGrayCp.style.display = "none";
                stopCp.style.display = "none";
                pauseCp.style.display = "none";
                pauseGrayCp.style.display = "inline-block";
              }
              //Mostrar dados da campanha
              mostrarValores();

              //Verificar se o retorno foi 0 -> existe campanha em status ativado = FALSE
            } else if (json.ativado == 0 && json.pausado == 0) {
              //Iniciar os botoes de maneira mais facil
              iniciarBotoes();

              //Mesmo podendo ter acesso a quantidade de contatos. Ela será visível so quando iniciar a campanha
              dadosZerados();
            }
            break;

          case 304:
            //Objeto JSON recebido da requisição no servidor
            json = JSON.parse(this.response);

            //Verificar se o retorno foi 1 -> existe campanha em status ativado = TRUE
            if (json.ativado == 1) {
              if (json.pausado == 0) {
                playCp.style.display = "none";
                restartCp.style.display = "none";
                playGrayCp.style.display = "inline-block";
                stopCp.style.display = "inline-block";
                pauseCp.style.display = "inline-block";
                pauseGrayCp.style.display = "none";

              } else if (json.pausado == 1) {
                playCp.style.display = "none";
                restartCp.style.display = "inline-block";
                playGrayCp.style.display = "none";
                stopCp.style.display = "none";
                pauseCp.style.display = "none";
                pauseGrayCp.style.display = "inline-block";
              }
              //Mostrar dados da campanha
              mostrarValores();

              //Verificar se o retorno foi 0 -> existe campanha em status ativado = FALSE
            } else if (json.ativado == 0) {
              //Iniciar os botoes de maneira mais facil
              iniciarBotoes();

              //Mesmo podendo ter acesso a quantidade de contatos. Ela será visível so quando iniciar a campanha
              dadosZerados();
            }
            break;

          case 400:
            alertForm(JSON.parse(this.response).message);
            break;

          case 500:
            alertForm(JSON.parse(this.response).message);
            break;

          default:
            alertForm("Erro inesperado, contate o administrador.");
            break;
        }
      }
    }
    xhttp.open('POST', '/campanha/selectDadosCampanhaVigente', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
  }
}

function mostrarValores() {
  totalContatos.val(json.totalContatos);
  totalDiscagens.val(json.totalDiscagens);
  totalDTMF1.val(json.totalDTMF1);
  totalDTMF2.val(json.totalDTMF2);
  totalDTMF3.val(json.totalDTMF3);
  totalAtendidas.val(json.totalAtendidas);
  totalNaoAtendidas.val(json.totalNaoAtendidas);
}

function alertForm(message) {
  var red_alert = document.getElementById('red_alert_gerenciamento');
  red_alert.style.visibility = 'none';
  red_alert.innerHTML = message;
  red_alert.classList.add('show')
  setTimeout(() => {
    red_alert.classList.remove('show')
  }, 3000);
}

function dadosZerados() {
  totalContatos.val('0');
  totalDiscagens.val('0');
  totalDTMF1.val('0');
  totalDTMF2.val('0');
  totalDTMF3.val('0');
  totalAtendidas.val('0');
  totalNaoAtendidas.val('0');
}
