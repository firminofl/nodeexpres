#!/bin/bash
#+--------------------------------------------------------------------------------------------------------------------------------------------+
#| Descricao:                                                                                                                                 |
#| Scritp eh chamado pelo dialplan, quando nao houver sucesso na discagem para o primerio numero do paciente informado no BD                  |
#| do cliente. Assim, no caso de falha chama este escript que ira criar novo canal de dialer porém discando para o segundo                    |
#| numero de telefone fornecido pelo BD do cliente.                                                                                           |
#+--------------------------------------------------------------------------------------------------------------------------------------------+
#| Simulacao:                                                                                                                                 |
#| ./call.sh '${CONTATO_ID}' '${CONTATO_NOME}' '${CONTATO_TEL_1}' '${CONTATO_TEL_2}' '${CONTATO_CONT}' '${DIALSTATUS}'                        |
#+--------------------------------------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                                                   |
#|Data: 09/01/2019                                                                                                                            |
#+--------------------------------------------------------------------------------------------------------------------------------------------+

if [ ${#4} -lt 8 ];then
    exit 0
fi

export PGPASSWORD=sml3uc0

DBUSER='postgres'
DBNAME='ura'
DBTABLE='contato'

CONTATO_ID=$1
CONTATO_NOME=$2
CONTATO_TEL_1=$3
CONTATO_TEL_2=$4
CONTATO_CONT=$5
DIALSTATUS=$6

TEL=$(echo "${CONTATO_TEL_2}" | xargs | sed 's/[^0-9]//g')
ABSOLUTE_FILE_NAME='/opt/leucotron/call/'$(date +"%d%m%Y%H%M%S")_${TEL}'.call'
                                       
echo "Channel: Local/${TEL}@outbound-call/n"                > ${ABSOLUTE_FILE_NAME}
echo "Callerid: <5999> "5999""                             >> ${ABSOLUTE_FILE_NAME}
echo "MaxRetries: 0"                                       >> ${ABSOLUTE_FILE_NAME}
echo "WaitTime: 180"                                       >> ${ABSOLUTE_FILE_NAME}
echo "Context: inbound-call"                               >> ${ABSOLUTE_FILE_NAME}
echo "Extension: ${TEL}"                                   >> ${ABSOLUTE_FILE_NAME}
echo "Priority: 1"                                         >> ${ABSOLUTE_FILE_NAME}
echo "Set: CONTATO_ID=${CONTATO_ID}"                       >> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CONTATO_NOME=${CONTATO_NOME}"                   >> ${ABSOLUTE_FILE_NAME}                                       
echo "Set: CONTATO_TEL_1=${CONTATO_TEL_1}"                 >> ${ABSOLUTE_FILE_NAME}
echo "Set: CONTATO_TEL_2=${CONTATO_TEL_2}"                 >> ${ABSOLUTE_FILE_NAME}                                       
echo "Set: CONTATO_CONT=${CONTATO_CONT}"                   >> ${ABSOLUTE_FILE_NAME}                                        
#                                        echo "Set: DIALSTATUS=ANSWER"                                  >> ${ABSOLUTE_FILE_NAME}
echo "Set: DIALSTATUS=${DIALSTATUS}"                           >> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_CAMPANHA=${AUDIO_CAMPANHA}"               >> ${ABSOLUTE_FILE_NAME}
echo "Archive: yes"                                        >> ${ABSOLUTE_FILE_NAME}
echo "$(date +"%d-%m-%Y_%H:%M:%S") Chamando TEL_2 ${TEL}"  >> /opt/leucotron/log/confirmaConsulta.log
mv ${ABSOLUTE_FILE_NAME} /var/spool/asterisk/outgoing/
