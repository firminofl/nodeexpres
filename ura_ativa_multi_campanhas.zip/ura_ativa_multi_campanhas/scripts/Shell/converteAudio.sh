#!/bin/bash
#|+----------------------------------------------------------------------------------------------------------------------------------------------+
#| Autor: Evaldo de Oliveira                                                                                                                     |
#| Data : 18/01/19                                                                                                                               |
#|-----------------------------------------------------------------------------------------------------------------------------------------------|
#| Script responsável por:                                                                                                                       |
#| - Converter os arquivos de áudios que estão no diretório /opt/leucotron/sounds/ e salvá-los no diretório /var/lib/asterisk/sounds/pt_BR/custom|
#+-----------------------------------------------------------------------------------------------------------------------------------------------+
#| Histórico:                                                                                                                                    |
#| Versão: v1.0                                                                                                                                  |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+
#|SGDB: Postgresql 9.4                                                                                                                           |
#+-----------------------------------------------------------------------------------------------------------------------------------------------+

cd /opt/leucotron/sounds/
#cd /home/filipefirmino/Music/sounds

for input in *;
do
 if [ "${input##*.}" = wav ]
 then
  sox ${input%%.*}.wav -r 8000 -c1 ${input%%.*}.gsm
  rm ${input}
  mv ${input%%.*}.gsm /var/lib/asterisk/sounds/pt_BR/custom
 else
  if [ "${input##*.}" = mp3 ]
  then
   mpg123 -w ${input%%.*}.wav ${input%%.*}.mp3
   sox ${input%%.*}.wav -r 8000 -c1 ${input%%.*}.gsm
   rm ${input%%.*}.wav
   rm ${input}
   mv ${input%%.*}.gsm /var/lib/asterisk/sounds/pt_BR/custom
 else
   if [ "${input##*.}" = gsm ]
   then
    mv ${input%%.*}.gsm /var/lib/asterisk/sounds/pt_BR/custom
 else
    echo -e "\nOs unicos formatos convertidos para .gsm sao, .mp3 e .wav.\n" >> /dev/null
   fi
  fi
 fi
done
