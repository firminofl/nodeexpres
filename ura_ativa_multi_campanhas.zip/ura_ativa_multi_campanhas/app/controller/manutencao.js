const pg = require('../db');
const exec = require('child_process').exec;

module.exports = {
    select: (req, res) => {
        //Buscar todas as informações referente as campanhas, contatos e cdr para exportar
        var queryTudo = 'SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id';

        pg.query(queryTudo, [], (err, ans) => {
            if (err) {
                console.log(err)
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                });
            } else {
                //Montar um objeto JSON para enviar para o front-end
                var object = {
                    data: ans.rows
                }
                res.json(object);
            }
        });
    },

    delete: (req, res) => {
        //Query para deletar os dados da base
        var query =
            'DELETE FROM contato; ' +
            'DELETE FROM cdr; ' +
            'DELETE FROM status; ' +
            'DELETE FROM campanha; ';

        pg.query(query, [], (err, ans) => {
            if (err) {
                console.log("Error: " + err);
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                });
            } else {
                var commandToDelete;
                //Executar o comando de exclusao do audio
                commandToDelete = `sudo rm -rf /var/lib/asterisk/sounds/pt_BR/custom/*`;
                execute(commandToDelete, (error, stdout) => { });

                commandToDelete = `sudo rm -rf /opt/leucotron/sounds/*`;
                execute(commandToDelete, (error, stdout) => { });

                //Retornar sucesso da exclusao no front-end                
                res.status(200).send();
            }
        });
    }
}

function execute(command, callback) {
    exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};
