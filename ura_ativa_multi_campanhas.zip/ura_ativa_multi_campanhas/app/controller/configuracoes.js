const pg = require('../db');
const exec = require('child_process').exec;
var houveAlteracaoEstatico = 0;
// Requiring fs module in which 
// writeFile function is defined. 
const fs = require('fs')

module.exports = {
  select: (req, res) => {
    var query = 'SELECT * FROM configuracao';

    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        //fs.readFile(__dirname + '/alteracaoConfiguracao.txt', (err, data) => {
          res.status(200).send({
            rows: ans.rows[0],
            houveAlteracao: 0
          });
        //});
      }
    });
  },

  update: (req, res) => {
    var tentativasDiscagem = req.body.tentativasDiscagem;
    var intervaloDiscagens = req.body.intervaloDiscagens;
    var chamadaSimultaneas = req.body.chamadaSimultaneas;

    //analyzeReturn(tentativasDiscagem, intervaloDiscagens, chamadaSimultaneas);

    var query = 'UPDATE configuracao SET conf_num_tentativa = ' + tentativasDiscagem + ', conf_intervalo_discagem = ' + intervaloDiscagens +
      ', conf_chamadas_simultaneas = ' + chamadaSimultaneas + ' WHERE conf_id = 1';

    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.status(200).send({
          message: 'Configurações atualizadas!',
          houveAlteracao: houveAlteracaoEstatico
        });
      }
    });
  },

  restart: (req, res) => {
    try {
      //execute('sudo dialer.sh start', (error, stdout) => { });

      setTimeout(() => {
        houveAlteracaoEstatico = 0;
        arquivoTxt(houveAlteracaoEstatico);
        res.status(200).send()
      }, 2500);
    } catch (error) {
      console.log(error);
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno ao reiniciar o servidor.'
      });
    }
  }
}

function execute(command, callback) {
  exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};

/*
function analyzeReturn(tentativasDiscagem, intervaloDiscagens, chamadaSimultaneas, antecedenciaFeriado, amd) {
  //buscar dados no banco de dados para analisar a mudança
  var query = 'SELECT * FROM configuracao WHERE conf_id = 1;';

  pg.query(query, [], (err, ans) => {
    if (err) {
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro ao selecionar dados no servidor'
      });
    } else {

      if (ans.rows[0].conf_num_tentativa != parseInt(tentativasDiscagem)) {
        houveAlteracaoEstatico = 1;
      }

      if (ans.rows[0].conf_intervalo_discagem != parseInt(intervaloDiscagens)) {
        houveAlteracaoEstatico = 1;
      }

      if (ans.rows[0].conf_chamadas_simultaneas != parseInt(chamadaSimultaneas)) {
        houveAlteracaoEstatico = 1;
      }

      if (ans.rows[0].conf_dias_antes != parseInt(antecedenciaFeriado)) {
        houveAlteracaoEstatico = 1;
      }

      if (String(ans.rows[0].conf_amd) != String(amd)) {
        houveAlteracaoEstatico = 1;
      }
      arquivoTxt(houveAlteracaoEstatico)
    }
  });
}

function arquivoTxt(houveAlteracao) {
  fs.open(__dirname + '/alteracaoConfiguracao.txt', 'wx', (err, fd) => {
    if (err) {
      if (err.code === 'EEXIST') {
        fs.unlink(__dirname + '/alteracaoConfiguracao.txt', function (err) {
          if (err) throw err;
          console.log('File deleted!');
          return;
        });
        fs.appendFile(__dirname + '/alteracaoConfiguracao.txt', houveAlteracao, (err) => {
          if (err) throw err;
          console.log('File created!');
        });
      } else if (err.code === 'ENOENT') {
        fs.appendFile(__dirname + '/alteracaoConfiguracao.txt', houveAlteracao, (err) => {
          if (err) throw err;
          console.log('File created!');
          return;
        });
      }
    }
  });
}
*/