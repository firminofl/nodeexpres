const pg = require('../db')

module.exports = {
  insert: (req, res) => {
    var nomeFeriado = req.body.nomeFeriado;
    var dataFeriado = req.body.dataFeriado;

    if (!nomeFeriado && !dataFeriado)
      return res.status(400).send();

    //Convertendo para o padrão yyyy-mm-dd
    var date = new Date(dataFeriado);//Convertendo data para o padrão yyyy-mm-dd
    dataFeriado = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate());

    var query = 'INSERT INTO feriado(feriado_data,feriado_nome)' +
      'VALUES(' + "'" + dataFeriado + "'" + "," + "'" + nomeFeriado + "'" + ")"
      pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'A data deve ser única no sistema!'
        });
      } else {
        res.status(200).send({
          message: 'Feriado cadastrado com sucesso.'
        });
      }
    });
  },

  select: (req, res) => {
    var query = 'SELECT feriado_id,feriado_nome,feriado_data FROM feriado ORDER BY feriado_data ASC';

    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows);
      }
    });
  },

  update: (req, res) => {
    var idFeriado = req.body.idFeriado;
    var nomeFeriado = req.body.nomeFeriado;
    var dataFeriado = req.body.dataFeriado;

    if (!idFeriado && !nomeFeriado && !dataFeriado)
      return res.status(400).send();

    //Convertendo para o padrão yyyy-mm-dd
    var date = new Date(dataFeriado);//Convertendo data para o padrão yyyy-mm-dd
    dataFeriado = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate());

    var query = 'UPDATE feriado SET feriado_data = ' + "'" + dataFeriado + "'" + ' , feriado_nome = ' + "'" + nomeFeriado + "'" +
      ' WHERE feriado_id = ' + idFeriado;

    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json({
          message: 'Feriado atualizado!'
        });
      }
    });
  },

  delete: (req, res) => {
    var idFeriado = req.body.idFeriado;

    var query = 'DELETE FROM feriado WHERE feriado_id = ' + idFeriado;

    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        res.json({
          message: 'Feriado excluído!'
        });
      }
    });
  }
}
