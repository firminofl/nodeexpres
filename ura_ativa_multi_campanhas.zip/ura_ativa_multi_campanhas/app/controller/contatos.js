const pg = require('../db');

module.exports = {
  select: (req, res) => {
    var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id';
    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        var count = ans.rows[0].resultado;

        //Verificar se existe contatos cadastrados
        if (count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhum contato registrado até o momento!'
          });
        } else {
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }

          var query =
            'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, cdr_tel_discado, cdr_status_chamada ' +
            'FROM cdr, contato, status, campanha ' +
            'WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id ' +
            'ORDER BY contato_id, cdr_data_hora_chamada DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Erro ao selecionar dados no servidor'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      dataInicioChamadaContato: req.body.dataInicioChamadaContatos,
      dataFimChamadaContato: req.body.dataFimChamadaContatos,

      horaInicioChamadaContato: req.body.horaInicioChamadaContatos,
      horaFimChamadaContato: req.body.horaFimChamadaContatos,

      nomeContato: req.body.nomeContatos,
      nomeCampanhaContato: req.body.nomeCampanhaContatos,
      telDiscado: req.body.telDiscado,
      statusChamada: req.body.statusChamada,

      exportarCSVTF: req.body.exportarCSVTrueFalse
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;

    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null) {
      if (queryPesquisa == 'Data de início é maior que a atual.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      } else if (queryPesquisa == 'Data de início está vazia.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      } else if (queryPesquisa == 'Insira um período de data para busca.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      } else if (queryPesquisa == 'Hora de início de consulta é maior que a de fim.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de consulta é maior que a de fim.'
        });
      } else if (queryPesquisa == 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.') {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'
        });
      } else {
        var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha ' + queryPesquisa + ' AND contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id';
        pg.query(query, [], (err, ans) => {
          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro ao selecionar dados no servidor'
            });
          } else {
            var count = ans.rows[0].resultado;

            if (count == 0) {
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Nenhum dado encontrado!'
              });
            } else {

              var pagination = req.body.pagination;

              if (pagination == null || pagination == 1) {
                pagination = 0;
              } else if (pagination > 1) {
                pagination = pagination * 10 - 10;
              }

              if (object.exportarCSVTF) {
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, cdr_tel_discado, cdr_status_chamada ' +
                  'FROM cdr, contato, status, campanha ' + queryPesquisa + ' AND contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id ' +
                  'ORDER BY contato_id, cdr_data_hora_chamada ';
                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    res.json(ans.rows);
                  }
                });
              } else {
                //query de busca no postgres, montada previamente para reduzir seu tamanho
                var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, cdr_tel_discado, cdr_status_chamada ' +
                  'FROM cdr, contato, status, campanha ' + queryPesquisa + ' AND contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id ' +
                  'ORDER BY contato_id, cdr_data_hora_chamada ' +
                  'DESC LIMIT 10 OFFSET ' + pagination;

                pg.query(queryConsulta, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro ao selecionar dados no servidor'
                    });
                  } else {
                    var data = new Object();
                    data.contador = count;
                    data.result = ans.rows;
                    res.json(data);
                  }
                });
              }
            }
          }
        });
      }
    } else {
      var query = 'SELECT COUNT(DISTINCT contato_id) as resultado FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id';
      pg.query(query, [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao selecionar dados no servidor'
          });
        } else {
          var count = ans.rows[0].resultado;

          if (count == 0) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Nenhum dado encontrado!'
            });
          } else {

            var pagination = req.body.pagination;

            if (pagination == null || pagination == 1) {
              pagination = 0;
            } else if (pagination > 1) {
              pagination = pagination * 10 - 10;
            }

            if (object.exportarCSVTF) {
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, cdr_tel_discado, cdr_status_chamada ' +
                'FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id ' +
                'ORDER BY contato_id, cdr_data_hora_chamada ';
              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  res.json(ans.rows);
                }
              });
            } else {
              //query de busca no postgres, montada previamente para reduzir seu tamanho
              var queryConsulta = 'SELECT DISTINCT ON (contato_id) contato_id, cdr_data_hora_chamada, campanha_nome, contato_nome, cdr_tel_discado, cdr_status_chamada ' +
                'FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id AND contato.campanha_fk = campanha.campanha_id ' +
                'ORDER BY contato_id, cdr_data_hora_chamada ' +
                'DESC LIMIT 10 OFFSET ' + pagination;
              pg.query(queryConsulta, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                  });
                } else {
                  var data = new Object();
                  data.contador = count;
                  data.result = ans.rows;
                  res.json(data);
                }
              });
            }
          }
        }
      });
    }
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item) {
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //**********************************consulta**********************************
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimChamadaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioChamadaContato;
      var date = new Date();
      var horaFim = ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ":" + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data fim
      var dataFimChamadaContato = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (preenchido no inicio da hora e data)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimChamadaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioDiscagemBilhete;
      var horaFim = item.horaFimChamadaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimChamadaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimChamadaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataHoraFim + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (tudo preenchido - data e hora)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimChamadaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato != '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioDiscagemBilhete;
      var horaFim = item.horaFimChamadaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimChamadaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimChamadaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (PPPV)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimChamadaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato != '') {
      //Hora de inicio e fim
      var horaInicio = item.horaInicioDiscagemBilhete;

      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " " + horaInicio;

      //Data Fim
      var dateFim = new Date(item.dataFimChamadaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimChamadaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (PPVP)
  if (item.horaInicioDiscagemBilhete == '' && item.horaFimChamadaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato != '') {
      //Hora de fim
      var horaFim = item.horaFimChamadaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data Fim
      var dateFim = new Date(item.dataFimChamadaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimChamadaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (PVVP)
  if (item.horaInicioDiscagemBilhete == '' && item.horaFimChamadaContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {
      //Hora de fim
      var horaFim = item.horaFimChamadaContato

      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data Fim
      var dateFim = new Date();//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimChamadaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " " + horaFim;

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (PVVV)
  if (item.horaInicioDiscagemBilhete == '' && item.horaFimChamadaContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato == '') {
      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data fim
      var date = new Date();
      var dataFimChamadaContato = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + ((date.getDate() < 10 ? '0' : '') + date.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas. (PPVV)
    } else if (item.dataInicioChamadaContato != '' && item.dataFimChamadaContato != '') {
      //Data Inicio
      var dateInicio = new Date(item.dataInicioChamadaContato);//Convertendo data de inicio para o padrão yyyy-mm-dd
      var dataInicioChamadaContato = dateInicio.getFullYear() + "-" + (dateInicio.getMonth() + 1) + "-" + ((dateInicio.getDate() < 10 ? '0' : '') + dateInicio.getDate()) + " 00:00";

      //Data Inicio
      var dateFim = new Date(item.dataFimChamadaContato);//Convertendo data de fim para o padrão yyyy-mm-dd
      var dataFimChamadaContato = dateFim.getFullYear() + "-" + (dateFim.getMonth() + 1) + "-" + ((dateFim.getDate() < 10 ? '0' : '') + dateFim.getDate()) + " 23:59";

      //Convertendo em milissegundos
      var inicio = new Date(dataInicioChamadaContato).valueOf();
      var fim = new Date(dataFimChamadaContato).valueOf();

      if (inicio < fim) {
        dataHoraInicio
        if (count > 0) {
          query += ' AND cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        } else {
          query += 'cdr_data_hora_chamada BETWEEN ' + "'" + dataInicioChamadaContato + "'" + ' AND ' + "'" + dataFimChamadaContato + "'";
        }
        count++;
      } else {
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    } else if (item.dataInicioChamadaContato == '' && item.dataFimChamadaContato != '') {
      return 'Data de início está vazia.';
    }
  }
  //****************************Fim data e hora de consulta***********************

  //Validação campanha
  if (item.nomeCampanhaContato != '') {
    if (count > 0) {
      query += ' AND campanha_nome ILIKE ' + "'%" + item.nomeCampanhaContato + "%'";
    } else {
      query += 'campanha_nome ILIKE ' + "'%" + item.nomeCampanhaContato + "%'";
    }
    count++;
  }

  //Validação telfone 1
  if (item.telDiscado != '') {
    if (count > 0) {
      query += ' AND cdr_tel_discado ILIKE ' + "'%" + item.telDiscado + "%'";
    } else {
      query += 'cdr_tel_discado ILIKE ' + "'%" + item.telDiscado + "%'";
    }
    count++;
  }

  //Validação telfone 2
  if (item.statusChamada != '') {
    if (count > 0) {
      query += ' AND cdr_status_chamada ILIKE ' + "'%" + item.statusChamada + "%'";
    } else {
      query += 'cdr_status_chamada ILIKE ' + "'%" + item.statusChamada + "%'";
    }
    count++;
  }

  //Validação Contato
  if (item.nomeContato != '' || item.nomeContato === undefined) {
    if (count > 0) {
      query += ' AND contato_nome ILIKE ' + "'%" + item.nomeContato + "%'";
    } else {
      query += 'contato_nome ILIKE ' + "'%" + item.nomeContato + "%'";
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}
