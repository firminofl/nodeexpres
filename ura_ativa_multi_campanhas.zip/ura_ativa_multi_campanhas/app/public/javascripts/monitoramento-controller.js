function monitorarDiscagens() {
    $.ajax({
        success: function (data) {
            //console.log(data)
            //console.log("Sucesso na busca");
            mostrarDadosDiscagem(data);
        },
        error: function () {
            console.log("Falha na busca");
            monitorarDiscagens();
        },
        processData: false,
        type: 'GET',
        url: '/monitoramento/selectAsterisk'
    });
}

function getDataAjax() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/monitoramento/selectAsterisk')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    mostrarDadosDiscagem(JSON.parse(this.response));
                    break;
                case 304:
                    mostrarDadosDiscagem(JSON.parse(this.response));
                    break;
                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;
                default:
                    alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }

    xhttp.send();
}

function mostrarDadosDiscagem(data) {
    $('#canaisAtivos').val(" Canais ativo(s): " + data.numberOfChannels);
    //Campos que estão sendo discados
    $('#numeroUm').val(data.numbers[0]);
    $('#numeroDois').val(data.numbers[1]);
    $('#numeroTres').val(data.numbers[2]);
    $('#numeroQuatro').val(data.numbers[3]);
    $('#numeroCinco').val(data.numbers[4]);
    $('#numeroSeis').val(data.numbers[5]);
    $('#numeroSete').val(data.numbers[6]);
    $('#numeroOito').val(data.numbers[7]);
}

function monitorarDevice() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/monitoramento/select')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    mostrarDadosMonitoramento(JSON.parse(this.response));
                    break;
                case 304:
                    mostrarDadosMonitoramento(JSON.parse(this.response));
                    break;
                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;
                default:
                    alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }

    xhttp.send();
}

function mostrarDadosMonitoramento(data) {
    var doughnutData = {
        labels: ["Livre (GB)", "Usado (GB)"],
        datasets: [{
            data: [data.free, data.used],
            backgroundColor: ["#a3e1d4", "#dedede"]
        }]
    };

    var doughnutOptions = {
        responsive: true
    };

    var ctx4 = document.getElementById("doughnutChart").getContext("2d");
    new Chart(ctx4, { type: 'doughnut', data: doughnutData, options: doughnutOptions });

    $('#espacoTotal').val(data.size + " GB");
    $('#espacoLivre').val(data.free + " GB");
    $('#espacoUsado').val(data.used + " GB");
    $('#arquivoSistema').val(data.fs);
    $('#pontoMontagem').val(data.mount);
    $('#tipoSistema').val(data.type);
    $('#porcentagemUsado').val(data.use);


}

function alertSwal(message) {
    swal({
        title: "Ops :-(",
        text: message,
        type: "error",
        showConfirmButton: true
    });
}