function atualizaContatos() {
  var xhttp = new XMLHttpRequest();

  var paginationAtual = $('#atualContatos').val();

  var object = {
    pagination: paginationAtual
  }

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          valorMaximoPag(JSON.parse(this.response).contador);
          addContatosNaTabela(JSON.parse(this.response).result);
          break;
        case 304:
          valorMaximoPag(JSON.parse(this.response).contador);
          addContatosNaTabela(JSON.parse(this.response).result);
          break;
        case 500:
          setTimeout(() => {
            $("#totalRegistros").val('0 registros.')
          }, 1200);
          break;
        default:
          setTimeout(() => {
            $("#totalRegistros").val('0 registros.')
          }, 1200);
          break;
      }
    }
  }

  xhttp.open('POST', '/contato/select')
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addContatosNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaContatos tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //Data/Hora chamada
    var chamadaCell = newRow.insertCell(count);
    var date = new Date(rows[i].cdr_data_hora_chamada)
    var chamadaValue = document.createTextNode(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '')}/${date.getFullYear()}` + ` ${(date.getHours() < 10 ? '0' : '') + date.getHours()}:${(date.getMinutes() < 10 ? '0' : '') + date.getMinutes()}`);
    chamadaCell.appendChild(chamadaValue);
    count++;

    //Nome campanha
    var nomeCampanhaCell = newRow.insertCell(count);
    var nomeCampanhaValue = document.createTextNode(rows[i].campanha_nome);
    nomeCampanhaCell.appendChild(nomeCampanhaValue);
    count++;

    //Nome contato
    var nomeContatoCell = newRow.insertCell(count);
    var nomeContatoValue = document.createTextNode(rows[i].contato_nome);
    nomeContatoCell.appendChild(nomeContatoValue);
    count++;

    //Telefone discado
    var telDiscadoCell = newRow.insertCell(count);
    var telDiscadoValue = document.createTextNode(rows[i].cdr_tel_discado);
    telDiscadoCell.appendChild(telDiscadoValue);
    count++;

    //Status Chamada
    var statusClienteCell = newRow.insertCell(count);
    var statusClienteValue = document.createTextNode(rows[i].cdr_status_chamada);
    statusClienteCell.appendChild(statusClienteValue);
    count++;

    //Ordenar a tabela e mostra-las stripada
    $("#cabecalhoDataContatos").click();
  }
}

function buscarContatos() {
  $('#selectORsearch').val('2');
  //Datas e horas referentes ao filtro
  var inputDataInicioChamadaContatos = $('#dataInicioChamadaContatos').val();
  var inputDataFimDiscChamadaContatos = $('#dataFimChamadaContatos').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioChamadaContatoss = null;
  if (!inputDataInicioChamadaContatos.length == 0) {
    inputDataInicioChamadaContatoss =
      inputDataInicioChamadaContatos[3] + inputDataInicioChamadaContatos[4] + //mes
      "/" + inputDataInicioChamadaContatos[0] + inputDataInicioChamadaContatos[1] + // dia
      "/" + inputDataInicioChamadaContatos[6] + inputDataInicioChamadaContatos[7] + inputDataInicioChamadaContatos[8] + inputDataInicioChamadaContatos[9]; //ano
  } else {
    inputDataInicioChamadaContatoss = '';
  }

  var inputDataFimDiscChamadaContatoss = null;
  if (!inputDataFimDiscChamadaContatos.length == 0) {
    inputDataFimDiscChamadaContatoss =
      inputDataFimDiscChamadaContatos[3] + inputDataFimDiscChamadaContatos[4] + //mes
      "/" + inputDataFimDiscChamadaContatos[0] + inputDataFimDiscChamadaContatos[1] + // dia
      "/" + inputDataFimDiscChamadaContatos[6] + inputDataFimDiscChamadaContatos[7] + inputDataFimDiscChamadaContatos[8] + inputDataFimDiscChamadaContatos[9]; //ano
  } else {
    inputDataFimDiscChamadaContatoss = '';
  }

  var inputHoraInicioChamadaContatos = $('#horaInicioChamadaContatos').val();
  var inputHoraFimChamadaContatos = $('#horaFimChamadaContatos').val();

  //contato, campanha, tel1 e tel2, telefone discado
  var inputNomeContatos = $('#nomeContato').val();
  var inputNomeCampanhaContatos = $('#nomeCampanhaContatos').val();
  var inputTelDiscado = $('#telDiscadoContatos').val();
  var inputStatusChamada = $('#statusChamadaContatos').val();

  var paginationAtual = $('#atualContatos').val();

  if (inputDataInicioChamadaContatos.length == 0 &&
    inputDataFimDiscChamadaContatos.length == 0 &&
    inputHoraInicioChamadaContatos.length == 0 &&
    inputHoraFimChamadaContatos.length == 0 &&
    inputNomeContatos.length == 0 &&
    inputNomeCampanhaContatos.length == 0 &&
    inputTelDiscado.length == 0 &&
    inputStatusChamada.length == 0) {
    return alertSwal('Nenhum filtro aplicado. Será mantido o estado atual.')

  } else {
    //Validar datas para não sobrecarregar o servidor
    validarDatas();

    //criando um objeto para passar como referencia na rota
    var object = {
      //Datas e horas referentes ao filtro
      dataInicioChamadaContatos: inputDataInicioChamadaContatoss,
      dataFimChamadaContatos: inputDataFimDiscChamadaContatoss,

      horaInicioChamadaContatos: inputHoraInicioChamadaContatos,
      horaFimChamadaContatos: inputHoraFimChamadaContatos,

      //contato, campanha, tel1 e tel2, telefone discado
      nomeContatos: inputNomeContatos,
      nomeCampanhaContatos: inputNomeCampanhaContatos,
      telDiscado: inputTelDiscado,
      statusChamada: inputStatusChamada,

      exportarCSVTrueFalse: false,

      //paginação atual para o filtro
      pagination: paginationAtual
    }

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            valorMaximoPag(JSON.parse(this.response).contador);
            addContatosNaTabela(JSON.parse(this.response).result);
            break;

          case 304:
            valorMaximoPag(JSON.parse(this.response).contador);
            addContatosNaTabela(JSON.parse(this.response).result);
            break;

          case 500:
            alertSwal(JSON.parse(this.response).message);
            break;

          default:
            alertSwal('Erro inesperado, contate o administrador.');
            break;
        }
      }
    }
    xhttp.open('POST', '/contato/search', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
  }
}

function exportarCSV() {
  //Validar datas para não sobrecarregar o servidor
  validarDatas();

  //Datas e horas referentes ao filtro
  var inputDataInicioChamadaContatos = $('#dataInicioChamadaContatos').val();
  var inputDataFimDiscChamadaContatos = $('#dataFimChamadaContatos').val();

  //Converter de pt-br para en o formato da data para consulta no banco
  var inputDataInicioChamadaContatoss = null;
  if (!inputDataInicioChamadaContatos.length == 0) {
    inputDataInicioChamadaContatoss =
      inputDataInicioChamadaContatos[3] + inputDataInicioChamadaContatos[4] + //mes
      "/" + inputDataInicioChamadaContatos[0] + inputDataInicioChamadaContatos[1] + // dia
      "/" + inputDataInicioChamadaContatos[6] + inputDataInicioChamadaContatos[7] + inputDataInicioChamadaContatos[8] + inputDataInicioChamadaContatos[9]; //ano
  } else {
    inputDataInicioChamadaContatoss = '';
  }

  var inputDataFimDiscChamadaContatoss = null;
  if (!inputDataFimDiscChamadaContatos.length == 0) {
    inputDataFimDiscChamadaContatoss =
      inputDataFimDiscChamadaContatos[3] + inputDataFimDiscChamadaContatos[4] + //mes
      "/" + inputDataFimDiscChamadaContatos[0] + inputDataFimDiscChamadaContatos[1] + // dia
      "/" + inputDataFimDiscChamadaContatos[6] + inputDataFimDiscChamadaContatos[7] + inputDataFimDiscChamadaContatos[8] + inputDataFimDiscChamadaContatos[9]; //ano
  } else {
    inputDataFimDiscChamadaContatoss = '';
  }

  var inputHoraInicioChamadaContatos = $('#horaInicioChamadaContatos').val();
  var inputHoraFimChamadaContatos = $('#horaFimChamadaContatos').val();

  //contato, campanha, tel1 e tel2, telefone discado
  var inputNomeContatos = $('#nomeContato').val();
  var inputNomeCampanhaContatos = $('#nomeCampanhaContatos').val();
  var inputTelDiscado = $('#telDiscadoContatos').val();
  var inputStatusChamada = $('#statusChamadaContatos').val();

  //criando um objeto para passar como referencia na rota
  var object = {
    //Datas e horas referentes ao filtro
    dataInicioChamadaContatos: inputDataInicioChamadaContatoss,
    dataFimChamadaContatos: inputDataFimDiscChamadaContatoss,

    horaInicioChamadaContatos: inputHoraInicioChamadaContatos,
    horaFimChamadaContatos: inputHoraFimChamadaContatos,

    //contato, campanha, tel1 e tel2, telefone discado
    nomeContatos: inputNomeContatos,
    nomeCampanhaContatos: inputNomeCampanhaContatos,
    telDiscado: inputTelDiscado,
    statusChamada: inputStatusChamada,

    exportarCSVTrueFalse: true
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 304:
          montarExportarTabelaCSV(JSON.parse(this.response));
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        default:
          alertSwal('Erro inesperado, contate o administrador.');
          break;
      }
    }
  }
  xhttp.open('POST', '/contato/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function montarExportarTabelaCSV(rows) {
  //Mostrar que o processo pode demorar
  swal({
    title: "Exportar CSV",
    text: "Este processo pode demorar um tempo!"
  });

  var csv = 'Data/Hora Chamada,Campanha,Contato,Telefone Discado, Status Chamada,\n';

  for (var i = 0; i < rows.length; i++) {
    var date = new Date(rows[i].cdr_data_hora_chamada)

    csv += (date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear() + " " + (date.getHours() < 10 ? '0' : '') + date.getHours() + ":" + (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
    csv += ',' + rows[i].campanha_nome;
    csv += ',' + rows[i].contato_nome;
    csv += ',' + rows[i].cdr_tel_discado;
    csv += ',' + rows[i].cdr_status_chamada;
    csv += '\n';
  }

  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'contatos.csv';
  document.body.appendChild(hiddenElement);
  hiddenElement.click();
  document.body.removeChild(hiddenElement);
}

function limparCampos() {
  //Datas e horas referentes ao filtro
  $('#dataInicioChamadaContatos').val('');
  $('#dataFimChamadaContatos').val('');

  $('#horaInicioChamadaContatos').val('');
  $('#horaFimChamadaContatos').val('');

  //contato, campanha, tel1 e tel2, telefone discado
  $('#nomeContato').val('');
  $('#nomeCampanhaContatos').val('');
  $('#telDiscadoContatos').val('');
  $('#statusChamadaContatos').val('');

  //Valor de paginacao
  $('#valorMaximo').val(1);

  //Atualiza tabela
  atualizaContatos();
}

function alertSwal(message) {
  swal({
    title: "Ops :-(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximoContatos');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atualContatos').val() > page) {
    $('#atualContatos').val(1);
    $('#contMenosContatos').click();
  }
}

function gatilhoContMenos() {
  $('#contMaisContatos').attr('disabled', false);
  var valorMaximo = $('#valorMaximoContatos').val();

  var paginationAtual = parseInt($('#atualContatos').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atualContatos').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atualContatos').val(1);
    $('#contMenosContatos').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaContatos();
  } else if (selectORsearch == 2) {
    buscarContatos();
  }
}

function gatilhoContMais() {
  $('#contMenosContatos').attr('disabled', false);
  var valorMaximo = $('#valorMaximoContatos').val();
  var paginationAtual = parseInt($('#atualContatos').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atualContatos').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMaisContatos').attr('disabled', true);
    $('#atualContatos').val(valorMaximo);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaContatos();
  } else if (selectORsearch == 2) {
    buscarContatos();
  }
}

function gatilhoPaginacaoProximo() {
  $('#contMenosContatos').attr('disabled', false);
  var valorMaximo = $('#valorMaximoContatos').val();
  var paginationAtual = parseInt($('#atualContatos').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atualContatos').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atualContatos').val(valorMaximo);
    $('#contMaisContatos').attr('disabled', true);
  }

  var selectORsearch = parseInt($('#selectORsearch').val());
  if (selectORsearch == 1) {
    atualizaContatos();
  } else if (selectORsearch == 2) {
    buscarContatos();
  }
}

function validarDatas() {
  //Datas e horas referentes ao filtro
  var dataInicioDiscagemContato = $('#dataInicioDiscagemContatos').val();
  var dataFimDiscagemContato = $('#dataFimDiscagemContatos').val();

  var horaInicioDiscagemContato = $('#horaInicioDiscagemContatos').val();
  var horaFimDiscagemContato = $('#horaFimDiscagemContatos').val();

  //VVVP
  if (horaInicioDiscagemContato == '' && horaFimDiscagemContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemContato == '' && dataFimDiscagemContato == '') {
      alertSwal('É necessário informar ao menos a data de início e hora início!');
      return;
    }
  }

  //VVPV
  if (horaInicioDiscagemContato == '' && horaFimDiscagemContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemContato != '' && dataFimDiscagemContato == '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VVPP
  if (horaInicioDiscagemContato == '' && horaFimDiscagemContato == '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemContato != '' && dataFimDiscagemContato != '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVV
  if (horaInicioDiscagemContato == '' && horaFimDiscagemContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemContato == '' && dataFimDiscagemContato == '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPPV
  if (horaInicioDiscagemContato == '' && horaFimDiscagemContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemContato != '' && dataFimDiscagemContato == '') {
      alertSwal('É necessário informar ao menos a data de início!');
      return;
    }
  }

  //VPVP
  if (horaInicioDiscagemContato == '' && horaFimDiscagemContato != '') {
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (dataInicioDiscagemContato != '' && dataFimDiscagemContato == '') {
      alertSwal('É necessário informar ao menos a data de início e hora!');
      return;
    }
  }
}
