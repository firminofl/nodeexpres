var json = null;

function atualizaHistoricoCampanhas() {
  var paginationAtual = $('#atual').val();

  var object = {
    pagination: paginationAtual
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          if (JSON.parse(this.response).totalCampanhas == 0) {
            $("#totalRegistros").val('0 registros.');
          } else {
            valorMaximoPag(JSON.parse(this.response).totalCampanhas);
            json = JSON.parse(this.response);
            addCampanhaNaTabela(json);
          }
          break;

        case 304:
          if (JSON.parse(this.response).totalCampanhas == 0) {
            $("#totalRegistros").val('0 registros.');
          } else {
            valorMaximoPag(JSON.parse(this.response).totalCampanhas);
            json = JSON.parse(this.response);
            addCampanhaNaTabela(json);
          }
          break;

        case 400:
          dangerSwal(JSON.parse(this.response).message);
          break;

        case 500:
          dangerSwal(JSON.parse(this.response).message);
          break;

        case 404:
          dangerSwal('Não foi possível alcançar o servidor');
          break;

        default:
          dangerSwal('Erro inesperado, contate o administrador');
          break;
      }
    }
  }
  xhttp.open('POST', '/campanha/selectSomenteCampanhasParadas', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function addCampanhaNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaCampanhasParadas tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.nomeCampanha.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    //Campanha
    var campanhaCell = newRow.insertCell(count);
    var campanhaValue = document.createTextNode(rows.nomeCampanha[i]);
    campanhaCell.appendChild(campanhaValue);
    count++;

    //Contatos importados
    var qtdImportadoCell = newRow.insertCell(count);
    var qtdImportadoValue = document.createTextNode(rows.totalContatos[i]);
    qtdImportadoCell.appendChild(qtdImportadoValue);
    count++;

    //Discagens realizadas
    var discRealizadasCell = newRow.insertCell(count);
    var discRealizadasValue = document.createTextNode(rows.totalDiscagens[i]);
    discRealizadasCell.appendChild(discRealizadasValue);
    count++;

    //Discagens realizadas
    var atendidasCell = newRow.insertCell(count);
    var atendidasValue = document.createTextNode(rows.totalAtendidas[i]);
    atendidasCell.appendChild(atendidasValue);
    count++;

    //Discagens não realizadas
    var naoAtendidasCell = newRow.insertCell(count);
    var naoAtendidasValue = document.createTextNode(rows.totalNaoAtendidas[i]);
    naoAtendidasCell.appendChild(naoAtendidasValue);
    count++;

    //Grafico
    var statusCell = newRow.insertCell(count);
    //Botão do grafico
    var icone = document.createElement('span');
    icone.setAttribute('class', 'btn btn-outline btn-success fa fa-bar-chart-o');
    icone.setAttribute('id', rows.nomeCampanha[i]);
    icone.setAttribute('data-toggle', "modal");
    icone.setAttribute('data-target', "#modalGraficoOpcoes");
    icone.setAttribute('title', "Gráfico das opções de 1 a 9");
    icone.onclick = graficoCampanha(
      rows.opcao1[i], rows.opcao2[i], rows.opcao3[i],
      rows.opcao4[i], rows.opcao5[i], rows.opcao6[i],
      rows.opcao7[i], rows.opcao8[i], rows.opcao9[i],
      rows.nomeCampanha[i]);
    statusCell.appendChild(icone);
    count++;
  }
}


function exportarCSV() {
  //Mostrar que o processo pode demorar
  swal({
    title: "Exportar CSV",
    text: "Este processo pode demorar um tempo!",
    timer: 4000,
    showConfirmButton: true
  });

  //Titulo para nortear os campos do backup
  var csv = 'Status, Campanha, Data, Contatos importados, Discagens realizadas, Chamadas atendidas, Chamadas não atendidas, Opção 1, Opção 2, Opção 3, Opção 4, Opção 5, Opção 6, Opção 7, Opção 8, Opção 9, \n';
  var date = new Date();
  var dataGrafico = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear();

  for (var i = 0; i < json.nomeCampanha.length; i++) {
    csv += 'Parado';
    csv += ',' + json.nomeCampanha[i];
    csv += ',' + dataGrafico;
    csv += ',' + json.totalContatos[i];
    csv += ',' + json.totalDiscagens[i];
    csv += ',' + json.totalAtendidas[i];
    csv += ',' + json.totalNaoAtendidas[i];
    csv += ',' + json.opcao1[i];
    csv += ',' + json.opcao2[i];
    csv += ',' + json.opcao3[i];
    csv += ',' + json.opcao4[i];
    csv += ',' + json.opcao5[i];
    csv += ',' + json.opcao6[i];
    csv += ',' + json.opcao7[i];
    csv += ',' + json.opcao8[i];
    csv += ',' + json.opcao9[i];
    csv += '\n';
  }

  try {
    var date = new Date();
    var dataExport = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "_" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "_" + date.getFullYear() + "_" + ((date.getHours() < 10 ? '0' : '') + date.getHours()) + ((date.getMinutes() < 10 ? '0' : '') + date.getMinutes());

    //Montar parametros para download do arquivo CSV
    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'historico_campanha_' + dataExport + '.csv';
    document.body.appendChild(hiddenElement);
    hiddenElement.click();
    document.body.removeChild(hiddenElement);

  } catch (error) {
    //Mostrar o erro ao usuário
    console.log("Error: " + error);
    alertSwal('Erro inesperado, contate o administrador');
  }
}

function graficoCampanha(opcao1, opcao2, opcao3, opcao4, opcao5, opcao6, opcao7, opcao8, opcao9, nomeCampanha) {
  return function () {
    $('#modalGraficoOpcoes').on('shown.bs.modal', function () {
      var barData = {
        labels: ["Opção 1", "Opção 2", "Opção 3", "Opção 4", "Opção 5", "Opção 6", "Opção 7", "Opção 8", "Opção 9"],
        datasets: [
          {
            label: "Total",
            backgroundColor: 'rgba(26,179,148,0.5)',
            borderColor: "rgba(26,179,148,0.7)",
            pointBackgroundColor: "rgba(26,179,148,1)",
            pointBorderColor: "#fff",
            data: [opcao1, opcao2, opcao3, opcao4, opcao5, opcao6, opcao7, opcao8, opcao9]
          }
        ]
      };

      var barOptions = {
        responsive: true
      };

      var ctx1 = document.getElementById("myChart").getContext("2d");
      new Chart(ctx1, { type: 'bar', data: barData, options: barOptions });

      $("#modalTitle").text("Campanha: " + nomeCampanha);

      var date = new Date();
      var dataGrafico = ((date.getDate() < 10 ? '0' : '') + date.getDate()) + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear();
      $("#dataGrafico").val("Hoje: " + dataGrafico);
    });
  }
}

function valorMaximoPag(page) {
  var totalRegistros = $('#totalRegistros');
  totalRegistros.val(page + " registros.");

  page /= 10;
  if (page % 1 == 0) {
    page = page;
  } else {
    page = Math.ceil(page);
  }

  var valorMaximo = $('#valorMaximo');

  if (page == 0) {
    valorMaximo.val(1);
  } else {
    valorMaximo.val(page);
  }

  if ($('#atual').val() > page) {
    $('#atual').val(1);
    $('#contMenos').click();
  }
}

function gatilhoContMenos() {
  $('#contMais').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();

  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual > 0) {
    var atual = paginationAtual - 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == 1) {
    $('#atual').val(1);
    $('#contMenos').attr('disabled', true);
  }

  atualizaHistoricoCampanhas();
}

function gatilhoContMais() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#contMais').attr('disabled', true);
    $('#atual').val(valorMaximo);
  }

  atualizaHistoricoCampanhas();
}

function gatilhoPaginacaoProximo() {
  $('#contMenos').attr('disabled', false);
  var valorMaximo = $('#valorMaximo').val();
  var paginationAtual = parseInt($('#atual').val());

  if (paginationAtual < valorMaximo) {
    var atual = paginationAtual + 1;
    $('#atual').val(atual);
  }

  if (paginationAtual == valorMaximo) {
    $('#atual').val(valorMaximo);
    $('#contMais').attr('disabled', true);
  }

  atualizaHistoricoCampanhas();
}

function dangerSwal(message) {
  swal({
    title: "Ops :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}