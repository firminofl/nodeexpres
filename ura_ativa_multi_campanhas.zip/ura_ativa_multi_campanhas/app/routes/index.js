var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate')

//Rota padrão criada pelo express para inicialização da aplicação
router.get('/', authenticate.auth, function(req, res) {
  res.render('campanha_cadastro');
});

//Verifica se o usuario fez login, em caso afirmativo: entra na pag principal, senão fica em login
router.get('/login', function(req, res) {
  if (req.session.userid) {
    res.redirect('campanha_cadastro')
  } else {
    res.render('login');
  }
});

//Abrir tela de cadastro de campanha
router.get('/cadastrar-campanha', authenticate.auth, function(req, res) {
  res.render('campanha_cadastro');
});

//Abrir tela de gerenciamento de campanha
router.get('/gerenciamento-de-campanha', authenticate.auth, function(req, res) {
  res.render('campanha_gerenciamento');
});

//Abrir tela de gerenciamento de campanha
router.get('/historico-de-campanhas', authenticate.auth, function(req, res) {
  res.render('campanha_historico');
});

//Abrir tela de bilhetes
router.get('/bilhetes', authenticate.auth, function(req, res) {
  res.render('bilhetes');
});

//Abrir tela de contatos
router.get('/contatos', authenticate.auth, function(req, res) {
  res.render('contatos');
});

//Abrir tela de feriados
router.get('/feriados', authenticate.auth, function(req, res) {
  res.render('feriados');
});

//Abrir tela de configuracoes
router.get('/configuracoes', authenticate.auth, function(req, res) {
  res.render('configuracoes');
});

//Abrir tela de dias da semana
router.get('/diasdasemana', authenticate.auth, function(req, res) {
  res.render('diasdasemana');
});

//Abrir tela de usuario
router.get('/usuarios', authenticate.auth, function(req, res) {
  res.render('usuario');
});

//Abrir tela de manutencao
router.get('/manutencao', authenticate.auth, function(req, res) {
  res.render('manutencao');
});

//Abrir tela de monitoramento do HD
router.get('/monitoramento-disco-rigido', authenticate.auth, function(req, res) {
  res.render('monitoramento_disco_rigido');
});

//Abrir tela de monitoramento das chamadas
router.get('/monitoramento-discagens', authenticate.auth, function(req, res) {
  res.render('monitoramento_discagens');
});

//Abrir tela de audios
router.get('/audios', authenticate.auth, function(req, res) {
  res.render('audio');
});

module.exports = router;
