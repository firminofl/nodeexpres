var express = require('express');
var router = express.Router();
var audios_controller = require('../controller/audios');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Fazer upload dos audios
router.post('/insert', audios_controller.insert);

//Buscar audios
router.get('/select', audios_controller.select);

module.exports = router;
