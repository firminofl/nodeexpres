//Variaveis no escopo global para reduzir suas instancias
var selecionarCampanha = document.getElementById("selecionarCampanha");

var totalContatos = $("#totalContatos");
var totalDiscagens = $("#totalDiscagens");
var totalDTMF1 = $("#totalDTMF1");
var totalDTMF2 = $("#totalDTMF2");
var totalDTMF3 = $("#totalDTMF3");
var totalAtendidas = $("#totalAtendidas");
var totalNaoAtendidas = $("#totalNaoAtendidas");

var json = null;

var campanhaVigente = null;
var campanhaVigenteValue = null;

function atualizaHistoricoCampanhas() {

  //Iniciar os campos zerados
  dadosZerados();

  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/campanha/selectSomenteCampanhasParadas')

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          inserirCampanhasSelect(JSON.parse(this.response));
          break;

        case 304:
          inserirCampanhasSelect(JSON.parse(this.response));
          break;

        case 400:
          alertForm(JSON.parse(this.response).message);
          break;

        case 500:
          alertForm(JSON.parse(this.response).message);
          break;

        case 404:
          alertForm('Não foi possível alcançar o servidor');
          break;

        default:
          alertForm('Erro inesperado, contate o administrador');
          break;
      }
    }
  }
  xhttp.send();
}

function inserirCampanhasSelect(rows) {
  //Pegar referencia do select(combobox) das campanhas
  for (var i = 0; i < rows.length; i++) {
    selecionarCampanha;
    var option = document.createElement("option");
    option.value = i + 1;
    option.text = rows[i].campanha_nome;
    selecionarCampanha.append(option);
  }
}

function escolherCampanha() {
  //Buscando o value da campanha clicada
  campanhaVigenteValue = selecionarCampanha.options[selecionarCampanha.selectedIndex].value;

  if (campanhaVigenteValue == 0) {
    dadosZerados();
  } else {
    //Buscando o nome da campanha clicada
    campanhaVigente = selecionarCampanha.options[selecionarCampanha.selectedIndex].text;

    var xhttp = new XMLHttpRequest();

    var object = {
      campanhaVigente: campanhaVigente
    }

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            json = JSON.parse(this.response);
            mostrarValores();
            break;

          case 304:
            json = JSON.parse(this.response);
            mostrarValores();
            break;

          case 400:
            alertForm(JSON.parse(this.response).message);
            break;

          case 500:
            alertForm(JSON.parse(this.response).message);
            break;

          default:
            alertForm("Erro inesperado, contate o administrador.");
            break;
        }
      }
    }
    xhttp.open('POST', '/campanha/selectDadosCampanhaVigenteParada', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
  }
}

function mostrarValores() {
  totalContatos.val(json.totalContatos);
  totalDiscagens.val(json.totalDiscagens);
  totalDTMF1.val(json.totalDTMF1);
  totalDTMF2.val(json.totalDTMF2);
  totalDTMF3.val(json.totalDTMF3);
  totalAtendidas.val(json.totalAtendidas);
  totalNaoAtendidas.val(json.totalNaoAtendidas);
}

function exportarCSV() {
  //Buscando o value da campanha clicada
  campanhaVigenteValue = selecionarCampanha.options[selecionarCampanha.selectedIndex].value;

  if (campanhaVigenteValue == 0) {
    dadosZerados();
    alertForm('Escolha uma campanha para exportar seus dados.');
  } else {
    //Mostrar que o processo pode demorar
    swal({
      title: "Exportar CSV",
      text: "Este processo pode demorar um tempo!"
    });

    //Exportar dados de acordo com a campanha escolhida
    var csv = 'Nome campanha, Total contatos, Total discagens, Total DTMF 1,' +
      ' Total DTMF 2, Total DTMF 3, Total atendidas, Total Não atendidas\n';

    csv += campanhaVigente;
    csv += ',' + json.totalContatos;
    csv += ',' + json.totalDiscagens;
    csv += ',' + json.totalDTMF1;
    csv += ',' + json.totalDTMF2;
    csv += ',' + json.totalDTMF3;
    csv += ',' + json.totalAtendidas;
    csv += ',' + json.totalNaoAtendidas;
    csv += '\n';

    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'historico_campanha_' + campanhaVigente + '.csv';
    hiddenElement.click();
  }
}

function alertForm(message) {
  var red_alert = document.getElementById('red_alert_historico');
  red_alert.style.visibility = 'none';
  red_alert.innerHTML = message;
  red_alert.classList.add('show')
  setTimeout(() => {
    red_alert.classList.remove('show')
  }, 3000);
}

function dadosZerados() {
  totalContatos.val('0');
  totalDiscagens.val('0');
  totalDTMF1.val('0');
  totalDTMF2.val('0');
  totalDTMF3.val('0');
  totalAtendidas.val('0');
  totalNaoAtendidas.val('0');
}
