const pg = require('../db');
const exec = require('child_process').exec;

var totalContatos = null;
var totalDiscagens = null;
var totalDTMF1 = null;
var totalDTMF2 = null;
var totalDTMF3 = null;
var totalAtendidas = null;
var totalNaoAtendidas = null;
var statusPausado = null;

module.exports = {
  insertContatos: (req, res) => {
    files = req.files.importaContatos;
    files2 = req.files;

    if (!files && !files2) {
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum arquivo CSV e áudio enviado'
      });
    }

    try {
      //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
      var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';
      var ultimoIdCampanha = 0;
      var allRows = null;
      var qtdContatos = 0;

      pg.query(sqlUltimaCampanha, [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Resultado do ultimo id de campanha cadastrada
          ultimoIdCampanha = ans.rows[0].max;

          //Converter arquivo csv para texto e fazer sua analise
          allRows = files.data.toString().split(/\r?\n|\r/);

          //Fazer update na tabela de campanha a quantidade de contatos
          qtdContatos = (allRows.length.valueOf() - 2);

          var queryUpdate = 'UPDATE campanha SET campanha_total_contatos = ' + qtdContatos + ' WHERE campanha_id = ' + ultimoIdCampanha;
          pg.query(queryUpdate, [], (err, ans) => {
            if (err) {
              console.log("Error: " + err)
              return res.status(500).send({
                error: 'Erro interno',
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              //Construir query para multiplos parametros no insert
              var params = []
              var chunks = []
              //Inicia a partir do dado e desconsidera o titulo das colunas no csv
              for (var singleRow = 1; singleRow <= qtdContatos; singleRow++) {
                var rowCells = allRows[singleRow].split(',');
                for (var rowCell = 0; rowCell < rowCells.length; rowCell++) {
                  var valueClause = []
                  //Pegar nome do contato:
                  var nomeContato = rowCells[rowCell];
                  valueClause.push("'" + nomeContato + "'")
                  rowCell++;

                  //Pegar telefone 1
                  var tel1Contato = rowCells[rowCell];
                  valueClause.push("'" + tel1Contato + "'")
                  rowCell++;

                  //Pegar Telefone 2
                  var tel2Contato = rowCells[rowCell];
                  valueClause.push("'" + tel2Contato + "'")

                  //Identificacao da campanha que o contato esta inserido
                  valueClause.push(ultimoIdCampanha)

                  //Construindo um array para insercao
                  chunks.push('(' + valueClause.join(', ') + ')')
                }
              }
              //Query de inserir contato novo na campanha
              var query = 'INSERT INTO contato(contato_nome,contato_tel1,contato_tel2, campanha_fk) ' +
                'VALUES ' + chunks.join(', ');

              pg.query(query, [], (err, ans) => {
                if (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro interno, por favor contacte o administrador'
                  });
                } else {
                  var nomeAudio = files2.audioCampanha.name.split('.')[0];

                  try {
                    //Verificar se existe o audio cadastrado com o mesmo nome que está vindo do front-end
                    var queryAudioCampanha = 'SELECT COUNT(campanha_audio) FROM campanha WHERE campanha_audio = ' + "'" + nomeAudio + "'";

                    pg.query(queryAudioCampanha, [], (err, ans) => {
                      if (err) {
                        return res.status(500).send({
                          error: 'Erro interno',
                          message: 'Erro interno, por favor contacte o administrador'
                        });
                      } else {
                        //Caso não tenha campanha cadastrada com o nome vindo do front-end
                        var temOuNaoAudio = ans.rows[0].count;

                        if (temOuNaoAudio > 0) {
                          //A campanha foi cadastrada, ela precisa ser excluída para que o usuario apenas atualize o audio
                          //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
                          var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                          pg.query(sqlUltimaCampanha, [], (err, ans) => {
                            if (err) {
                              return res.status(500).send({
                                error: 'Erro interno',
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            } else {
                              //Resultado do ultimo id de campanha cadastrada
                              var ultimoIdCampanha = ans.rows[0].max;

                              //Deletar a campanha cadastrada com o audio que tinha no banco
                              var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                              pg.query(queryDeleteCampanha, [], (err, ans) => {
                                if (err) {
                                  return res.status(500).send({
                                    error: 'Erro interno',
                                    message: 'Erro interno, por favor contacte o administrador'
                                  });
                                }
                              });
                            }
                          });

                          console.log("\n\nExiste um áudio cadastrado com este mesmo nome. Verifique!\n\n");
                          return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Existe um áudio cadastrado com este mesmo nome. Verifique!'
                          });

                        } else if (temOuNaoAudio == 0) {
                          //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
                          var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

                          pg.query(sqlUltimaCampanha, [], (err, ans) => {
                            if (err) {
                              return res.status(500).send({
                                error: 'Erro interno',
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            } else {
                              //Resultado do ultimo id de campanha cadastrada
                              var ultimoIdCampanha = ans.rows[0].max;

                              //Extraindo o nome do audio para montar a query de update
                              var nomeAudio = files2.audioCampanha.name.split('.')[0];

                              var sqlUpdate = 'UPDATE campanha SET campanha_audio = ' + "'" + nomeAudio + "'" + ' WHERE campanha_id = ' + ultimoIdCampanha;

                              try {

                                pg.query(sqlUpdate);

                              } catch (err) {
                                return res.status(500).send({
                                  error: 'Erro interno',
                                  message: 'Erro interno, por favor contacte o administrador. Áudio não foi atualizado.'
                                });
                              }

                              if (files2.audioCampanha.length === undefined) {
                                try {
                                  //await files.audios.mv('/opt/leucotron/confirma/sounds/' + files.audios.name)
                                  files2.audioCampanha.mv('/opt/leucotron/sounds/' + files2.audioCampanha.name)
                                  //files.audioCampanha.mv('/home/filipefirmino/Music/sounds' + files.audioCampanha.name)
                                } catch (error) {
                                  return res.status(500).send({
                                    error: 'Upload file',
                                    message: 'Erro ao gravar áudio no servidor'
                                  })
                                }
                              } else {
                                for (var i = 0; i < files2.audioCampanha.length; i++) {
                                  try {
                                    ///home/filipefirmino/Music/sounds/
                                    //await files.audios[i].mv('/opt/leucotron/ura/sounds/' + files.audios[i].name)
                                    files2.audioCampanha[i].mv('/opt/leucotron/sounds/' + files2.audioCampanha[i].name)
                                    //files.audioCampanha[i].mv('/home/filipefirmino/Music/sounds' + files.audioCampanha.name)
                                  } catch (error) {
                                    return res.status(500).send({
                                      error: 'Upload file',
                                      message: 'Erro ao gravar áudio no servidor'
                                    });
                                  }
                                }
                              }
                              execute('sudo converteAudio.sh', (error, stdout) => { });
                              //execute('sudo /etc/init.d/dialer restart', (stdout) => { })

                              return res.json({
                                success: 'Configurado',
                                message: 'Campanha configurada com sucesso!'
                              });
                            }
                          });
                        }
                      }
                    });
                  } catch (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  }
                }
              });
            }
          });
        }
      });
    } catch (error) {
      console.log("Error: " + error)
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insertAudio: async (req, res) => {
    files = req.files;
    filesName = req.body;

    if (!files) {
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum arquivo de áudio enviado'
      });
    }
    var nomeAudio = files.audioCampanha.name.split('.')[0];

    try {
      //Verificar se existe o audio cadastrado com o mesmo nome que está vindo do front-end
      var queryAudioCampanha = 'SELECT COUNT(campanha_audio) FROM campanha WHERE campanha_audio = ' + "'" + nomeAudio + "'";

      pg.query(queryAudioCampanha, [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Caso não tenha campanha cadastrada com o nome vindo do front-end
          var temOuNaoAudio = ans.rows[0].count;

          if (temOuNaoAudio > 0) {
            //A campanha foi cadastrada, ela precisa ser excluída para que o usuario apenas atualize o audio
            //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
            var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

            pg.query(sqlUltimaCampanha, [], (err, ans) => {
              if (err) {
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              } else {
                //Resultado do ultimo id de campanha cadastrada
                var ultimoIdCampanha = ans.rows[0].max;

                //Deletar a campanha cadastrada com o audio que tinha no banco
                var queryDeleteCampanha = 'DELETE FROM campanha WHERE campanha_id = ' + ultimoIdCampanha
                pg.query(queryDeleteCampanha, [], (err, ans) => {
                  if (err) {
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  }
                });
              }
            });

            console.log("\n\nExiste um áudio cadastrado com este mesmo nome. Verifique!\n\n");
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Existe um áudio cadastrado com este mesmo nome. Verifique!'
            });

          } else if (temOuNaoAudio == 0) {
            //Buscar a campanha cadastrada por ultimo, para fazer o update no nome do audio
            var sqlUltimaCampanha = 'SELECT MAX(campanha_id) FROM campanha;';

            pg.query(sqlUltimaCampanha, [], (err, ans) => {
              if (err) {
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              } else {
                //Resultado do ultimo id de campanha cadastrada
                var ultimoIdCampanha = ans.rows[0].max;

                //Extraindo o nome do audio para montar a query de update
                var nomeAudio = files.audioCampanha.name.split('.')[0];

                var sqlUpdate = 'UPDATE campanha SET campanha_audio = ' + "'" + nomeAudio + "'" + ' WHERE campanha_id = ' + ultimoIdCampanha;

                try {

                  pg.query(sqlUpdate);

                } catch (err) {
                  return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro interno, por favor contacte o administrador. Áudio não foi atualizado.'
                  });
                }

                if (files.audioCampanha.length === undefined) {
                  try {
                    //await files.audios.mv('/opt/leucotron/confirma/sounds/' + files.audios.name)
                    files.audioCampanha.mv('/opt/leucotron/sounds/' + files.audioCampanha.name)
                    //files.audioCampanha.mv('/home/filipefirmino/Music/sounds' + files.audioCampanha.name)
                  } catch (error) {
                    return res.status(500).send({
                      error: 'Upload file',
                      message: 'Erro ao gravar áudio no servidor'
                    })
                  }
                } else {
                  for (var i = 0; i < files.audioCampanha.length; i++) {
                    try {
                      ///home/filipefirmino/Music/sounds/
                      //await files.audios[i].mv('/opt/leucotron/ura/sounds/' + files.audios[i].name)
                      files.audioCampanha[i].mv('/opt/leucotron/sounds/' + files.audioCampanha[i].name)
                      //files.audioCampanha[i].mv('/home/filipefirmino/Music/sounds' + files.audioCampanha.name)
                    } catch (error) {
                      return res.status(500).send({
                        error: 'Upload file',
                        message: 'Erro ao gravar áudio no servidor'
                      });
                    }
                  }
                }
                execute('sudo converteAudio.sh', (error, stdout) => { });
                //execute('sudo /etc/init.d/dialer restart', (stdout) => { })

                return res.json({
                  success: 'Configurado',
                  message: 'Campanha configurada com sucesso!'
                });
              }
            });
          }
        }
      });
    } catch (err) {
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  insert: (req, res) => {
    var nomeCampanha = req.body.nomeCampanha;
    //totalcontatos = req.body.totalContatos;
    var tentativasDiscagem = req.body.tentativasDiscagem;
    var intervaloDiscagens = req.body.intervaloDiscagens;
    var chamadaSimultaneas = req.body.chamadaSimultaneas;

    if (!nomeCampanha && !tentativasDiscagem && !intervaloDiscagens && !chamadaSimultaneas)
      return res.status(400).send();

    try {
      //Verificar se existe uma campanha cadastrada com o mesmo nome
      var queryNomeCampanha = 'SELECT COUNT(campanha_nome) FROM campanha WHERE campanha_nome = ' + "'" + nomeCampanha + "'";
      pg.query(queryNomeCampanha, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Caso não tenha campanha cadastrada com o nome vindo do front-end
          temOuNaoCampanha = ans.rows[0].count;

          if (temOuNaoCampanha > 0) {
            console.log("\n\nExiste uma campanha cadastrada com este mesmo nome. Verifique!\n\n")
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Existe uma campanha cadastrada com este mesmo nome. Verifique!'
            });
          } else if (temOuNaoCampanha == 0) {
            //Modificando o status da campanha para default no Cadastro
            var queryStatus = 'INSERT INTO status(ativado, pausado,parado)VALUES (default, default,default);';
            pg.query(queryStatus, [], (err, ans) => {
              if (err) {
                console.log("\n\nError: " + err)
                return res.status(500).send({
                  error: 'Erro interno',
                  message: 'Erro interno, por favor contacte o administrador'
                });
              } else {
                //Buscando o id do status para passar no parametro
                var queryUltimoId = 'SELECT MAX(status_id) from status;';
                pg.query(queryUltimoId, [], (err, ans) => {
                  if (err) {
                    console.log("\n\nError: " + err)
                    return res.status(500).send({
                      error: 'Erro interno',
                      message: 'Erro interno, por favor contacte o administrador'
                    });
                  } else {
                    //Resultado do ultimo id do status
                    var ultimoIdStatus = ans.rows[0].max;

                    //Inserindo agora a campanha
                    var nomeAudio = ultimoIdStatus;
                    var totalContatos = 000;

                    //Query de inserção na tabela de campanha, posteriormente o nomeAudio vai ser alterado para o real.
                    var query = 'INSERT INTO campanha(campanha_nome, campanha_audio, campanha_num_tentativa, campanha_intervalo_discagem, campanha_chamadas_simultaneas, campanha_total_contatos, status_fk)' +
                      'VALUES(' + "'" + nomeCampanha + "'" + "," + "'" + nomeAudio + "'" + "," + tentativasDiscagem + "," + intervaloDiscagens + "," + chamadaSimultaneas + "," + totalContatos + "," + ultimoIdStatus + ")";

                    pg.query(query, [], (err, ans) => {
                      if (err) {
                        console.log("\n\nError: " + err)
                        return res.status(500).send({
                          error: 'Erro interno',
                          message: 'Erro interno, por favor contacte o administrador'
                        });
                      } else {
                        res.status(200).send({
                          message: 'Campanha configurada com sucesso!'
                        });
                      }
                    });
                  }
                });
              }
            });
          }
        }
      });
    } catch (error) {
      console.log("\n\nError: " + error)
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  select: (req, res) => {
    //Buscar quantidade de campanhas cadastradas
    var queryQtdCampanha = 'SELECT COUNT(campanha_id) FROM campanha,status WHERE status_fk = status_id';

    pg.query(queryQtdCampanha, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem campanha cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma campanha cadastrada!'
          });
        } else {
          //paginacao no front-end
          var pagination = req.body.pagination;

          if (pagination == null || pagination == 1) {
            pagination = 0;
          } else if (pagination > 1) {
            pagination = pagination * 10 - 10;
          }

          //Query de busca do id, nome e audio da companha
          var query = 'SELECT campanha_id,campanha_nome,campanha_audio FROM campanha,status WHERE status_fk = status_id ORDER BY campanha_id DESC LIMIT 10 OFFSET ' + pagination;

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              var data = new Object();
              data.contador = count;
              data.result = ans.rows;
              res.json(data);
            }
          });
        }
      }
    });
  },

  delete: (req, res) => {
    var campanha_id = req.body.campanha_id;

    var query = 'DELETE FROM campanha WHERE campanha_id = ' + campanha_id;

    pg.query(query, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao deletar dados no servidor'
        });
      } else {
        res.json({
          message: 'Campanha excluída com sucesso!'
        });
      }
    });
  },

  export: (req, res) => {
    //Buscar quantidade de campanhas cadastradas
    var queryQtdCampanha = 'SELECT COUNT(campanha_id) FROM campanha,status WHERE status_fk = status_id';

    pg.query(queryQtdCampanha, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0];

        //Verificar se não tem campanha cadastrada
        if (count.count == 0) {
          return res.status(500).send({
            contador: count,
            message: 'Nenhuma campanha cadastrada!'
          });
        } else {
          //Query de busca 'da companha
          var query = 'SELECT * FROM campanha,status WHERE status_fk = status_id ORDER BY campanha_id DESC';

          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  },

  selectSomenteCampanhas: (req, res) => {
    //Verificar se existe alguma campanha cadastrada
    var queryVerificaCampanhaCadastrada = 'SELECT COUNT(campanha_nome) as resultado FROM campanha, status WHERE status_fk = status_id AND parado = FALSE;';
    pg.query(queryVerificaCampanhaCadastrada, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0].resultado;

        //Verificar se não tem campanha cadastrada
        if (count == 0) {
          return res.status(500).send({
            message: 'Nenhuma campanha cadastrada!',
            contador: count
          });
        } else {
          //query para buscar somente os nomes das campanhas e popular o select(combobox) na tela de gerenciamento
          var query = 'SELECT campanha_nome FROM campanha, status WHERE status_fk = status_id AND parado = FALSE ORDER BY campanha_nome ASC;';
          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  },

  selectSomenteCampanhasParadas: (req, res) => {
    //Verificar se existe alguma campanha cadastrada
    var queryVerificaCampanhaCadastrada = 'SELECT COUNT(campanha_nome) as resultado FROM campanha, status WHERE status_fk = status_id AND parado = TRUE;';
    pg.query(queryVerificaCampanhaCadastrada, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Quantidade retornada da consulta
        var count = ans.rows[0].resultado;

        //Verificar se não tem campanha cadastrada
        if (count == 0) {
          return res.status(500).send({
            message: 'Nenhuma campanha parada!'
          });
        } else {
          //query para buscar somente os nomes das campanhas e popular o select(combobox) na tela de gerenciamento
          var query = 'SELECT campanha_nome FROM campanha, status WHERE status_fk = status_id AND parado = TRUE ORDER BY campanha_nome ASC;';
          pg.query(query, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              res.json(ans.rows);
            }
          });
        }
      }
    });
  },

  selectDadosCampanhaVigente: (req, res) => {
    //Recebendo o nome da campanha
    var campanhaVigente = req.body.campanhaVigente;

    if (!campanhaVigente) {
      return res.status(400).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }

    //Verificar se a campanha teve seu status alterado para ativado = TRUE, por causa dos botoes de start,pause e stop no front-end
    try {
      var queryStatusAtivado = 'SELECT COUNT(ativado) FROM  status,campanha WHERE status_fk = status_id ' +
        'AND ativado = TRUE and campanha_nome = ' + "'" + campanhaVigente + "';";

      //Executar comando no banco
      pg.query(queryStatusAtivado, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Pega o resultado obtido da query
          totalAtivado = ans.rows[0].count;

          //Verifica se tem um 1 campanha ativada, se TRUE então não pode mostrar a opção de dar play na campanha
          if (totalAtivado == 0) {
            //Response enviado para o front-end
            res.json({
              ativado: 0,
              pausado: 0
            });

          } else if (totalAtivado == 1) {
            //Verificação de cada campo e incrementar as variaveis e dados
            try {
              //Verificar a quantidade de contatos
              var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status WHERE status_fk = status_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "';";

              //Executar comando no banco
              pg.query(queryQtdContatos, [], (err, ans) => {
                if (err) {
                  console.log("\n\nError: " + err)
                  return res.status(500).send({
                    message: 'Erro interno, por favor contacte o administrador'
                  });
                } else {
                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                  totalContatos = ans.rows[0].campanha_total_contatos;

                  //Verificar total discagens
                  var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND campanha_nome = ' + "'" + campanhaVigente + "';";

                  //Executar comando no banco
                  pg.query(queryTotalDiscagens, [], (err, ans) => {
                    if (err) {
                      console.log("\n\nError: " + err)
                      return res.status(500).send({
                        message: 'Erro interno, por favor contacte o administrador'
                      });
                    } else {
                      //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                      totalDiscagens = ans.rows[0].count;

                      //Verificar total DTMF1
                      var queryTotalDTMF1 = 'SELECT COUNT(cdr_dtmf) as dtfm1 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND cdr_dtmf = ' + "'1'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                      //Executar comando no banco
                      pg.query(queryTotalDTMF1, [], (err, ans) => {
                        if (err) {
                          console.log("\n\nError: " + err)
                          return res.status(500).send({
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {
                          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                          totalDTMF1 = ans.rows[0].dtfm1;

                          //Verificar total DTMF2
                          var queryTotalDTMF2 = 'SELECT COUNT(cdr_dtmf) as dtfm2 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND cdr_dtmf = ' + "'2'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                          //Executar comando no banco
                          pg.query(queryTotalDTMF2, [], (err, ans) => {
                            if (err) {
                              console.log("\n\nError: " + err)
                              return res.status(500).send({
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            } else {
                              //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                              totalDTMF2 = ans.rows[0].dtfm2;

                              //Verificar total DTMF3
                              var queryTotalDTMF3 = 'SELECT COUNT(cdr_dtmf) as dtfm3 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND cdr_dtmf = ' + "'3'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                              //Executar comando no banco
                              pg.query(queryTotalDTMF3, [], (err, ans) => {
                                if (err) {
                                  console.log("\n\nError: " + err)
                                  return res.status(500).send({
                                    message: 'Erro interno, por favor contacte o administrador'
                                  });
                                } else {
                                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                  totalDTMF3 = ans.rows[0].dtfm3;

                                  //Verificar total atendidas
                                  var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                                  //Executar comando no banco
                                  pg.query(queryTotalAtendidas, [], (err, ans) => {
                                    if (err) {
                                      console.log("\n\nError: " + err)
                                      return res.status(500).send({
                                        message: 'Erro interno, por favor contacte o administrador'
                                      });
                                    } else {
                                      //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                      totalAtendidas = ans.rows[0].count;

                                      //Verificar total não atendidas
                                      var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = FALSE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                                      //Executar comando no banco
                                      pg.query(queryTotalNaoAtendidas, [], (err, ans) => {
                                        if (err) {
                                          console.log("\n\nError: " + err)
                                          return res.status(500).send({
                                            message: 'Erro interno, por favor contacte o administrador'
                                          });
                                        } else {
                                          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                          totalNaoAtendidas = ans.rows[0].count;

                                          //Verificar se a campanha está pausada
                                          var campanhaPausada = 'SELECT COUNT(pausado) FROM status,campanha WHERE status_fk = status_id ' +
                                            'AND pausado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "';";

                                          pg.query(campanhaPausada, [], (err, ans) => {
                                            if (err) {
                                              console.log("\n\nError: " + err)
                                              return res.status(500).send({
                                                message: 'Erro interno, por favor contacte o administrador'
                                              });
                                            } else {
                                              //Pega o resultado obtido da query
                                              statusPausado = ans.rows[0].count;
                                              //Enviar os dados para o Front-end
                                              var objectResult;

                                              if (statusPausado == 0) {
                                                //Está ativo sem pausa
                                                objectResult = {
                                                  totalContatos: totalContatos,
                                                  totalDiscagens: totalDiscagens,
                                                  totalDTMF1: totalDTMF1,
                                                  totalDTMF2: totalDTMF2,
                                                  totalDTMF3: totalDTMF3,
                                                  totalAtendidas: totalAtendidas,
                                                  totalNaoAtendidas: totalNaoAtendidas,
                                                  ativado: 1,
                                                  pausado: 0
                                                }
                                              } else {
                                                //Está ativo com pausa
                                                objectResult = {
                                                  totalContatos: totalContatos,
                                                  totalDiscagens: totalDiscagens,
                                                  totalDTMF1: totalDTMF1,
                                                  totalDTMF2: totalDTMF2,
                                                  totalDTMF3: totalDTMF3,
                                                  totalAtendidas: totalAtendidas,
                                                  totalNaoAtendidas: totalNaoAtendidas,
                                                  ativado: 1,
                                                  pausado: 1
                                                }
                                              }
                                              /*
                                              console.log("\n\nTotal Contatos: " + objectResult.totalContatos
                                                + "\nTotal Discagens: " + objectResult.totalDiscagens
                                                + "\nTotal DTMF1: " + objectResult.totalDTMF1
                                                + "\nTotal DTMF2: " + objectResult.totalDTMF2
                                                + "\nTotal DTMF3: " + objectResult.totalDTMF3
                                                + "\nTotal Atendidas: " + objectResult.totalAtendidas
                                                + "\nTotal Nao Atendidas: " + objectResult.totalNaoAtendidas
                                                + "\nStatus pausa: " + objectResult.pausado + "\n");
                                                */
                                              //Response enviado para o front-end
                                              res.json(objectResult);

                                            }
                                          });

                                        }
                                      });
                                    }
                                  });
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  });
                }
              });
            } catch (error) {
              console.log("Error: " + error);
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            }
          }
        }
      });

    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }

  },

  selectDadosCampanhaVigenteParada: (req, res) => {
    //Recebendo o nome da campanha
    var campanhaVigente = req.body.campanhaVigente;

    if (!campanhaVigente) {
      return res.status(400).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }

    //Verificação de cada campo e incrementar as variaveis e dados
    try {
      //Verificar a quantidade de contatos
      var queryQtdContatos = 'SELECT campanha_total_contatos FROM campanha, status WHERE status_fk = status_id AND parado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "';";

      //Executar comando no banco
      pg.query(queryQtdContatos, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
          totalContatos = ans.rows[0].campanha_total_contatos;

          //Verificar total discagens
          var queryTotalDiscagens = 'SELECT COUNT(cdr_id) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = TRUE AND campanha_nome = ' + "'" + campanhaVigente + "';";

          //Executar comando no banco
          pg.query(queryTotalDiscagens, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
              totalDiscagens = ans.rows[0].count;

              //Verificar total DTMF1
              var queryTotalDTMF1 = 'SELECT COUNT(cdr_dtmf) as dtfm1 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = TRUE AND cdr_dtmf = ' + "'1'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

              //Executar comando no banco
              pg.query(queryTotalDTMF1, [], (err, ans) => {
                if (err) {
                  console.log("\n\nError: " + err)
                  return res.status(500).send({
                    message: 'Erro interno, por favor contacte o administrador'
                  });
                } else {
                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                  totalDTMF1 = ans.rows[0].dtfm1;

                  //Verificar total DTMF2
                  var queryTotalDTMF2 = 'SELECT COUNT(cdr_dtmf) as dtfm2 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = TRUE AND cdr_dtmf = ' + "'2'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                  //Executar comando no banco
                  pg.query(queryTotalDTMF2, [], (err, ans) => {
                    if (err) {
                      console.log("\n\nError: " + err)
                      return res.status(500).send({
                        message: 'Erro interno, por favor contacte o administrador'
                      });
                    } else {
                      //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                      totalDTMF2 = ans.rows[0].dtfm2;

                      //Verificar total DTMF3
                      var queryTotalDTMF3 = 'SELECT COUNT(cdr_dtmf) as dtfm3 FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = TRUE AND cdr_dtmf = ' + "'3'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                      //Executar comando no banco
                      pg.query(queryTotalDTMF3, [], (err, ans) => {
                        if (err) {
                          console.log("\n\nError: " + err)
                          return res.status(500).send({
                            message: 'Erro interno, por favor contacte o administrador'
                          });
                        } else {
                          //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                          totalDTMF3 = ans.rows[0].dtfm3;

                          //Verificar total atendidas
                          var queryTotalAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = TRUE AND cdr_status_chamada = ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                          //Executar comando no banco
                          pg.query(queryTotalAtendidas, [], (err, ans) => {
                            if (err) {
                              console.log("\n\nError: " + err)
                              return res.status(500).send({
                                message: 'Erro interno, por favor contacte o administrador'
                              });
                            } else {
                              //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                              totalAtendidas = ans.rows[0].count;

                              //Verificar total não atendidas
                              var queryTotalNaoAtendidas = 'SELECT COUNT(cdr_status_chamada) FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND campanha_fk = campanha_id AND status_fk = status_id AND parado = TRUE AND cdr_status_chamada <> ' + "'ANSWER'" + ' AND campanha_nome = ' + "'" + campanhaVigente + "';";

                              //Executar comando no banco
                              pg.query(queryTotalNaoAtendidas, [], (err, ans) => {
                                if (err) {
                                  console.log("\n\nError: " + err)
                                  return res.status(500).send({
                                    message: 'Erro interno, por favor contacte o administrador'
                                  });
                                } else {
                                  //Armazenando temporariamente o valor da variavel para enviar tudo de uma vez para o front-end
                                  totalNaoAtendidas = ans.rows[0].count;

                                  //Enviar os dados para o Front-end
                                  var objectResult = {
                                    totalContatos: totalContatos,
                                    totalDiscagens: totalDiscagens,
                                    totalDTMF1: totalDTMF1,
                                    totalDTMF2: totalDTMF2,
                                    totalDTMF3: totalDTMF3,
                                    totalAtendidas: totalAtendidas,
                                    totalNaoAtendidas: totalNaoAtendidas
                                  }

                                  console.log("\n\nTotal Contatos: " + objectResult.totalContatos
                                    + "\nTotal Discagens: " + objectResult.totalDiscagens
                                    + "\nTotal DTMF1: " + objectResult.totalDTMF1
                                    + "\nTotal DTMF2: " + objectResult.totalDTMF2
                                    + "\nTotal DTMF3: " + objectResult.totalDTMF3
                                    + "\nTotal Atendidas: " + objectResult.totalAtendidas
                                    + "\nTotal Nao Atendidas: " + objectResult.totalNaoAtendidas + "\n");
                                  //Response enviado para o front-end
                                  res.json(objectResult);
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  });
                }
              });
            }
          });
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  iniciarCampanha: (req, res) => {
    //Recebendo o nome da campanha para ativa-la
    var nomeCampanha = req.body.campanhaVigente;

    //Verificar se existe uma campanha com o status ativado = TRUE executando
    try {
      //Query para verificar se existe campanha em execucao
      var queryCampanhaExecutando = 'SELECT COUNT(ativado) as ativado FROM status, campanha WHERE status_fk = status_id AND ativado = TRUE';

      pg.query(queryCampanhaExecutando, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {

          //Retorno obtido do banco e verificar o total
          var totalAtivado = ans.rows[0].ativado;

          //Primeira vez que está sendo inicializado a campanha
          if (totalAtivado == 0) {
            try {
              //Ativar a campanha atraves da tabela status
              var sqlAtivar = 'UPDATE status SET ativado = TRUE FROM campanha WHERE status_fk = status_id AND campanha_nome = ' + "'" + nomeCampanha + "';";

              pg.query(sqlAtivar, [], (err, ans) => {
                if (err) {
                  console.log("\n\nError: " + err)
                  return res.status(500).send({
                    message: 'Erro interno, por favor contacte o administrador'
                  });
                } else {
                  //execute('sudo /bin/bash /usr/bin/dialer.sh stop', (stdout) => {});
                  //execute('sudo dialer.sh start', (stdout) => {
                  //console.log("\nCallback start: " + stdout);
                  //});
                  execute('sudo /etc/init.d/dialer start', (stdout) => { });

                  setTimeout(() => {
                    console.log("\n\nDialer ativado!\nSistema de discagem comecou!\n\n");
                    res.status(200).send();
                  }, 1000);
                }
              });
            } catch (error) {
              console.log("Error: " + error);
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            }
          } else if (totalAtivado != 0) {
            //Campanha ativada
            return res.status(500).send({
              message: 'Somente uma campanha pode ser iniciada por vez!'
            });
          }
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  reiniciarCampanha: (req, res) => {
    //Recebendo o nome da campanha para reativa-la
    var nomeCampanha = req.body.campanhaVigente;

    //passar o status pausado para FALSE
    var pausadoFalse = 'UPDATE status SET pausado = FALSE FROM campanha WHERE status_fk = status_id AND ativado = TRUE AND campanha_nome = ' + "'" + nomeCampanha + "';";

    pg.query(pausadoFalse, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        console.log("\n\nDialer reativado!\nSistema de discagem recomecou!\n\n")
        //execute('sudo bash -x /usr/bin/dialer.sh start', (stdout) => {});
        //execute('sudo bash -x /etc/init.d/dialer start', (stdout) => {});

        res.status(200).send();
      }
    });
  },

  pararCampanha: (req, res) => {
    //Recebendo o nome da campanha para ativa-la
    var nomeCampanha = req.body.campanhaVigente;

    try {
      //Buscar os contatos com contagem de discagem = 0 e o nome da campanha atrelado
      var sqlBuscaContDiscagem = 'UPDATE contato SET contato_excluido = TRUE FROM campanha ' +
        ' WHERE contato_cont_discagem = 0 AND campanha_fk = campanha_id AND campanha_nome = ' + "'" + nomeCampanha + "';";

      pg.query(sqlBuscaContDiscagem, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          //Atualizar o status parado = TRUE para os contatos marcados como excluido
          var sqlStatusParado = 'UPDATE status SET parado = TRUE, ativado = FALSE, pausado = FALSE FROM campanha,contato ' +
            'WHERE contato_excluido = TRUE AND status_fk = status_id AND campanha_nome = ' + "'" + nomeCampanha + "';";

          pg.query(sqlStatusParado, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              //execute('sudo bash -x /usr/bin/dialer.sh stop', (stdout) => { });
              execute('sudo /etc/init.d/dialer stop', (stdout) => { });
              //execute('sudo dialer.sh stop', (stdout) => {
              //console.log("\nCallback stop: " + stdout);
              //});

              setTimeout(() => {
                console.log("\n\nDialer desativado!\nSistema de discagem parou!\n\n");
                res.status(200).send();
              }, 1000);
            }
          });
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  pausarCampanha: (req, res) => {
    //Recebendo o nome da campanha para ativa-la
    var nomeCampanha = req.body.campanhaVigente;
    var pausado = req.body.pausado;

    try {
      //Ativar a campanha atraves da tabela status
      var sqlAtivar = 'UPDATE status SET pausado = TRUE FROM campanha WHERE status_fk = status_id AND ativado = TRUE AND campanha_nome = ' + "'" + nomeCampanha + "';";

      pg.query(sqlAtivar, [], (err, ans) => {
        if (err) {
          console.log("\n\nError: " + err)
          return res.status(500).send({
            message: 'Erro interno, por favor contacte o administrador'
          });
        } else {
          console.log("\n\nDialer pausado!\nSistema de discagem aguardando para continuar!\n")
          //Variavel para controlar se está pausado ou não, controle mais simple do que tratar no banco
          statusPausado = pausado;
          res.status(200).send();
        }
      });
    } catch (error) {
      console.log("Error: " + error);
      return res.status(500).send({
        message: 'Erro interno, por favor contacte o administrador'
      });
    }
  },

  selectCampanhaAtiva: (req, res) => {
    //Saber se existe campanha ativada atraves do count
    var sqlCampanhaAtivada = 'SELECT COUNT(campanha_nome) FROM campanha, status WHERE status_fk = status_id AND ativado = TRUE;';

    pg.query(sqlCampanhaAtivada, [], (err, ans) => {
      if (err) {
        console.log("\n\nError: " + err)
        return res.status(500).send({
          message: 'Erro interno, por favor contacte o administrador'
        });
      } else {
        //Retorno da consulta
        var contador = ans.rows[0].count;
        console.log("Contador: " + contador)
        //Caso nada esteja ativado
        if (contador == 0) {
          res.status(200).send({
            message: 'Nenhuma campanha em execução.',
            contador: contador
          });

        } else if (contador == 1) {
          //Buscar por campanha ativada
          var sqlCampanhaAtivada = 'SELECT campanha_nome FROM campanha, status WHERE status_fk = status_id AND ativado = TRUE;';

          pg.query(sqlCampanhaAtivada, [], (err, ans) => {
            if (err) {
              console.log("\n\nError: " + err)
              return res.status(500).send({
                message: 'Erro interno, por favor contacte o administrador'
              });
            } else {
              //pegando o nome da campanha

              var nomeCampanhaAtivada = ans.rows[0].campanha_nome;

              res.status(200).send({
                message: 'Em execução: ' + nomeCampanhaAtivada,
                contador: contador,
                campanha: nomeCampanhaAtivada
              })
            }
          });
        }
      }
    });
  }

}

function execute(command, callback) {
  exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};
