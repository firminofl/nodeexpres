const pg = require('../db');

module.exports = {
  select: (req, res) => {
    pg.query('SELECT * FROM contato, cdr WHERE contato_id = contato_fk ORDER BY cdr_id', [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      dataInicioConsultaContato: req.body.dataInicioConsultaContatos,
      dataFimConsultaContato: req.body.dataFimConsultaContatos,

      horaInicioConsultaContato: req.body.horaInicioConsultaContatos,
      horaFimConsultaContato: req.body.horaFimConsultaContatos,

      nomePacienteContato: req.body.nomePacienteContatos,
      tel1PacienteContato: req.body.tel1PacienteContatos,
      tel2PacienteContato: req.body.tel2PacienteContatos,

      nomeMedicoContato: req.body.nomeMedicoContatos,

      statusChamadaContato: req.body.statusChamadaContatos,
      statusConsultaContato: req.body.statusConsultaContatos,

      tipoAtendimentoContato: req.body.tipoAtendimentoContatos,
      telDiscadoContato: req.body.telDiscadoContatos
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;
    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null){
      if (queryPesquisa == 'Data de início é maior que a atual.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      }else if (queryPesquisa == 'Data de início está vazia.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      }else if (queryPesquisa == 'Insira um período de data para busca.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      }else if (queryPesquisa == 'Hora de início de consulta é maior que a de fim.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de consulta é maior que a de fim.'
        });
      }else if (queryPesquisa == 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'
        });
      }else{
        var queryConsulta = 'SELECT * FROM cdr, contato '+ queryPesquisa +' AND contato_fk = contato_id ORDER BY cdr_id DESC LIMIT 10 OFFSET 0;';
      }
    } else {
      var queryConsulta = 'SELECT * FROM cdr, contato WHERE contato_fk = contato_id ' +
      ' ORDER BY cdr_id DESC LIMIT 10 OFFSET 0;';
    }

    //query de busca no postgres, montada previamente para reduzir seu tamanho
    pg.query(queryConsulta, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item){
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //*******************************consulta***************************************
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == ''){
      var horaInicio = item.horaInicioConsultaContato;

      var dateConverter = new Date(item.dataInicioConsultaContato);
      var dataHoraInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var date = new Date();
      var horaFim = ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());
      var dataHoraFim = ((date.getDate()<10?'0':'') + date.getDate())+ "/" + (date.getMonth()+1) + "/" +date.getFullYear() + " "+ horaFim;

      var inicio = new Date(item.dataInicioConsultaContato+" "+horaInicio).valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio + " "+ horaInicio+ "'"+ ' AND '+ "'"+dataHoraFim+"'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio + " "+ horaInicio+"'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Preenchido no inicio e fim da hora e na data somente o inicio)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == ''){
      var horaInicio = item.horaInicioConsultaContato;

      var dateConverter = new Date(item.dataInicioConsultaContato);
      var dataHoraInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var horaFim = item.dataFimConsultaContato

      var date = new Date();
      var dataHoraFim = ((date.getDate()<10?'0':'') + date.getDate())+ "/" + (date.getMonth()+1) + "/" +date.getFullYear();

      var inicio = new Date(item.dataInicioConsultaContato+" "+horaInicio).valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio + " "+ horaInicio+"'"+ ' AND '+ "'"+dataHoraFim + " "+ horaFim+"'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio + " "+ horaInicio +"'"+ ' AND '+ "'"+dataHoraFim + " "+ horaFim+"'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação consulta (tudo preenchido - data e hora)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato != ''){
      var horaInicio = item.horaInicioConsultaContato;

      var dateConverter = new Date(item.dataInicioConsultaContato);
      var dataHoraInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var horaFim = item.horaFimConsultaContato;

      var dateConverterFim = new Date(item.dataFimConsultaContato);
      var dataHoraFim = (((dateConverterFim.getDate()+1)<10?'0':'') + (dateConverterFim.getDate()+1))+ "/" + (dateConverterFim.getMonth()+1) + "/" +dateConverterFim.getFullYear();

      var dataHoraFimConversao = dateConverterFim.getFullYear()+ "-" + (dateConverterFim.getMonth()+1) + "-" + (((dateConverterFim.getDate()+1)<10?'0':'') + (dateConverterFim.getDate()+1));
      var inicio = new Date(item.dataInicioConsultaContato+" "+horaInicio).valueOf();
      var fim = new Date(dataHoraFimConversao+" "+horaFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio+" "+horaInicio+ "'"+ ' AND '+ "'" +dataHoraFim+" "+horaFim+ "'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'"+ dataHoraInicio +" "+horaInicio+ "'"+ ' AND '+ "'" +dataHoraFim+" "+horaFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação consulta (hora vazio e data preenchida)
  if (item.horaInicioConsultaContato == '' && item.horaFimConsultaContato == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato == ''){

      var dateConverter = new Date(item.dataInicioConsultaContato);
      var dataInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var date = new Date();
      var dataFim = ((date.getDate()<10?'0':'') +date.getDate()) + "/" + (date.getMonth()+1) + "/" + date.getFullYear() + " " +
      ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());

      var inicio = new Date(item.dataInicioConsultaContato+ " 00:00").valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'" +dataInicio+ " 00:00"+"'"+ ' AND '+ "'" +dataFim+ "'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'" +dataInicio+ " 00:00"+"'"+ ' AND '+ "'" +dataFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas.
    }else if (item.dataInicioConsultaContato != '' && item.dataFimConsultaContato != ''){
      var dateConverter = new Date(item.dataInicioConsultaContato);
      var dataInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var dateConverterFim = new Date(item.dataFimConsultaContato);
      var dataHoraFim = (((dateConverterFim.getDate()+1)<10?'0':'') + (dateConverterFim.getDate()+1))+ "/" + (dateConverterFim.getMonth()+1) + "/" +dateConverterFim.getFullYear();

      var inicio = new Date(item.dataInicioConsultaContato + " 00:00").valueOf();
      var fim = new Date(dateConverterFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'" +dataInicio + " 00:00"+ "'"+ ' AND '+ "'" +dataHoraFim + " 23:59"+"'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'" +dataInicio + " 00:00"+ "'"+ ' AND '+ "'" +dataHoraFim + " 23:59"+"'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    }else if (item.dataInicioConsultaContato == '' && item.dataFimConsultaContato != ''){
      return 'Data de início está vazia.';
    }
  }

  //Validação horario de discagem (hora preenchida e data vazia)
  if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato != ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioConsultaContato == '' && item.dataFimConsultaContato == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }else if (item.horaInicioConsultaContato != '' && item.horaFimConsultaContato == ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioConsultaContato == '' && item.dataFimConsultaContato == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }
  //**************************Fim data e hora de consulta **********************

  //Validação Paciente
  if (item.nomePacienteContato != ''){
    if (count > 0){
      query +=' AND contato_paciente_nome ILIKE '+ "'%" +item.nomePacienteContato+ "%'";
    }else{
      query +='contato_paciente_nome ILIKE '+ "'%" +item.nomePacienteContato+ "%'";
    }
    count++;
  }

  //Validação telfone 1
  if (item.tel1PacienteContato != ''){
    if (count > 0){
      query +=' AND contato_paciente_tel1 ILIKE '+ "'%" +item.tel1PacienteContato+ "%'";
    }else{
      query +='contato_paciente_tel1 ILIKE '+ "'%" +item.tel1PacienteContato+ "%'";
    }
    count++;
  }

  //Validação telfone 2
  if (item.tel2PacienteContato != ''){
    if (count > 0){
      query +=' AND contato_paciente_tel1 ILIKE '+ "'%" +item.tel2PacienteContato+ "%'";
    }else{
      query +='contato_paciente_tel2 ILIKE '+ "'%" +item.tel2PacienteContato+ "%'";
    }
    count++;
  }

  //Validação médico
  if (item.nomeMedicoContato != ''){
    if (count > 0){
      query +=' AND contato_medico_nome ILIKE '+ "'%" +item.nomeMedicoContato+ "%'";
    }else{
      query +='contato_medico_nome ILIKE '+ "'%" +item.nomeMedicoContato+ "%'";
    }
    count++;
  }

  //Validação Status chamada
  if (item.statusChamadaContato != ''){
    if (count > 0){
      query +=' AND cdr_status_chamada ILIKE '+ "'%" +item.statusChamadaContato+ "%'";
    }else{
      query +='cdr_status_chamada ILIKE '+ "'%" +item.statusChamadaContato+ "%'";
    }
    count++;
  }

  //Validação Status consulta
  if (item.statusConsultaContato != ''){
    if (count > 0){
      query +=' AND cdr_status_consulta ILIKE '+ "'%" +item.statusConsultaContato+ "%'";
    }else{
      query +='cdr_status_consulta ILIKE '+ "'%" +item.statusConsultaContato+ "%'";
    }
    count++;
  }

  //Validação Tipo Atendimento
  if (item.tipoAtendimentoContato != ''){
    if (count > 0){
      query +=' AND cdr_tipo ILIKE '+ "'%" +item.tipoAtendimentoContato+ "%'";
    }else{
      query +='cdr_tipo ILIKE '+ "'%" +item.tipoAtendimentoContato+ "%'";
    }
    count++;
  }

  //Validação Telefone Discado
  if (item.telDiscadoContato != ''){
    if (count > 0){
      query +=' AND cdr_tel_discado ILIKE '+ "'%" +item.telDiscadoContato+ "%'";
    }else{
      query +='cdr_tel_discado ILIKE '+ "'%" +item.telDiscadoContato+ "%'";
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}
