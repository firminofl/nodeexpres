var express = require('express');
var router = express.Router();
var audios_controller = require('../controller/audios');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

module.exports = router;
