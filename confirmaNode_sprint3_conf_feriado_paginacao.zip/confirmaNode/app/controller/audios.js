const pg = require('../db')

module.exports = {
  select: (req,res) => {

  }
}
