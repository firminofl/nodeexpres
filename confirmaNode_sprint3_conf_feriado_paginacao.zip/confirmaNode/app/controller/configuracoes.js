const pg = require('../db')

module.exports = {
  select: (req,res) => {
    var query = 'SELECT * FROM configuracao';

    pg.query(query, [], (err, ans) => {
      if (err){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      }else{
        res.json(ans.rows[0]);
      }
    });
  },

  update: (req,res) => {
    var tentativasDiscagem = req.body.tentativasDiscagem;
    var intervaloDiscagens = req.body.intervaloDiscagens;
    var chamadaSimultaneas = req.body.chamadaSimultaneas;
    var tomadaLinha = req.body.tomadaLinha;
    var antecedenciaFeriado = req.body.antecedenciaFeriado;
    var csp = req.body.csp;
    var amd = req.body.amd;

    var query = 'UPDATE configuracao SET conf_num_tentativa = '+tentativasDiscagem+', conf_intervalo_discagem = '+intervaloDiscagens+
    ', conf_chamadas_simultaneas = '+chamadaSimultaneas+', conf_dias_antes = '+antecedenciaFeriado+
    ', conf_cod_tomada_linha = '+tomadaLinha+', conf_csp = '+csp+', conf_amd = '+amd+' WHERE conf_id = 1';

    console.log("\n\nquery: "+query);

    pg.query(query, [], (err,ans) => {
      if (err){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      }else{
        res.json({
          message: 'Configurações atualizadas!'
        });
      }
    });
  }
}
