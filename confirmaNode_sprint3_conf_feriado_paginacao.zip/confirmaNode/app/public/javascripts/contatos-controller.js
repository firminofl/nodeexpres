function exportarCSV(){
  //Datas e horas referentes ao filtro
  var inputDataInicioConsultaContatos = $('#dataInicioConsultaContatos').val();
  var inputDataFimDiscConsultaContatos = $('#dataFimConsultaContatos').val();

  var inputHoraInicioConsultaContatos = $('#horaInicioConsultaContatos').val();
  var inputHoraFimConsultaContatos = $('#horaFimConsultaContatos').val();

  //paciente
  var inputNomePacienteContatos = $('#nomePacienteContatos').val();
  var inputTel1PacienteContatos = $('#tel1PacienteContatos').val();
  var inputTel2PacienteContatos = $('#tel2PacienteContatos').val();

  //medico
  var inputNomeMedicoContatos = $('#nomeMedicoContatos').val();

  //status
  var inputStatusChamadaContatos = $('#statusChamadaContatos').val();
  var inputStatusConsultaContatos = $('#statusConsultaContatos').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoContatos = $('#tipoAtendimentoContatos').val();
  var inputTelDiscadoContatos = $('#telDiscadoContatos').val();

  //Id consulta
  var inputIdConsultaContatos = $('#idConsultaContatos').val();

  //criando um objeto para passar como referencia na rota
  var object = {
    dataInicioConsultaContatos: inputDataInicioConsultaContatos,
    dataFimConsultaContatos: inputDataFimDiscConsultaContatos,

    horaInicioConsultaContatos: inputHoraInicioConsultaContatos,
    horaFimConsultaContatos: inputHoraFimConsultaContatos,

    nomePacienteContatos: inputNomePacienteContatos,
    tel1PacienteContatos: inputTel1PacienteContatos,
    tel2PacienteContatos: inputTel2PacienteContatos,

    nomeMedicoContatos: inputNomeMedicoContatos,

    statusChamadaContatos: inputStatusChamadaContatos,
    statusConsultaContatos: inputStatusConsultaContatos,

    tipoAtendimentoContatos: inputTipoAtendimentoContatos,
    telDiscadoContatos: inputTelDiscadoContatos,

    idConsultaContatos: inputIdConsultaContatos
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        montarExportarTabelaCSV(JSON.parse(this.response));
        alert("Arquivo CSV gerado com sucesso!");
        break;

        case 304:
        montarExportarTabelaCSV(JSON.parse(this.response));
        alert("Arquivo CSV gerado com sucesso!");
        break;

        case 500:
        alert(JSON.parse(this.response).message);
        break;

        default:
        alert('Erro inesperado, contate o administrador.');
        break;
      }
    }
  }
  xhttp.open('POST', '/contato/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function montarExportarTabelaCSV(rows){
  var csv = 'Data/Hora Consulta,Status Consulta,Paciente,Telefone 1,Telefone 2,'+
  'Status Chamada,Tel discado,Id consulta\n';

  for (var i = 0; i < rows.length; i++) {
    csv += rows[i].contato_consulta_data_hora;
    csv += ','+ rows[i].cdr_status_consulta;
    csv += ','+ rows[i].contato_paciente_nome;
    csv += ','+ rows[i].contato_paciente_tel1;
    csv += ','+ rows[i].contato_paciente_tel2;
    csv += ','+ rows[i].cdr_status_chamada;
    csv += ','+ rows[i].cdr_tel_discado;
    csv += ','+ rows[i].contato_consulta_id;
    csv += '\n';
  }

  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'contatos.csv';
  hiddenElement.click();
}

function atualizaContatos(){
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/contato/select')

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4){
      switch (this.status) {
        case 200:
        addContatosNaTabela(JSON.parse(this.response));
        break;
        case 304:
        addContatosNaTabela(JSON.parse(this.response));
        break;
        case 500:
        console.log("Erro interno com o servidor.");
        break;
        default:
        console.log("Erro inesperado, contate o administrador.");
        break;
      }
    }
  }

  xhttp.send();
}

function addContatosNaTabela(rows){
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaContatos tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //Data/Hora Consulta
    var consultaCell = newRow.insertCell(count);
    var consultaValue = document.createTextNode(rows[i].contato_consulta_data_hora);
    consultaCell.appendChild(consultaValue);
    count++;

    //Status consulta
    var statusConsultaCell = newRow.insertCell(count);
    var statusConsultaValue = document.createTextNode(rows[i].cdr_status_consulta);
    statusConsultaCell.appendChild(statusConsultaValue);
    count++;

    //Paciente
    var pacienteCell = newRow.insertCell(count);
    var pacienteValue = document.createTextNode(rows[i].contato_paciente_nome);
    pacienteCell.appendChild(pacienteValue);
    count++;

    //Telefone 1
    var tel1Cell = newRow.insertCell(count);
    var tel1Value = document.createTextNode(rows[i].contato_paciente_tel1);
    tel1Cell.appendChild(tel1Value);
    count++;

    //Telefone 2
    var tel2Cell = newRow.insertCell(count);
    var tel2Value = document.createTextNode(rows[i].contato_paciente_tel2);
    tel2Cell.appendChild(tel2Value);
    count++;

    //Status chamada
    var statusClienteCell = newRow.insertCell(count);
    var statusClienteValue = document.createTextNode(rows[i].cdr_status_chamada);
    statusClienteCell.appendChild(statusClienteValue);
    count++;

    //Telefone discado
    var telDiscadoCell = newRow.insertCell(count);
    var telDiscadoValue = document.createTextNode(rows[i].cdr_tel_discado);
    telDiscadoCell.appendChild(telDiscadoValue);
    count++;

    //Id consulta
    var idConsultaCell = newRow.insertCell(count);
    var idConsultaValue = document.createTextNode(rows[i].contato_consulta_id);
    idConsultaCell.appendChild(idConsultaValue);
    count++;
  }
}

function buscarContatos() {
  //Datas e horas referentes ao filtro
  var inputDataInicioConsultaContatos = $('#dataInicioConsultaContatos').val();
  var inputDataFimDiscConsultaContatos = $('#dataFimConsultaContatos').val();

  var inputHoraInicioConsultaContatos = $('#horaInicioConsultaContatos').val();
  var inputHoraFimConsultaContatos = $('#horaFimConsultaContatos').val();

  //paciente
  var inputNomePacienteContatos = $('#nomePacienteContatos').val();
  var inputTel1PacienteContatos = $('#tel1PacienteContatos').val();
  var inputTel2PacienteContatos = $('#tel2PacienteContatos').val();

  //medico
  var inputNomeMedicoContatos = $('#nomeMedicoContatos').val();

  //status
  var inputStatusChamadaContatos = $('#statusChamadaContatos').val();
  var inputStatusConsultaContatos = $('#statusConsultaContatos').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoContatos = $('#tipoAtendimentoContatos').val();
  var inputTelDiscadoContatos = $('#telDiscadoContatos').val();

  //Id consulta
  var inputIdConsultaContatos = $('#idConsultaContatos').val();

  var red_alert_modal = document.getElementById('red-alert_modal');

  red_alert_modal.style.visibility = 'none';

  //criando um objeto para passar como referencia na rota
  var object = {
    dataInicioConsultaContatos: inputDataInicioConsultaContatos,
    dataFimConsultaContatos: inputDataFimDiscConsultaContatos,

    horaInicioConsultaContatos: inputHoraInicioConsultaContatos,
    horaFimConsultaContatos: inputHoraFimConsultaContatos,

    nomePacienteContatos: inputNomePacienteContatos,
    tel1PacienteContatos: inputTel1PacienteContatos,
    tel2PacienteContatos: inputTel2PacienteContatos,

    nomeMedicoContatos: inputNomeMedicoContatos,

    statusChamadaContatos: inputStatusChamadaContatos,
    statusConsultaContatos: inputStatusConsultaContatos,

    tipoAtendimentoContatos: inputTipoAtendimentoContatos,
    telDiscadoContatos: inputTelDiscadoContatos,

    idConsultaContatos: inputIdConsultaContatos
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        addContatosNaTabela(JSON.parse(this.response));
        $('#dismiss-modal').trigger('click');
        break;

        case 304:
        addContatosNaTabela(JSON.parse(this.response));
        $('#dismiss-modal').trigger('click');
        break;

        case 500:
        redAlert(JSON.parse(this.response).message);
        break;

        default:
        redAlert('Erro inesperado, contate o administrador.');
        break;
      }
    }
  }
  xhttp.open('POST', '/contato/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function redAlert(message) {
  var success = document.getElementById('red-alert_modal');
  success.innerHTML = message
  success.classList.add('show');
  setTimeout(() => {
    success.classList.remove('show');
  }, 3000);
}

function limparCampos(){
  //Datas e horas referentes ao filtro
  $('#dataInicioConsultaContatos').val('');
  $('#dataFimConsultaContatos').val('');

  $('#horaInicioConsultaContatos').val('');
  $('#horaFimConsultaContatos').val('');

  //paciente
  $('#nomePacienteContatos').val('');
  $('#tel1PacienteContatos').val('');
  $('#tel2PacienteContatos').val('');

  //medico
  $('#nomeMedicoContatos').val('');

  //status
  $('#statusChamadaContatos').val('');
  $('#statusConsultaContatos').val('');

  //tipo de atendimento e telefone discado
  $('#tipoAtendimentoContatos').val('');
  $('#telDiscadoContatos').val('');

  //Id consulta
  $('#idConsultaContatos').val('');
  atualizaContatos();
}
