function carregaConfiguracoes() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/configuracao/select')

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        setaValores(JSON.parse(this.response))
        break;
        case 304:
        setaValores(JSON.parse(this.response))
        break;
        case 500:
        console.log("Erro interno com o servidor.");
        break;
        default:
        console.log("Erro inesperado, contate o administrador.");
        break;
      }
    }
  }

  xhttp.send()
}

function setaValores(item){
  $('#tentativasDiscagem').val(item.conf_num_tentativa);
  $('#intervaloDiscagens').val(item.conf_intervalo_discagem);
  $('#chamadaSimultaneas').val(item.conf_chamadas_simultaneas);
  $('#tomadaLinha').val(item.conf_cod_tomada_linha);
  $('#antecedenciaFeriado').val(item.conf_dias_antes);
  $('#csp').val(item.conf_csp);
  if (item.conf_amd.toString() == 'true'){
    document.getElementById('amd').checked = true;
  }else if (item.conf_amd.toString() == 'false'){
    document.getElementById('amd').checked = false;
  }
}

function validarConfiguracoes() {
  var tentativasDiscagem = $('#tentativasDiscagem').val();
  var intervaloDiscagens = $('#intervaloDiscagens').val();
  var chamadaSimultaneas = $('#chamadaSimultaneas').val();
  var tomadaLinha = $('#tomadaLinha').val();
  var antecedenciaFeriado = $('#antecedenciaFeriado').val();
  var csp = $('#csp').val();
  var amd;
  if ($('#amd').is(':checked')){
    amd = 'TRUE';
  }else{
    amd = 'FALSE';
  }

  var object = {
    tentativasDiscagem: tentativasDiscagem,
    intervaloDiscagens: intervaloDiscagens,
    chamadaSimultaneas: chamadaSimultaneas,
    tomadaLinha: tomadaLinha,
    antecedenciaFeriado: antecedenciaFeriado,
    csp: csp,
    amd: amd
  }

  if (tentativasDiscagem == '' || tentativasDiscagem > 9 || tentativasDiscagem < 1){
    alert('Campo de tentativas de discagem não está preenchido corretamente!');
    return false;
  }

  if (intervaloDiscagens == '' || intervaloDiscagens > 3 || intervaloDiscagens < 1){
    alert('Campo de intervalo de discagens não está preenchido corretamente!');
    return false;
  }

  if (chamadaSimultaneas == '' || chamadaSimultaneas > 8 || chamadaSimultaneas < 1){
    alert('Campo de chamadas simultâneas não está preenchido corretamente!');
    return false;
  }

  if (csp == '' || csp == null){
    alert('Campo CSP não está preenchido corretamente!');
    return false;
  }

  if (csp.length != 2){
    alert('Campo CSP não contém 2 dígitos obrigatoriamente!');
    return false;
  }

  if (antecedenciaFeriado == '' || antecedenciaFeriado > 7 || antecedenciaFeriado < 1){
    alert('Campo dias com antecedência de feriado não está preenchido corretamente!');
    return false;
  }

  if (tomadaLinha == '' || tomadaLinha == null){
    alert('Campo tomada de linha não está preenchido corretamente!');
    return false;
  }

  var red_alert = document.getElementById('red-alert');
  red_alert.style.visibility = 'none';

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        carregaConfiguracoes();
        sucessAlert(JSON.parse(this.response).message)
        break;

        case 304:
        carregaConfiguracoes();
        sucessAlert(JSON.parse(this.response).message)
        break;

        case 400:
        break;

        case 401:
        red_alert.innerHTML = 'Erro ao atualizar informações no sistema.';
        red_alert.classList.add('show')
        setTimeout(() => {
          red_alert.classList.remove('show')
        }, 2000)
        break;

        case 500:
        red_alert.innerHTML = 'Erro interno com o servidor.';
        red_alert.classList.add('show')
        setTimeout(() => {
          red_alert.classList.remove('show')
        }, 2000)
        break;

        case 404:
        red_alert.innerHTML = 'Não foi possível alcançar o servidor.';
        red_alert.classList.add('show')
        setTimeout(() => {
          red_alert.classList.remove('show')
        }, 2000)
        break;

        default:
        red_alert.innerHTML = 'Erro inesperado, contate o administrador.'
        red_alert.classList.add('show')
        setTimeout(() => {
          red_alert.classList.remove('show')
        }, 2000)
        break;
      }
    }
  }
  xhttp.open("POST", '/configuracao/update', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function sucessAlert(message) {
    var success = document.getElementById('success')
    success.innerHTML = message
    success.classList.add('show')
    setTimeout(() => {
      success.classList.remove('show')
      location.reload();
    }, 3000);
}
