const pg = require('../db');

module.exports = {
  select: (req, res) => {
    var query = 'SELECT COUNT(*) as resultado FROM cdr,contato WHERE contato_fk = contato_id';
    pg.query(query, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        var count = ans.rows[0];

        var pagination = req.body.pagination;
        if (pagination == null || pagination == 1){
          pagination = 0;
        }else if (pagination > 1){
          pagination = pagination*10 - 10;
        }

        var query = 'SELECT * FROM contato, cdr WHERE contato_id = contato_fk ORDER BY cdr_id DESC LIMIT 10 OFFSET '+pagination;
        pg.query(query, [], (err, ans) => {
          if (err) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Erro ao selecionar dados no servidor'
            });
          } else {
            var data = new Object()
            data.contador = count
            data.result = ans.rows
            res.json(data)
          }
        });
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      dataInicioDiscagemBilhete: req.body.dataInicioDiscagemBilhetes,
      dataFimDiscagemBilhete: req.body.dataFimDiscagemBilhetes,

      horaInicioDiscagemBilhete: req.body.horaInicioDiscagemBilhetes,
      horaFimDiscagemBilhete: req.body.horaFimDiscagemBilhetes,

      dataInicioConsultaBilhete: req.body.dataInicioConsultaBilhetes,
      dataFimConsultaBilhete: req.body.dataFimConsultaBilhetes,

      horaInicioConsultaBilhete: req.body.horaInicioConsultaBilhetes,
      horaFimConsultaBilhete: req.body.horaFimConsultaBilhetes,

      nomePacienteBilhete: req.body.nomePacienteBilhetes,
      tel1PacienteBilhete: req.body.tel1PacienteBilhetes,
      tel2PacienteBilhete: req.body.tel2PacienteBilhetes,

      nomeMedicoBilhete: req.body.nomeMedicoBilhetes,

      statusChamadaBilhete: req.body.statusChamadaBilhetes,
      statusConsultaBilhete: req.body.statusConsultaBilhetes,

      tipoAtendimentoBilhete: req.body.tipoAtendimentoBilhetes,
      telDiscadoBilhete: req.body.telDiscadoBilhetes,
      idConsultaBilhete: req.body.idConsultaBilhetes
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;
    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null){
      if (queryPesquisa == 'Data de início é maior que a atual.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      }else if (queryPesquisa == 'Data de início está vazia.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      }else if (queryPesquisa == 'Insira um período de data para busca.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      }else if (queryPesquisa == 'Hora de início de discagem é maior que a de fim.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de discagem é maior que a de fim.'
        });
      }else if (queryPesquisa == 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.'
        });
      }else{
        var queryConsulta = 'SELECT * FROM cdr, contato '+ queryPesquisa +' AND contato_fk = contato_id ORDER BY cdr_id DESC LIMIT 20 OFFSET 0;';
      }
    } else {
      var queryConsulta = 'SELECT * FROM cdr, contato WHERE contato_fk = contato_id ' +
      ' ORDER BY cdr_id DESC LIMIT 20 OFFSET 0;';
    }
    //query de busca no postgres, montada previamente para reduzir seu tamanho
    pg.query(queryConsulta, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item){
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //**********************************discagem**********************************
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
      var horaInicio = item.horaInicioDiscagemBilhete;
      var dataHoraInicio = item.dataInicioDiscagemBilhete+ " "+horaInicio;

      var date = new Date();
      var horaFim = ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());
      var dataHoraFim = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + ((date.getDate()<10?'0':'') + date.getDate())+ " "+ horaFim;

      var inicio = new Date(dataHoraInicio).valueOf();
      var fim = new Date(dataHoraFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'"+dataHoraInicio+ "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ dataHoraInicio + "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (preenchido no inicio da hora e data)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
      var horaInicio = item.horaInicioDiscagemBilhete;
      var dataHoraInicio = item.dataInicioDiscagemBilhete+ " "+horaInicio;

      var date = new Date();
      var horaFim = item.horaFimDiscagemBilhete
      var dataHoraFim = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + ((date.getDate()<10?'0':'') + date.getDate())+ " "+ horaFim;

      var inicio = new Date(dataHoraInicio).valueOf();
      var fim = new Date(dataHoraFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'"+dataHoraInicio+ "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ dataHoraInicio + "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (tudo preenchido - data e hora)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
      var horaInicio = item.horaInicioDiscagemBilhete;
      var dataHoraInicio = item.dataInicioDiscagemBilhete+ " "+horaInicio;

      var date = new Date();
      var horaFim = item.horaFimDiscagemBilhete
      var dataHoraFim = item.dataFimDiscagemBilhete+ " "+ horaFim;

      var inicio = new Date(dataHoraInicio).valueOf();
      var fim = new Date(dataHoraFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'"+dataHoraInicio+ "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ dataHoraInicio + "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação discagem (hora vazio e data preenchida)
  if (item.horaInicioDiscagemBilhete == '' && item.horaFimDiscagemBilhete == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){

      var date = new Date();
      var dataFimDiscagemBilhete = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + ((date.getDate()<10?'0':'') +date.getDate()) + " " +
      date.getHours() + ":" + date.getMinutes();

      var inicio = new Date(item.dataInicioDiscagemBilhete + " 00:00").valueOf();
      var fim = new Date(dataFimDiscagemBilhete).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'" +item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'" +item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas.
    }else if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
      var inicio = new Date(item.dataInicioDiscagemBilhete + " 00:00").valueOf();
      var fim = new Date(item.dataFimDiscagemBilhete + " 23:59").valueOf();

      if (inicio < fim){dataHoraInicio
        if (count > 0){
          query += ' AND cdr_data_hora_chamada BETWEEN '+ "'" +item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete + " 23:59"+ "'";
        }else{
          query += 'cdr_data_hora_chamada BETWEEN '+ "'" +item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete + " 23:59"+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    }else if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete != ''){
      return 'Data de início está vazia.';
    }
  }

  //Validação horario de discagem (hora preenchida e data vazia)
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }else if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete == ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }
  //****************************Fim data e hora de discagem***********************

  //*******************************consulta***************************************
  if (item.horaInicioConsultaBilhete != '' && item.horaFimConsultaBilhete == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete == ''){
      var horaInicio = item.horaInicioConsultaBilhete;

      var dateConverter = new Date(item.dataInicioConsultaBilhete);
      var dataHoraInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear() + " "+ horaInicio;

      var date = new Date();
      var horaFim = ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());
      var dataHoraFim = ((date.getDate()<10?'0':'') + date.getDate())+ "/" + (date.getMonth()+1) + "/" +date.getFullYear() + " "+ horaFim;

      var inicio = new Date(item.dataInicioConsultaBilhete+" "+horaInicio).valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio+ "'"+ ' AND '+ "'"+dataHoraFim+"'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio+"'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Preenchido no inicio e fim da hora e na data somente o inicio)
  if (item.horaInicioConsultaBilhete != '' && item.horaFimConsultaBilhete != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete == ''){
      var horaInicio = item.horaInicioConsultaBilhete;

      var dateConverter = new Date(item.dataInicioConsultaBilhete);
      var dataHoraInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear() + " "+ horaInicio;

      var horaFim = item.horaFimConsultaBilhete

      var date = new Date();
      var dataHoraFim = ((date.getDate()<10?'0':'') + date.getDate())+ "/" + (date.getMonth()+1) + "/" +date.getFullYear() + " "+ horaFim;

      var inicio = new Date(item.dataInicioConsultaBilhete+" "+horaInicio).valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio+"'"+ ' AND '+ "'"+dataHoraFim+"'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio +"'"+ ' AND '+ "'"+dataHoraFim+"'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação consulta (tudo preenchido - data e hora)
  if (item.horaInicioConsultaBilhete != '' && item.horaFimConsultaBilhete != ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete != ''){
      var horaInicio = item.horaInicioConsultaBilhete;

      var dateConverter = new Date(item.dataInicioConsultaBilhete);
      var dataHoraInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear() + " "+horaInicio;

      var horaFim = item.horaFimConsultaBilhete

      var dateConverterFim = new Date(item.dataFimConsultaBilhete);
      var dataHoraFim = (((dateConverterFim.getDate()+1)<10?'0':'') + (dateConverterFim.getDate()+1))+ "/" + (dateConverterFim.getMonth()+1) + "/" +dateConverterFim.getFullYear() + " "+horaFim;

      var dataHoraFimConversao = dateConverterFim.getFullYear()+ "-" + (dateConverterFim.getMonth()+1) + "-" + (((dateConverterFim.getDate()+1)<10?'0':'') + (dateConverterFim.getDate()+1));
      var inicio = new Date(item.dataInicioConsultaBilhete+" "+horaInicio).valueOf();
      var fim = new Date(dataHoraFimConversao+" "+horaFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'"+dataHoraInicio+ "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'"+ dataHoraInicio + "'"+ ' AND '+ "'" +dataHoraFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
    }
  }

  //Validação consulta (hora vazio e data preenchida)
  if (item.horaInicioConsultaBilhete == '' && item.horaFimConsultaBilhete == ''){
    //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
    if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete == ''){

      var dateConverter = new Date(item.dataInicioConsultaBilhete);
      var dataInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var date = new Date();
      var dataFim = ((date.getDate()<10?'0':'') +date.getDate()) + "/" + (date.getMonth()+1) + "/" + date.getFullYear() + " " +
      ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());

      var inicio = new Date(item.dataInicioConsultaBilhete+ " 00:00").valueOf();
      var fim = new Date(date).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'" +dataInicio+ " 00:00"+"'"+ ' AND '+ "'" +dataFim+ "'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'" +dataInicio+ " 00:00"+"'"+ ' AND '+ "'" +dataFim+ "'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início e fim estão preenchidas.
    }else if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete != ''){
      var dateConverter = new Date(item.dataInicioConsultaBilhete);
      var dataInicio = (((dateConverter.getDate()+1)<10?'0':'') + (dateConverter.getDate()+1))+ "/" + (dateConverter.getMonth()+1) + "/" +dateConverter.getFullYear();

      var dateConverterFim = new Date(item.dataFimConsultaBilhete);
      var dataHoraFim = (((dateConverterFim.getDate()+1)<10?'0':'') + (dateConverterFim.getDate()+1))+ "/" + (dateConverterFim.getMonth()+1) + "/" +dateConverterFim.getFullYear();

      var inicio = new Date(item.dataInicioConsultaBilhete + " 00:00").valueOf();
      var fim = new Date(dateConverterFim).valueOf();

      if (inicio < fim){
        if (count > 0){
          query += ' AND contato_consulta_data_hora BETWEEN '+ "'" +dataInicio + " 00:00"+ "'"+ ' AND '+ "'" +dataHoraFim + " 23:59"+"'";
        }else{
          query += 'contato_consulta_data_hora BETWEEN '+ "'" +dataInicio + " 00:00"+ "'"+ ' AND '+ "'" +dataHoraFim + " 23:59"+"'";
        }
        count++;
      }else{
        return 'Data de início é maior que a atual.';
      }
      //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
    }else if (item.dataInicioConsultaBilhete == '' && item.dataFimConsultaBilhete != ''){
      return 'Data de início está vazia.';
    }
  }

  //Validação horario de discagem (hora preenchida e data vazia)
  if (item.horaInicioConsultaBilhete != '' && item.horaFimConsultaBilhete != ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioConsultaBilhete == '' && item.dataFimConsultaBilhete == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }else if (item.horaInicioConsultaBilhete != '' && item.horaFimConsultaBilhete == ''){
    //Data de início e fim não está preenchida
    if (item.dataInicioConsultaBilhete == '' && item.dataFimConsultaBilhete == ''){
      return 'Para pesquisar por horário é necessário inserir pelo menos uma data de início.';
    }
  }
  //********Fim data e hora de consulta de bilhete******************************

  //Validação Paciente
  if (item.nomePacienteBilhete != ''){
    if (count > 0){
      query +=' AND contato_paciente_nome ILIKE '+ "'%" +item.nomePacienteBilhete+ "%'";
    }else{
      query +='contato_paciente_nome ILIKE '+ "'%" +item.nomePacienteBilhete+ "%'";
    }
    count++;
  }

  //Validação telfone 1
  if (item.tel1PacienteBilhete != ''){
    if (count > 0){
      query +=' AND contato_paciente_tel1 ILIKE '+ "'%" +item.tel1PacienteBilhete+ "%'";
    }else{
      query +='contato_paciente_tel1 ILIKE '+ "'%" +item.tel1PacienteBilhete+ "%'";
    }
    count++;
  }

  //Validação telfone 2
  if (item.tel2PacienteBilhete != ''){
    if (count > 0){
      query +=' AND contato_paciente_tel1 ILIKE '+ "'%" +item.tel2PacienteBilhete+ "%'";
    }else{
      query +='contato_paciente_tel2 ILIKE '+ "'%" +item.tel2PacienteBilhete+ "%'";
    }
    count++;
  }

  //Validação médico
  if (item.nomeMedicoBilhete != ''){
    if (count > 0){
      query +=' AND contato_medico_nome ILIKE '+ "'%" +item.nomeMedicoBilhete+ "%'";
    }else{
      query +='contato_medico_nome ILIKE '+ "'%" +item.nomeMedicoBilhete+ "%'";
    }
    count++;
  }

  //Validação Status chamada
  if (item.statusChamadaBilhete != ''){
    if (count > 0){
      query +=' AND cdr_status_chamada ILIKE '+ "'%" +item.statusChamadaBilhete+ "%'";
    }else{
      query +='cdr_status_chamada ILIKE '+ "'%" +item.statusChamadaBilhete+ "%'";
    }
    count++;
  }

  //Validação Status consulta
  if (item.statusConsultaBilhete != ''){
    if (count > 0){
      query +=' AND cdr_status_consulta ILIKE '+ "'%" +item.statusConsultaBilhete+ "%'";
    }else{
      query +='cdr_status_consulta ILIKE '+ "'%" +item.statusConsultaBilhete+ "%'";
    }
    count++;
  }

  //Validação Tipo Atendimento
  if (item.tipoAtendimentoBilhete != ''){
    if (count > 0){
      query +=' AND cdr_tipo ILIKE '+ "'%" +item.tipoAtendimentoBilhete+ "%'";
    }else{
      query +='cdr_tipo ILIKE '+ "'%" +item.tipoAtendimentoBilhete+ "%'";
    }
    count++;
  }

  //Validação Telefone Discado
  if (item.telDiscadoBilhete != ''){
    if (count > 0){
      query +=' AND cdr_tel_discado ILIKE '+ "'%" +item.telDiscadoBilhete+ "%'";
    }else{
      query +='cdr_tel_discado ILIKE '+ "'%" +item.telDiscadoBilhete+ "%'";
    }
    count++;
  }

  //Validação Id consulta
  if (item.idConsultaBilhete != ''){
    if (count > 0){
      query +=' AND contato_consulta_id = '+ "'" +item.idConsultaBilhete+ "'";
    }else{
      query +='contato_consulta_id = '+ "'" +item.idConsultaBilhete+ "'";
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}
