function setAudioName(element) {
  var div = element.parentElement;
  var childs = div.childNodes;

  var label = undefined;

  for (var i = 0; i < childs.length; i++) {
    if (childs[i].nodeName === 'LABEL') {
      label = childs[i];
      break;
    }
  }

  if (element.files[0] === undefined) {
    return label.innerHTML = 'Não selecionado';
  }

  var file = element.files[0];

  if (element.files[0].name.split('.')[0].length > 15) {
    alert('Nome do arquivo não deve passar de 15 caracteres');
    label.innerHTML = 'Não selecionado';
    element.value = '';
    return;
  }

  if (label && file && (file.type.includes('gsm') ||
  file.type.includes('wav') ||
  file.type.includes('mp3'))) {

    label.innerHTML = element.files[0].name;

  } else {
    alert('Por favor, selecione apenas arquivos de áudios ' +
    'com o formato de gsm, mp3 ou wav.');
    label.innerHTML = 'Não selecionado';
    element.value = '';
  }
}

function validarAudios() {
  var audioInforma = $('#audioInforma');
  var audioConfirma = $('#audioConfirma');
  var audioTentativas = $('#audioTentativas');
  var audioAgradece = $('#audioAgradece');
  var audioNovamente = $('#audioNovamente');
  var audioInvalida = $('#audioInvalida');
  var audioConfirmada = $('#audioConfirmada');
  var audioAgradecePart = $('#audioAgradecePart');
  var audioCancelada = $('#audioCancelada');
  var audioReagendar = $('#audioReagendar');
  var audioAlo = $('#audioAlo');

  var formData = new FormData();

  if (audioInforma.get(0).files[0]) {
    formData.append('audios', audioInforma.get(0).files[0], audioInforma.get(0).files[0].name);
    formData.append(audioInforma.get(0).files[0].name, 'audio_informa');
  }

  if (audioConfirma.get(0).files[0]) {
    formData.append('audios', audioConfirma.get(0).files[0], audioConfirma.get(0).files[0].name);
    formData.append(audioConfirma.get(0).files[0].name, 'audio_confirma');
  }

  if (audioTentativas.get(0).files[0]) {
    formData.append('audios', audioTentativas.get(0).files[0], audioTentativas.get(0).files[0].name);
    formData.append(audioTentativas.get(0).files[0].name, 'audio_tentativas');
  }

  if (audioAgradece.get(0).files[0]) {
    formData.append('audios', audioAgradece.get(0).files[0], audioAgradece.get(0).files[0].name);
    formData.append(audioAgradece.get(0).files[0].name, 'audio_agradece');
  }

  if (audioNovamente.get(0).files[0]) {
    formData.append('audios', audioNovamente.get(0).files[0], audioNovamente.get(0).files[0].name);
    formData.append(audioNovamente.get(0).files[0].name, 'audio_novamente');
  }

  if (audioInvalida.get(0).files[0]) {
    formData.append('audios', audioInvalida.get(0).files[0], audioInvalida.get(0).files[0].name);
    formData.append(audioInvalida.get(0).files[0].name, 'audio_invalida');
  }

  if (audioConfirmada.get(0).files[0]) {
    formData.append('audios', audioConfirmada.get(0).files[0], audioConfirmada.get(0).files[0].name);
    formData.append(audioConfirmada.get(0).files[0].name, 'audio_confirmada');
  }

  if (audioAgradecePart.get(0).files[0]) {
    formData.append('audios', audioAgradecePart.get(0).files[0], audioAgradecePart.get(0).files[0].name);
    formData.append(audioAgradecePart.get(0).files[0].name, 'audio_agradece_part');
  }

  if (audioCancelada.get(0).files[0]) {
    formData.append('audios', audioCancelada.get(0).files[0], audioCancelada.get(0).files[0].name);
    formData.append(audioCancelada.get(0).files[0].name, 'audio_cancelada');
  }

  if (audioReagendar.get(0).files[0]) {
    formData.append('audios', audioReagendar.get(0).files[0], audioReagendar.get(0).files[0].name);
    formData.append(audioReagendar.get(0).files[0].name, 'audio_reagendar');
  }

  if (audioAlo.get(0).files[0]) {
    formData.append('audios', audioAlo.get(0).files[0], audioAlo.get(0).files[0].name);
    formData.append(audioAlo.get(0).files[0].name, 'audio_alo');
  }

  var xhttp = new XMLHttpRequest()

  xhttp.open('POST', '/audio/insert', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      carregarAudios();
      alert(JSON.parse(this.response).message);
    } else if (this.readyState == 4 && this.status != 200) {
      carregarAudios();
      alert(JSON.parse(this.response).message);
    }
  }
  xhttp.send(formData);
}

function carregarAudios() {
  var xhttp = new XMLHttpRequest()

  xhttp.open('GET', '/audio/select', true);

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      if (this.response) {
        setLabelsName(JSON.parse(this.response)[0]);
      }
    }
  };
  xhttp.send();
}

function setLabelsName(items) {
  var labels = document.getElementsByClassName('custom-file-label')
  labels[0].innerHTML = items.audio_informa;
  labels[1].innerHTML = items.audio_confirma;
  labels[2].innerHTML = items.audio_tentativas;
  labels[3].innerHTML = items.audio_agradece;
  labels[4].innerHTML = items.audio_novamente;
  labels[5].innerHTML = items.audio_invalida;
  labels[6].innerHTML = items.audio_confirmada;
  labels[7].innerHTML = items.audio_agradece_part;
  labels[8].innerHTML = items.audio_cancelada;
  labels[9].innerHTML = items.audio_reagendar;
  labels[10].innerHTML = items.audio_alo;
}
