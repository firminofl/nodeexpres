var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate')

//Rota padrão criada pelo express para inicialização da aplicação
router.get('/', authenticate.auth, function(req, res) {
  res.render('index');
});

//Verifica se o usuario fez login, em caso afirmativo: entra na pag principal, senão fica em login
router.get('/login', function(req, res) {
  if (req.session.userid) {
    res.redirect('index')
  } else {
    res.render('login');
  }
});

//Abrir tela de cadastro e listagem de usuarios
router.get('/usuario', authenticate.auth, function(req, res) {
  res.render('usuario');
});

//Abrir tela de bilhetes (discagens)
router.get('/bilhetes', authenticate.auth, function(req, res) {
  res.render('bilhetes');
});

//Abrir tela de contatos
router.get('/contatos', authenticate.auth, function(req, res) {
  res.render('contatos');
});

module.exports = router;
