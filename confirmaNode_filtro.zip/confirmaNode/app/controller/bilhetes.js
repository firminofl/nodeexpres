const pg = require('../db');

module.exports = {
  select: (req, res) => {
    pg.query('SELECT * FROM contato, cdr WHERE contato_id = contato_fk ORDER BY cdr_id', [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  },

  search: (req, res) => {
    //Pegando referencia do objeto vindo do Front-end
    var object = {
      dataInicioDiscagemBilhete: req.body.dataInicioDiscagemBilhetes,
      dataFimDiscagemBilhete: req.body.dataFimDiscagemBilhetes,

      horaInicioDiscagemBilhete: req.body.horaInicioDiscagemBilhetes,
      horaFimDiscagemBilhete: req.body.horaFimDiscagemBilhetes,

      dataInicioConsultaBilhete: req.body.dataInicioConsultaBilhetes,
      dataFimConsultaBilhete: req.body.dataFimConsultaBilhetes,

      horaInicioConsultaBilhete: req.body.horaInicioConsultaBilhetes,
      horaFimConsultaBilhete: req.body.horaFimConsultaBilhetes,

      nomePacienteBilhete: req.body.nomePacienteBilhetes,
      tel1PacienteBilhete: req.body.tel1PacienteBilhetes,
      tel2PacienteBilhete: req.body.tel2PacienteBilhetes,

      nomeMedicoBilhete: req.body.nomeMedicoBilhetes,

      statusChamadaBilhete: req.body.statusChamadaBilhetes,
      statusConsultaBilhete: req.body.statusConsultaBilhetes,

      tipoAtendimentoBilhete: req.body.tipoAtendimentoBilhetes,
      telDiscadoBilhete: req.body.telDiscadoBilhetes
    }
    //Variavel para validar a query de busca e também se existe alguma exceção
    var queryPesquisa = null;
    queryPesquisa = queryBuilder(object);

    if (queryPesquisa != null){
      if (queryPesquisa == 'Data de início é maior que a atual.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início é maior que a atual.'
        });
      }else if (queryPesquisa == 'Data de início está vazia.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Data de início está vazia.'
        });
      }else if (queryPesquisa == 'Insira um período de data para busca.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Insira um período de data para busca.'
        });
      }else if (queryPesquisa == 'Hora de início de discagem é maior que a de fim.'){
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Hora de início de discagem é maior que a de fim.'
        });
      }else{
        var queryConsulta = 'SELECT * FROM cdr,contato '+ queryPesquisa +' ORDER BY cdr_id DESC LIMIT 10 OFFSET 0;';
      }
    } else {
      var queryConsulta = 'SELECT * FROM cdr,contato WHERE contato_fk = contato_id ' +
      ' ORDER BY cdr_id DESC LIMIT 10 OFFSET 0;';
    }
    //query de busca no postgres, montada previamente para reduzir seu tamanho
    console.log("\n\nQuery real: "+queryConsulta+"\n\n")
    pg.query(queryConsulta, [], (err, ans) => {
      if (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao selecionar dados no servidor'
        });
      } else {
        res.json(ans.rows)
      }
    });
  }
}

//metodo para descobrir quais campos estão preenchidos e montar a query
function queryBuilder(item){
  var query = null;
  query = 'WHERE ';
  var count = 0;

  //Validação data de discagem
  //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
  if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){

    var date = new Date();
    var dataFimDiscagemBilhete = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate() + " " +
    date.getHours() + ":" + date.getMinutes();

    var inicio = new Date(item.dataInicioDiscagemBilhete + " 00:00").valueOf();
    var fim = new Date(dataFimDiscagemBilhete).valueOf();

    if (inicio <= fim){
      if (count > 0){
        query += ' AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
      }else{
        query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'" +' AND contato_fk = contato_id';
      }
      count++;
    }else{
      return 'Data de início é maior que a atual.';
    }
    //Data de início e fim estão preenchidas.
  }else if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
    var inicio = new Date(item.dataInicioDiscagemBilhete + " 00:00").valueOf();
    var fim = new Date(item.dataFimDiscagemBilhete + " 23:59").valueOf();

    if (inicio <= fim){
      if (count > 0){
        query += ' AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete + " 23:59"+ "'";
      }else{
        query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete + " 00:00" + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete + " 23:59"+ "'"+ ' AND contato_fk = contato_id';
      }
      count++;
    }else{
      return 'Data de início é maior que a atual.';
    }
    //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
  }else if (item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete != ''){
    return 'Data de início está vazia.';
  }

  //Validação horario de discagem
  if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete == ''){
    var horaInicio = item.horaInicioDiscagemBilhete;

    var date = new Date();
    var horaFim = ((date.getHours()<10?'0':'') + date.getHours()) + ":" + ((date.getMinutes()<10?'0':'') + date.getMinutes());

    console.log("HOras: preenchido e vaziO: "+ horaInicio+" - "+horaFim)

    if (horaInicio <= horaFim){
      if ((item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete == '')){
        return 'Insira um período de data válido para busca.';
      }else{
        //Data preenchida no inicio e fim
        if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
          var inicio = new Date(item.dataInicioDiscagemBilhete +" "+horaInicio).valueOf();
          var fim = new Date(item.dataFimDiscagemBilhete +" "+horaFim).valueOf();

          console.log("DATA1: "+item.dataInicioDiscagemBilhete +" "+horaInicio+" - "+item.dataFimDiscagemBilhete +" "+horaFim)
          console.log("QUery na 1: "+query);
          if (inicio <= fim){
            if (count > 0){
              query += ' AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete+" "+horaInicio + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete +" "+horaFim+ "'";
            }else{
              query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete+" "+horaInicio + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete +" "+horaFim+ "'"+ ' AND contato_fk = contato_id';
            }
            count++;
          }else{
            return 'Data de início é maior que a atual.';
          }
          //Data preenchida somente no início
        }else if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
          var date = new Date();
          var dataFimDiscagemBilhete = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate() + " " +
          horaFim;

          var inicio = new Date(item.dataInicioDiscagemBilhete +" "+horaInicio).valueOf();
          var fim = new Date(dataFimDiscagemBilhete).valueOf();
          console.log("DATA2: "+item.dataInicioDiscagemBilhete +" "+horaInicio+" - "+dataFimDiscagemBilhete)
          console.log("QUery: "+'AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'")
          console.log("Query 2: "+'cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'" +' AND contato_fk = contato_id')
          if (inicio <= fim){
            if (count > 0){
              query += ' AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
            }else{
              query += 'cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'" +' AND contato_fk = contato_id';
            }
            count++;
          }else{
            return 'Data de início é maior que a atual.';
          }
        }
      }
    }else{
      return 'Hora de início de discagem é maior que a de fim.';
    }

  }else if (item.horaInicioDiscagemBilhete != '' && item.horaFimDiscagemBilhete != ''){
    var horaInicio = item.horaInicioDiscagemBilhete;
    var horaFim = item.horaFimDiscagemBilhete;
    console.log("HOras: preenchido e preenchido: "+ horaInicio+" - "+horaFim)
    if (horaInicio <= horaFim){
      if ((item.dataInicioDiscagemBilhete == '' && item.dataFimDiscagemBilhete == '')){
        return 'Insira um período de data válido para busca.';
      }else{
        //Data preenchida no inicio e fim
        if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete != ''){
          var inicio = new Date(item.dataInicioDiscagemBilhete +" "+horaInicio).valueOf();
          var fim = new Date(item.dataFimDiscagemBilhete +" "+horaFim).valueOf();

          console.log("DATA1: "+item.dataInicioDiscagemBilhete +" "+horaInicio+" - "+item.dataFimDiscagemBilhete +" "+horaFim)
          console.log("QUery na 1: "+'AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete+" "+horaInicio + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete +" "+horaFim+ "'");
          if (inicio <= fim){
            if (count > 0){
              query += ' AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete+" "+horaInicio + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete +" "+horaFim+ "'";
            }else{
              query += 'cdr_data_hora_chamada BETWEEN '+ "'"+ item.dataInicioDiscagemBilhete+" "+horaInicio + "'"+ ' AND '+ "'" +item.dataFimDiscagemBilhete +" "+horaFim+ "'"+ ' AND contato_fk = contato_id';
            }
            count++;
          }else{
            return 'Data de início é maior que a atual.';
          }
          //Data preenchida somente no início
        }else if (item.dataInicioDiscagemBilhete != '' && item.dataFimDiscagemBilhete == ''){
          var date = new Date();
          var dataFimDiscagemBilhete = date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate() + " " +
          horaFim;

          var inicio = new Date(item.dataInicioDiscagemBilhete +" "+horaInicio).valueOf();
          var fim = new Date(dataFimDiscagemBilhete).valueOf();
          console.log("DATA2: "+item.dataInicioDiscagemBilhete +" "+horaInicio+" - "+dataFimDiscagemBilhete)
          console.log("QUery: "+'AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'")
          console.log("Query 2: "+'cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'" +' AND contato_fk = contato_id')
          if (inicio <= fim){
            if (count > 0){
              query += ' AND contato_fk = contato_id AND cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'";
            }else{
              query += 'cdr_data_hora_chamada BETWEEN '+ "'"+item.dataInicioDiscagemBilhete +" "+horaInicio+"'"+ ' AND '+ "'" +dataFimDiscagemBilhete+ "'" +' AND contato_fk = contato_id';
            }
            count++;
          }else{
            return 'Data de início é maior que a atual.';
          }
        }
      }
    }else{
      return 'Hora de início de discagem é maior que a de fim.';
    }
  }

  //Validação data de consulta
  //Data de início está preenchida, mas a final não. (Sistema preenche automaticamente)
  if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete == ''){
    item.dataInicioConsultaBilhete += " 00:00";

    var date = new Date();
    var dataFimConsultaBilhete = date.getDate() + "/" + (date.getMonth()+1) + "/" + date.getFullYear() + " " +
    date.getHours() + ":" + date.getMinutes();

    var dataInicioConsultaBilhete = item.dataInicioConsultaBilhete.getDate() + "/" + item.dataInicioConsultaBilhete.getMonth() + "/" + item.dataInicioConsultaBilhete.getFullYear() + " 00:00";

    console.log("Inicío: "+ dataInicioConsultaBilhete+ "\nFim: "+dataFimConsultaBilhete);

    var inicio = new Date(dataInicioConsultaBilhete).valueOf();
    var fim = new Date(dataFimConsultaBilhete).valueOf();

    if (inicio <= fim){
      if (count > 0){
        query += ' AND contato_fk = contato_id AND contato_consulta_data_hora BETWEEN '+ "'"+ item.dataInicioConsultaBilhete + "'"+ ' AND '+ "'" +dataFimConsultaBilhete+ "'";
      }else{
        query += 'contato_consulta_data_hora BETWEEN '+ "'"+ item.dataInicioConsultaBilhete + "'"+ ' AND '+ "'" +dataFimConsultaBilhete+ "'" +' AND contato_fk = contato_id';
      }
      count++;
    }else{
      return 'Data de início é maior que a atual.';
    }
    //Data de início e fim estão preenchidas.
  }else if (item.dataInicioConsultaBilhete != '' && item.dataFimConsultaBilhete != ''){

    var dataInicioConsultaBilhete = item.dataInicioConsultaBilhete.getDate() + "/" + item.dataInicioConsultaBilhete.getMonth() + "/" + item.dataInicioConsultaBilhete.getFullYear() + " 00:00";
    var dataFimConsultaBilhete = item.dataFimConsultaBilhete.getDate() + "/" + item.dataFimConsultaBilhete.getMonth() + "/" + item.dataFimConsultaBilhete.getFullYear() + " 23:59";
    console.log("Inicío: "+ dataInicioConsultaBilhete+ "\nFim: "+dataFimConsultaBilhete);

    var inicio = new Date(item.dataInicioConsultaBilhete).valueOf();
    var fim = new Date(item.dataFimConsultaBilhete).valueOf();

    if (inicio <= fim){
      if (count > 0){
        query += ' AND contato_fk = contato_id AND contato_consulta_data_hora BETWEEN '+ "'"+ item.dataInicioConsultaBilhete + "'"+ ' AND '+ "'" +item.dataFimConsultaBilhete+ "'";
      }else{
        query += 'contato_consulta_data_hora BETWEEN '+ "'"+ item.dataInicioConsultaBilhete + "'"+ ' AND '+ "'" +item.dataFimConsultaBilhete+ "'"+ ' AND contato_fk = contato_id';
      }
      count++;
    }else{
      return 'Data de início é maior que a atual.';
    }
    //Data de início está vazia e a final está preenchida. (Sistema alerta que está faltando no início)
  }else if (item.dataInicioConsultaBilhete == '' && item.dataFimConsultaBilhete != ''){
    return 'Data de início está vazia.';
  }

  //Validação Paciente
  if (item.nomePacienteBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND contato_paciente_nome LIKE '+ "'%"+ item.nomePacienteBilhete+ "%'";
    }else{
      query +=' contato_paciente_nome LIKE '+ "'%"+ item.nomePacienteBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação telfone 1
  if (item.tel1PacienteBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND contato_paciente_tel1 LIKE '+ "'%"+ item.tel1PacienteBilhete+ "%'";
    }else{
      query +=' contato_paciente_tel1 LIKE '+ "'%"+ item.tel1PacienteBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação telfone 2
  if (item.tel2PacienteBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND contato_paciente_tel1 LIKE '+ "'%"+ item.tel2PacienteBilhete+ "%'";
    }else{
      query +=' contato_paciente_tel2 LIKE '+ "'%"+ item.tel2PacienteBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação médico
  if (item.nomeMedicoBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND contato_medico_nome LIKE '+ "'%"+ item.nomeMedicoBilhete+ "%'";
    }else{
      query +=' contato_medico_nome LIKE '+ "'%"+ item.nomeMedicoBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação Status chamada
  if (item.statusChamadaBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND cdr_status_chamada LIKE '+ "'%"+ item.statusChamadaBilhete+ "%'";
    }else{
      query +=' cdr_status_chamada LIKE '+ "'%"+ item.statusChamadaBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação Status consulta
  if (item.statusConsultaBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND cdr_status_consulta LIKE '+ "'%"+ item.statusConsultaBilhete+ "%'";
    }else{
      query +=' cdritem.dataI_status_consulta LIKE '+ "'%"+ item.statusConsultaBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação Tipo Atendimento
  if (item.tipoAtendimentoBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND cdr_tipo LIKE '+ "'%"+ item.tipoAtendimentoBilhete+ "%'";
    }else{
      query +=' cdr_tipo LIKE '+ "'%"+ item.tipoAtendimentoBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  //Validação Telefone Discado
  if (item.telDiscadoBilhete != ''){
    if (count > 0){
      query +=' AND contato_fk = contato_id AND cdr_tel_discado LIKE '+ "'%"+ item.telDiscadoBilhete+ "%'";
    }else{
      query +=' cdr_tel_discado LIKE '+ "'%"+ item.telDiscadoBilhete+ "%'"+ ' AND contato_fk = contato_id';
    }
    count++;
  }

  if (count == 0) {
    return null;
  }

  return query;
}

function validarHoraDataDiscagem(item,horaInicio,horaFim,count,query){

}
