const pg = require('../db');
const exec = require('child_process').exec;

module.exports = {
    select: (req, res) => {
        //Buscar todas as informações referente as campanhas, contatos e cdr para exportar
        var queryTudo = 'SELECT * FROM cdr, contato, status, campanha WHERE contato_fk = contato_id AND status.campanha_fk = campanha.campanha_id';

        pg.query(queryTudo, [], (err, ans) => {
            if (err) {
                console.log(err)
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao selecionar dados no servidor'
                });
            } else {
                //Montar um objeto JSON para enviar para o front-end
                var object = {
                    data: ans.rows
                }
                res.json(object);
            }
        });
    },

    delete: (req, res) => {
        //comando para buscar o nome do áudio no diretorio de audios do asterisk
        var queryNomeAudio = `SELECT campanha_audio FROM campanha`;

        pg.query(queryNomeAudio, [], (err, ans) => {
            if (err) {
                console.log("\n\nError: " + err)
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao deletar dados no servidor'
                });
            } else {
                //nome do audio
                var nomeAudio = ans.rows;
                console.log(nomeAudio)
                //Query para deletar os dados da base
                var queryDeleteTudo =
                    'DELETE FROM contato; ' +
                    'DELETE FROM cdr; ' +
                    'DELETE FROM status; ' +
                    'DELETE FROM campanha; ';

                pg.query(queryDeleteTudo, [], (err, ans) => {
                    if (err) {
                        console.log("Error: " + err);
                        return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Erro ao selecionar dados no servidor'
                        });
                    } else {
                        for (var i = 0; i < nomeAudio.length; i++) {
                            //Executar o comando de exclusao do audio
                            var commandToDelete = `sudo rm -rf /var/lib/asterisk/sounds/pt_BR/custom/${nomeAudio[i].campanha_audio}.gsm`;
                            execute(commandToDelete, (error, stdout) => { });
                        }
                        //Retornar sucesso da exclusao no front-end                
                        res.status(200).send();
                    }
                });
            }
        });
    }
}

function execute(command, callback) {
    exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};
