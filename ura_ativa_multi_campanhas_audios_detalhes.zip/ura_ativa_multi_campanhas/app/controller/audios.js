const pg = require('../db');
const exec = require('child_process').exec;
var houveAlteracaoEstatico = 0;
// Requiring fs module in which 
// writeFile function is defined. 
const fs = require('fs')
var igual = 0;

module.exports = {
    select: (req, res) => {
        pg.query('SELECT audio_tentativas, audio_agradece, audio_novamente, audio_invalida FROM audio', [], (err, ans) => {
                if (err) {
                    return res.status(500).send({
                        error: 'Erro interno',
                        message: 'Erro ao selecionar dados no servidor'
                    });
                } else {
                    if (ans.rowCount > 0) {
                        return res.send({
                            rows: ans.rows
                        });

                    } else {
                        return res.status(500).send({
                            message: 'Nenhum arquivo de áudio no servidor'
                        });
                    }
                }
            });
    },

    insert: async (req, res) => {
        files = req.files;
        filesName = req.body;

        if (!files) {
            return res.status(400).send({
                error: 'Missing audios',
                message: 'Nenhum áudio enviado'
            });
        }

        var { rows } = await pg.queryAsync('SELECT COUNT(*) FROM audio;');

        if (rows[0].count < 1) {
            if (files.audios.length == 4) {
                values = []
                for (var i = 0; i < files.audios.length; i++) {
                    values.push(files.audios[i].name.split('.')[0]);
                    try {
                        //await files.audios[i].mv('/home/filipefirmino/Music/sounds/' + files.audios[i].name)
                        await files.audios[i].mv('/opt/leucotron/sounds/' + files.audios[i].name)
                    } catch (error) {
                        console.log("\nErro 1: " + error);
                        return res.status(500).send({
                            error: 'Upload file',
                            message: 'Erro ao gravar áudio no servidor'
                        });
                    }
                }

                try {
                    var { rows } = await pg.queryAsync('INSERT INTO audio(audio_tentativas, ' +
                        'audio_agradece, audio_novamente, audio_invalida) ' +
                        'VALUES ($1, $2, $3, $4);', values);

                    execute('sudo converteAudio.sh', (stdout) => { });
                    //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
                    return res.status(200).send({
                        success: 'Configurado',
                        message: 'Áudios configurados com sucesso'
                    });
                } catch (error) {
                    console.log("\nErro 2: " + error);
                    return res.status(500).send({
                        error: 'Upload file',
                        message: 'Erro ao gravar áudio no servidor'
                    });
                }

            } else {
                return res.status(400).send({
                    error: 'First submit',
                    message: 'Na primeira utilização é necessário enviar todos os áudios'
                });
            }
        } else {

            //Try-Catch para verificar se existe algum áudio no banco de dados com o mesmo nome vindo do front-end
            try {
                //Caso tenha sido feito o upload de 1 arquivo apenas
                if (files.audios.length === undefined) {
                    var igual = await analisarNomesIguais(files.audios.name.split('.')[0], 0, files);

                    if (igual.igual) {
                        return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Nome do áudio: ' + igual.nomeAudio + ', já existe no banco de dados.'
                        });
                    }
                } else {
                    //Caso tenha sido feito o upload de mais de 1 arquivo no front-end
                    //files.audios[0].name.split('.')[0] neste caso é apenas para não deixar nulo o parametro, já que não é usado
                    var igual = await analisarNomesIguais(files.audios[0].name.split('.')[0], 1, files);

                    if (igual.igual) {
                        return res.status(500).send({
                            error: 'Erro interno',
                            message: 'Nome do áudio: ' + igual.nomeAudio + ', já existe no banco de dados.'
                        });
                    }
                }
            } catch (error) {
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao validar o nome do áudio no banco de dados (122)'
                });
            }

            try {
                //Query para alterar os nomes no BD
                var sql = await buildQuery(files.audios, filesName, res);
                console.log("sql: "+sql)
                var { rows } = await pg.query(sql);

                if (files.audios.length === undefined) {
                    try {
                        await files.audios.mv('/opt/leucotron/sounds/' + files.audios.name)
                        //await files.audios.mv('/home/filipefirmino/Music/sounds/' + files.audios.name)
                    } catch (error) {
                        console.log("\nErro 3: " + error);
                        return res.status(500).send({
                            error: 'Upload file',
                            message: 'Erro ao gravar áudio no servidor'
                        })
                    }
                } else {
                    for (var i = 0; i < files.audios.length; i++) {
                        try {
                            await files.audios[i].mv('/opt/leucotron/sounds/' + files.audios[i].name)
                            //await files.audios[i].mv('/home/filipefirmino/Music/sounds/' + files.audios[i].name)
                        } catch (error) {
                            console.log("\nErro 4: " + error);
                            return res.status(500).send({
                                error: 'Upload file',
                                message: 'Erro ao gravar áudio no servidor'
                            });
                        }
                    }
                }

            } catch (err) {
                return res.status(500).send({
                    error: 'Erro interno',
                    message: 'Erro ao validar o nome do áudio no banco de dados'
                });
            }
            execute('sudo converteAudio.sh', (error, stdout) => { });
            //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
            return res.status(200).send({
                success: 'Configurado',
                message: 'Áudio(s) configurado(s) com sucesso',
            });
        }
    }
}

async function buildQuery(files, filesName, res) {
    var query = null;
    query = 'UPDATE audio SET '

    if (files.length === undefined) {
        query += `${filesName[files.name]} = '${files.name.split('.')[0]}' `

    } else {
        for (var i = 0; i < files.length; i++) {
            if (i < (files.length - 1)) {
                query += `${filesName[files[i].name]} = '${files[i].name.split('.')[0]}', `
            } else {
                query += `${filesName[files[i].name]} = '${files[i].name.split('.')[0]}' `
            }
        }
    }
    return query + 'WHERE audio_id = 1';
}

async function analisarNomesIguais(valueFrontOne, qtdFront, files) {
    //Mapas para auxilio de comparação dos nomes
    var mapBackEnd = new Map();
    var mapFront = new Map();

    //Variavel de controle para informar se existe igualdade entre o que tem no front-end e back-end
    var igual = null;

    //Variavel para saber o nome do áudio que está igual e mostrar para o usuário
    var nomeAudio;

    //Query para trazer os nomes dos audios e comparar com o que veio do front-end
    var query = 'SELECT * FROM audio;'
    var { rows } = await pg.query(query);

    try {
        //Mapa dos dados do BD para ficar fácil a consulta
        mapBackEnd.set(1, rows[0].audio_tentativas);
        mapBackEnd.set(2, rows[0].audio_agradece);
        mapBackEnd.set(3, rows[0].audio_novamente);
        mapBackEnd.set(4, rows[0].audio_invalida);

        //Se somente 1( o que é marco) um áudio foi enviado e é preciso analisar o nome dele com todos que tem no banco
        if (qtdFront == 0) {
            for (var valueBack of mapBackEnd.values()) {
                if (valueBack == valueFrontOne) {
                    igual = true;
                    nomeAudio = valueFrontOne;
                }
            }
            //Caso mais de 1 áudio tenha sido enviado, então será analisados de todos para todos os nomes
        } else if (qtdFront == 1) {

            //Preencher o mapa de nome vindo do Front-end
            for (var i = 0; i < files.audios.length; i++) {
                mapFront.set(i, files.audios[i].name.split('.')[0]);
            }

            //Verificando os nomes
            for (var valueBack of mapBackEnd.values()) {
                for (var valueFront of mapFront.values()) {

                    if (valueBack == valueFront) {
                        igual = true;
                        nomeAudio = valueFront;
                    }
                }
            }
        }

        //Retorna para o método principal se existiu algum match
        return { igual: igual, nomeAudio: nomeAudio };

    } catch (error) {
        res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao validar o nome do áudio no banco de dados'
        });
    }
}

function execute(command, callback) {
    exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};