function sendCredentials() {

  var username = document.getElementById('inputUsername').value;
  var password = document.getElementById('inputPassword').value;

  if (username == '' || password == '') {
    alertSwal('Usuário e senha vazios');
    return;
  }

  var object = new Object();
  object.username = username;
  object.password = password;

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        window.open("/", "_self");
        break;

        case 500:
          alertSwal('Erro interno com o servidor');
          break;

        case 404:
          alertSwal('Não foi possível alcançar o servidor');
          break;
          
        default:
          alertSwal('Erro inesperado, contate o administrador');
      }
    }
  }

  xhttp.open("POST", '/users/signin', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function alertSwal(message) {
  swal({
    title: "Ops :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}