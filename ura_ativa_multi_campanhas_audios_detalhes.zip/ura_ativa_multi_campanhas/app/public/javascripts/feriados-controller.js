function atualizaFeriados() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/feriado/select')

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          addFeriadosNaTabela(JSON.parse(this.response))
          break;
        case 304:
          addFeriadosNaTabela(JSON.parse(this.response))
          break;
        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        default:
          alertSwal(JSON.parse(this.response).message);
          break;
      }
    }
  }
  xhttp.send()
}

function addFeriadosNaTabela(rows) {
  //Pegar referencia da tabela de usuários
  const table = document.querySelector('#tabelaFeriados tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;
    var actionCell = newRow.insertCell(count);

    //Nome do feriado
    var feriadoCell = newRow.insertCell(count);
    var feriadoValue = document.createTextNode(rows[i].feriado_nome);
    feriadoCell.appendChild(feriadoValue);
    count++;

    //Data feriado
    var dataCell = newRow.insertCell(count);
    var date = new Date(rows[i].feriado_data)
    var dataValue = document.createTextNode(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1))}`);
    dataCell.appendChild(dataValue);
    count++;

    // botao editar
    var editarCell = newRow.insertCell(count)
    var editarElement = document.createElement('input')
    editarElement.setAttribute('type', 'button')
    editarElement.setAttribute('value', 'Editar')
    editarElement.setAttribute('data-toggle', "modal")
    editarElement.setAttribute('data-target', "#modalEditarFeriado")
    editarElement.classList.add('btn')
    editarElement.classList.add('btn-outline')
    editarElement.classList.add('btn-warning')
    editarElement.onclick = editItem(rows[i])
    editarCell.appendChild(editarElement)
    count++;

    // botao excluir
    var excluirCell = newRow.insertCell(count)
    var excluirElement = document.createElement('input')
    excluirElement.setAttribute('type', 'button')
    excluirElement.setAttribute('value', 'Excluir')
    excluirElement.classList.add('btn')
    excluirElement.classList.add('btn-outline')
    excluirElement.classList.add('btn-danger')
    excluirElement.classList.add('dim')
    excluirElement.onclick = deleteItem(rows[i])
    excluirCell.appendChild(excluirElement)
    count++;
  }
}

function deleteItem(item) {
  return function () {

    var xhttp = new XMLHttpRequest();
    xhttp.open('POST', '/feriado/delete')

    var object = {
      idFeriado: item.feriado_id
    }

    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        switch (this.status) {
          case 200:
            atualizaFeriados();
            sucessSwal(JSON.parse(this.response).message);
            break;

          case 304:
            atualizaFeriados();
            sucessSwal(JSON.parse(this.response).message);
            break;
        }
      }
    }
    xhttp.setRequestHeader('Content-Type', 'application/json')
    xhttp.send(JSON.stringify(object));
  }
}

var itemEditar;
function editItem(item) {
  return function () {
    var date = new Date(item.feriado_data)
    $('#nomeEditarFeriado').val(item.feriado_nome);
    $('#dataEditarFeriado').val(`${(date.getDate() < 10 ? '0' : '') + date.getDate()}/${((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1))}`);
    $('#idFeriado').val(item.feriado_id);
    itemEditar = item;
  }
}

function salvarEdicao() {
  var idFeriado = $('#idFeriado').val();
  var nomeFeriado = $('#nomeEditarFeriado').val();
  var dataFeriado = $('#dataEditarFeriado').val();
  
  //Verificar se os campos de nome do feriado e a data estão vazios
  if (nomeFeriado.length == 0 && dataFeriado.length == 0) {
    alertSwal('Nome do feriado e a data não podem estar vazios!');
    return;
  }

  //Verificar se somente o nome do feriado está vazio
  if (nomeFeriado.length == 0 && dataFeriado.length != 0) {
    alertSwal('Nome do feriado não pode estar vazio!');
    return;
  }

  //Verificar se a data do feriado está vazio
  if (nomeFeriado.length != 0 && dataFeriado.length == 0) {
    alertSwal('Data do feriado não pode estar vazio!');
    return;
  }

  //Converter de pt-br para en o formato da data para consulta no banco
  //-----------------------------------------------------------------------------------
  var dataFeriados = null;
  if (!dataFeriado.length == 0) {
    dataFeriados =
      dataFeriado[3] + dataFeriado[4] + //mes
      "/" + dataFeriado[0] + dataFeriado[1] + // dia
      "/" + dataFeriado[6] + dataFeriado[7] + dataFeriado[8] + dataFeriado[9]; //ano
  } else {
    dataFeriados = '';
  }
  //-----------------------------------------------------------------------------------

  var object = {
    idFeriado: idFeriado,
    nomeFeriado: nomeFeriado,
    dataFeriado: dataFeriados
  }

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          atualizaFeriados();
          sucessSwal(JSON.parse(this.response).message);
          $('#modalEditarFeriado').modal('hide');
          break;

        case 304:
          atualizaFeriados();
          sucessSwal(JSON.parse(this.response).message);
          $('#modalEditarFeriado').modal('hide');
          break;

        case 400:
          break;

        case 401:
          alertSwal('Não houve alterações no feriado, tente novamente!');
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        case 404:
          alertSwal('Não foi possível alcançar o servidor.');
          break;

        default:
          alertSwal(JSON.parse(this.response).message);
          break;
      }
    }
  }

  xhttp.open("POST", '/feriado/update', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function salvarFeriado() {
  var nomeFeriado = $('#nomeFeriado').val();
  var dataFeriado = $('#dataFeriado').val();

  //Verificar se os campos de nome do feriado e a data estão vazios
  if (nomeFeriado.length == 0 && dataFeriado.length == 0) {
    alertSwal('Nome do feriado e a data não podem estar vazios!');
    return;
  }

  //Verificar se somente o nome do feriado está vazio
  if (nomeFeriado.length == 0 && dataFeriado.length != 0) {
    alertSwal('Nome do feriado não pode estar vazio!');
    return;
  }

  //Verificar se a data do feriado está vazio
  if (nomeFeriado.length != 0 && dataFeriado.length == 0) {
    alertSwal('Data do feriado não pode estar vazio!');
    return;
  }

  //Converter de pt-br para en o formato da data para consulta no banco
  //-----------------------------------------------------------------------------------
  var dataFeriados = null;
  if (!dataFeriado.length == 0) {
    dataFeriados =
      dataFeriado[3] + dataFeriado[4] + //mes
      "/" + dataFeriado[0] + dataFeriado[1] + // dia
      "/" + dataFeriado[6] + dataFeriado[7] + dataFeriado[8] + dataFeriado[9]; //ano
  } else {
    dataFeriados = '';
  }
  //-----------------------------------------------------------------------------------

  var object = {
    nomeFeriado: nomeFeriado,
    dataFeriado: dataFeriados
  }

  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
          atualizaFeriados();
          sucessSwal(JSON.parse(this.response).message)
          break;

        case 304:
          atualizaFeriados();
          sucessSwal(JSON.parse(this.response).message)
          break;

        case 401:
          alertSwal('Feriado já cadastrado no sistema!');
          break;

        case 500:
          alertSwal(JSON.parse(this.response).message);
          break;

        case 404:
          alertSwal('Não foi possível alcançar o servidor.');
          break;

        default:
          alertSwal(JSON.parse(this.response).message);
          break;
      }
    }
  }

  xhttp.open("POST", '/feriado/insert', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function alertSwal(message) {
  swal({
    title: "Ops :(",
    text: message,
    type: "error",
    showConfirmButton: true
  });
}

function sucessSwal(message) {
  swal({
    title: "Sucesso :)",
    text: message,
    type: "success",
    timer: 4500
  },
    function () {
      swal.close();
      location.reload();
    });
}