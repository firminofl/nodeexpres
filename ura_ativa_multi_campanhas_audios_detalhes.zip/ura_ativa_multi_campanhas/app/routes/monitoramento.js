var express = require('express');
var router = express.Router();
var monitoramento_controller = require('../controller/monitoramento');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Buscar dados do HD
router.get('/select', monitoramento_controller.select);

//Buscar dados do Asterisk
router.get('/selectAsterisk', monitoramento_controller.selectAsterisk);

module.exports = router;