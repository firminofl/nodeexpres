var express = require('express');
var router = express.Router();
var authenticate = require('../controller/authenticate');
var campanha_controller = require('../controller/campanha')

router.use(authenticate.apiAuth);

//Cadastrar campanha
router.post('/insert', campanha_controller.insert);

//Cadastrar contatos campanha
router.post('/insertContatos', campanha_controller.insertContatos);

//Buscar campanha
router.post('/select', campanha_controller.select);

//Deletar campanha
router.post('/delete', campanha_controller.delete);

//Deletar campanha
router.get('/export', campanha_controller.export);

//Buscar campanhas e atualizar o select na tela de gerenciamento
router.get('/selectSomenteCampanhas', campanha_controller.selectSomenteCampanhas);

//Buscar campanhas e atualizar o select na tela de historico
router.post('/selectSomenteCampanhasParadas', campanha_controller.selectSomenteCampanhasParadas);

//Buscar campanhas e seus dados na tela de historico
router.post('/selectDadosCampanhaVigenteParada', campanha_controller.selectDadosCampanhaVigenteParada);

//Buscar campanhas e seus dados na tela de gerenciamento
router.post('/selectDadosCampanhaVigente', campanha_controller.selectDadosCampanhaVigente);

//Iniciar campanha (mudar status de ativado = TRUE)
router.post('/iniciarCampanha', campanha_controller.iniciarCampanha);

//Parar campanha (mudar contato_excluido = TRUE && cont_discagem = 0)
router.post('/pararCampanha', campanha_controller.pararCampanha);

//Pausar campanha (mudar status pausado = TRUE e o status ativado continua como TRUE)
router.post('/pausarCampanha', campanha_controller.pausarCampanha);

//Reiniciar campanha (mudar status pausado = FALSE e o status ativado continua como TRUE)
//router.post('/reiniciarCampanha', campanha_controller.reiniciarCampanha);

//Buscar campanha ativado = TRUE
router.get('/selectCampanhaAtiva', campanha_controller.selectCampanhaAtiva);
module.exports = router;
