﻿--INSERT CAMPANHA 1
INSERT INTO campanha(
            campanha_nome, campanha_audio, campanha_total_contatos, 
            campanha_op1, campanha_op2, campanha_op3, campanha_op4, campanha_op5, 
            campanha_op6, campanha_op7, campanha_op8, campanha_op9)
    VALUES ('Campanha_ISION', 'Audio_Ision', 1000, 
            '560', '600', '601', '602', '603', 
            '604', '605', '606', '607');
            
INSERT INTO status(campanha_fk)
    VALUES (1);
    
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Evaldo', '3534719553', '35999998888',1);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Michel', '3534719538', '35999997777',1);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Jonathan', '3534719503', '35999996666',1);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Filipe', '3534719535', '35999995555',1);
    
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719553', 'BUSY',
            '', '', 1);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999998888', 'ANSWER',
            '560', 'HUMAN', 1);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719538', 'BUSY',
            '', '', 2);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999997777', 'ANSWER',
            '', 'MACHINE', 2);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719503', 'BUSY',
            '', '', 3);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999996666', 'ANSWER',
            '', 'MACHINE', 3);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719535', 'BUSY',
            '', '', 4);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999995555', 'ANSWER',
            '600', 'HUMAN', 4);
-------------------------------------------------------------------------------------------
--INSERT CAMPANHA 2
INSERT INTO campanha(
            campanha_nome, campanha_audio, campanha_total_contatos, 
            campanha_op1, campanha_op2, campanha_op3, campanha_op4, campanha_op5, 
            campanha_op6, campanha_op7, campanha_op8, campanha_op9)
    VALUES ('Campanha_FLUX', 'Audio_FLUX', 100, 
            '560', '600', '601', '602', '603', 
            '604', '605', '606', '607');
            
INSERT INTO status(campanha_fk)
    VALUES (2);
    
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Evaldo FLUX', '3534719553', '35999998888',2);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Michel FLUX', '3534719538', '35999997777',2);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Jonathan FLUX', '3534719503', '35999996666',2);
INSERT INTO contato(contato_nome, contato_tel1, contato_tel2,campanha_fk)
    VALUES ('Filipe FLUX', '3534719535', '35999995555',2);
    
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719553', 'BUSY',
            '', '', 5);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999998888', 'ANSWER',
            '560', 'HUMAN', 5);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719538', 'BUSY',
            '', '', 6);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999997777', 'ANSWER',
            '', 'MACHINE', 6);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719503', 'BUSY',
            '', '', 7);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999996666', 'ANSWER',
            '', 'MACHINE', 7);

INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('003534719535', 'BUSY',
            '', '', 8);
INSERT INTO cdr(cdr_tel_discado, cdr_status_chamada, 
            cdr_dtmf, cdr_tipo_atendimento, contato_fk)
    VALUES ('0035999995555', 'ANSWER',
            '600', 'HUMAN', 8);

--------------------------------------------------------------------------------------------------------------------------------------
--SELECT
SELECT * from campanha AS c 
LEFT JOIN status AS s ON c.campanha_id = s.campanha_fk
LEFT JOIN contato AS cont ON c.campanha_id = cont.campanha_fk
LEFT JOIN cdr AS cdr ON cont.contato_id = cdr.contato_fk

SELECT cont.contato_id, cont.contato_nome, cont.contato_tel1, cont.contato_tel2, cont.contato_outros, TO_CHAR(CURRENT_TIMESTAMP - cont.contato_data_hora_discagem, 'HH24'), cont.contato_cont_discagem, c.campanha_id, c.campanha_nome, c.campanha_audio, c.campanha_op1, c.campanha_op2, c.campanha_op3, c.campanha_op4, c.campanha_op5, c.campanha_op6, c.campanha_op7, c.campanha_op8, c.campanha_op9  from campanha AS c 
LEFT JOIN status AS s ON c.campanha_id = s.campanha_fk
LEFT JOIN contato AS cont ON c.campanha_id = cont.campanha_fk
WHERE s.ativado IS TRUE
AND s.pausado IS FALSE 
AND s.parado IS FALSE 
AND cont.contato_excluido IS FALSE
AND cont.contato_cont_discagem <= 5 
ORDER BY RANDOM() LIMIT 10;

--------------------------------------------------------------------------------------------------------------------------------------
DELETE FROM campanha WHERE campanha_id = 1