#!/bin/bash
#+--------------------------------------------------------------------------------------------------------------------------------------------+
#| Descricao:                                                                                                                                 |
#| Scritp eh chamado pelo dialplan, quando nao houver sucesso na discagem para o primerio numero do paciente informado no BD                  |
#| do cliente. Assim, no caso de falha chama este script que ira criar novo canal de dialer porém discando para o segundo                    |
#| numero de telefone fornecido pelo BD do cliente.                                                                                           |
#+--------------------------------------------------------------------------------------------------------------------------------------------+
#| Simulacao:                                                                                                                                 |
#| ./call.sh '${CONTATO_ID}' '${CONTATO_NOME}' '${CONTATO_TEL_1}' '${CONTATO_TEL_2}' '${CONTATO_OUTROS}' '${CONTATO_CONT_DISCAGEM}' '${CAMPANHA_NOME}' '${CAMPANHA_AUDIO}' '${CAMPANHA_OP1}' '${CAMPANHA_OP2}' '${CAMPANHA_OP3}' '${CAMPANHA_OP4}' '${CAMPANHA_OP5}' '${CAMPANHA_OP6}' '${CAMPANHA_OP7}' '${CAMPANHA_OP8}' '${CAMPANHA_OP9}' '${DIALSTATUS}'

#| ./call.sh '${CONTATO_ID}' '${CONTATO_NOME}' '${CONTATO_TEL_1}' '${CONTATO_TEL_2}' '${CONTATO_CONT}' '${DIALSTATUS}'                        |
#+--------------------------------------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                                                   |
#|Data: 09/01/2019                                                                                                                            |
#+--------------------------------------------------------------------------------------------------------------------------------------------+

if [ ${#4} -lt 8 ];then
    exit 0
fi

export PGPASSWORD=sml3uc0

DBUSER='postgres'
DBNAME='ura'
DBTABLE='contato'

CONTATO_ID=$1
CONTATO_NOME=$2
CONTATO_TEL_1=$3
CONTATO_TEL_2=$4
CONTATO_OUTROS=$5
CONTATO_CONT_DISCAGEM=$6
CAMPANHA_NOME=$7
CAMPANHA_AUDIO=$8
CAMPANHA_OP1=$9
CAMPANHA_OP2=${10}
CAMPANHA_OP3=${11}
CAMPANHA_OP4=${12}
CAMPANHA_OP5=${13}
CAMPANHA_OP6=${14}
CAMPANHA_OP7=${15}
CAMPANHA_OP8=${16}
CAMPANHA_OP9=${17}
DIALSTATUS=${18}

TEL=$(echo "${CONTATO_TEL_2}" | xargs | sed 's/[^0-9]//g')
ABSOLUTE_FILE_NAME='/opt/leucotron/call/'$(date +"%d%m%Y%H%M%S")_${TEL}'.call'
                                       
echo "Channel: Local/${TEL}@outbound-call/n"				> ${ABSOLUTE_FILE_NAME}
echo "Callerid: <5999> "5999""								>> ${ABSOLUTE_FILE_NAME}
echo "MaxRetries: 0"										>> ${ABSOLUTE_FILE_NAME}
echo "WaitTime: 180"										>> ${ABSOLUTE_FILE_NAME}
echo "Context: inbound-call"								>> ${ABSOLUTE_FILE_NAME}
echo "Extension: ${TEL}"									>> ${ABSOLUTE_FILE_NAME}
echo "Priority: 1"											>> ${ABSOLUTE_FILE_NAME}
echo "Set: CONTATO_ID=${CONTATO_ID}"						>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CONTATO_NOME=${CONTATO_NOME}"					>> ${ABSOLUTE_FILE_NAME}                                       
echo "Set: CONTATO_TEL_1=${CONTATO_TEL_1}"					>> ${ABSOLUTE_FILE_NAME}
echo "Set: CONTATO_TEL_2=${CONTATO_TEL_2}"					>> ${ABSOLUTE_FILE_NAME}                                       
echo "Set: CONTATO_OUTROS=${CONTATO_OUTROS}"				>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CONTATO_CONT_DISCAGEM=${CONTATO_CONT_DISCAGEM}"	>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_NOME=${CAMPANHA_NOME}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_AUDIO=${CAMPANHA_AUDIO}"				>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP1=${CAMPANHA_OP1}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP2=${CAMPANHA_OP2}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP3=${CAMPANHA_OP3}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP4=${CAMPANHA_OP4}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP5=${CAMPANHA_OP5}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP6=${CAMPANHA_OP6}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP7=${CAMPANHA_OP7}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP8=${CAMPANHA_OP8}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: CAMPANHA_OP9=${CAMPANHA_OP9}"					>> ${ABSOLUTE_FILE_NAME}                                        
echo "Set: DIALSTATUS=${DIALSTATUS}"						>> ${ABSOLUTE_FILE_NAME}
echo "Archive: yes"											>> ${ABSOLUTE_FILE_NAME}
#echo "$(date +"%d-%m-%Y_%H:%M:%S") Chamando TEL_2 ${TEL}"	>> /opt/leucotron/log/confirmaConsulta.log
mv ${ABSOLUTE_FILE_NAME} /var/spool/asterisk/outgoing/
