#!/bin/bash
#+----------------------------------------------------------------------------------------------------------------------------------------------+
#| Descricao:                                                                                                                                   |
#| Scritp eh chamado pelo dialplan, quando nao houver sucesso na discagem para o primerio numero do paciente informado no BD                    |
#| do cliente. Assim, no caso de falha chama este escript que ira criar novo canal de dialer porém discando para o segundo                      |
#| numero de telefone fornecido pelo BD do cliente.                                                                                             |
#+----------------------------------------------------------------------------------------------------------------------------------------------+
#| Simulacao:                                                                                                                                   |
#| ./call.sh '${ID}' '${ID_CONSULTA}' '${DATA_HORA_CONSULTA}' '${PACIENTE_ID}' '${PACIENTE_NOME}' '${TEL_1_ORIGINAL}' '${TEL_2_ORIGINAL}'       |
#| '${MED_ID}' '${MED_NOME}' '${ESPECIALIDADE}' '${PROCEDIMENTO}' '${LOCALIDADE}' '${OUTROS}' '${STATUS}' '${AUDIO_INFORMA}' '${AUDIO_CONFIRMA}'|
#| '${AUDIO_TENTATIVAS}' '${AUDIO_AGRADECE}' '${AUDIO_NOVAMENTE}' '${AUDIO_INVALIDA}' '${AUDIO_CONFIRMADA}' '${AUDIO_AGRADECE_PART}'            |
#| '${AUDIO_CANCELADA}' '${AUDIO_REAGENDAR}' '${AUDIO_ALO}'                                                                                     |
#+----------------------------------------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                                                     |
#|Data: 20/03/2019                                                                                                                              |
#+----------------------------------------------------------------------------------------------------------------------------------------------+

#Testa se quantidade de digitos de  TEL_2_ORIGINAL eh menor que 8.
if [ ${#7} -lt 8 ]
then
    exit 0
fi

ID=$1
ID_CONSULTA=$2
DATA_HORA_CONSULTA=$3
PACIENTE_ID=$4
PACIENTE_NOME=$5
TEL_1_ORIGINAL=$6
TEL_2_ORIGINAL=$7
MED_ID=$8
MED_NOME=$9
ESPECIALIDADE=${10}
PROCEDIMENTO=${11}
LOCALIDALIDADE=${12}
OUTROS=${13}
STATUS=${14}
AUDIO_INFORMA=${15}
AUDIO_CONFIRMA=${16}
AUDIO_TENTATIVAS=${17}
AUDIO_AGRADECE=${18}
AUDIO_NOVAMENTE=${19}
AUDIO_INVALIDA=${20}
AUDIO_CONFIRMADA=${21}
AUDIO_AGRADECE_PART=${22}
AUDIO_CANCELADA=${23}
AUDIO_REAGENDAR=${24}
AUDIO_ALO=${25}

TEL=$(echo "${TEL_2_ORIGINAL}" | xargs | sed 's/[^0-9]//g')
ABSOLUTE_FILE_NAME='/opt/leucotron/call/'$(date +"%d%m%Y%H%M%S")_${TEL}'.call'
                                       
echo "Channel: Local/${TEL}@outbound-call/n"				> ${ABSOLUTE_FILE_NAME}
echo "Callerid: <5999> "5999""								>> ${ABSOLUTE_FILE_NAME}
echo "MaxRetries: 0"										>> ${ABSOLUTE_FILE_NAME}
echo "WaitTime: 180"										>> ${ABSOLUTE_FILE_NAME}
echo "Context: inbound-call"								>> ${ABSOLUTE_FILE_NAME}
echo "Extension: ${TEL}"									>> ${ABSOLUTE_FILE_NAME}
echo "Priority: 1"											>> ${ABSOLUTE_FILE_NAME}
echo "Set: ID=${ID}"                                    	>> ${ABSOLUTE_FILE_NAME}
echo "Set: ID_CONSULTA=${ID_CONSULTA}"                  	>> ${ABSOLUTE_FILE_NAME}
echo "Set: DATA_HORA_CONSULTA=${DATA_HORA_CONSULTA}"    	>> ${ABSOLUTE_FILE_NAME}
echo "Set: PACIENTE_ID=${PACIENTE_ID}"                  	>> ${ABSOLUTE_FILE_NAME}
echo "Set: PACIENTE_NOME=${PACIENTE_NOME}"              	>> ${ABSOLUTE_FILE_NAME}
echo "Set: TEL_1_ORIGINAL=${TEL_1_ORIGINAL}"            	>> ${ABSOLUTE_FILE_NAME}
echo "Set: TEL_2_ORIGINAL=${TEL_2_ORIGINAL}"            	>> ${ABSOLUTE_FILE_NAME}
echo "Set: MED_ID=${MED_ID}"                            	>> ${ABSOLUTE_FILE_NAME}
echo "Set: MED_NOME=${MED_NOME}"                        	>> ${ABSOLUTE_FILE_NAME}
echo "Set: ESPECIALIDADE=${ESPECIALIDADE}"              	>> ${ABSOLUTE_FILE_NAME}
echo "Set: PROCEDIMENTO=${PROCEDIMENTO}"                	>> ${ABSOLUTE_FILE_NAME}
echo "Set: LOCALIDADE=${LOCALIDADE}"                    	>> ${ABSOLUTE_FILE_NAME}
echo "Set: OUTROS=${OUTROS}"                            	>> ${ABSOLUTE_FILE_NAME}
echo "Set: STATUS=${STATUS}"                            	>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_INFORMA=${AUDIO_INFORMA}"					>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_CONFIRMA=${AUDIO_CONFIRMA}"				>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_TENTATIVAS=${AUDIO_TENTATIVAS}"			>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_AGRADECE=${AUDIO_AGRADECE}"				>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_NOVAMENTE=${AUDIO_NOVAMENTE}"				>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_INVALIDA=${AUDIO_INVALIDA}"				>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_CONFIRMADA=${AUDIO_CONFIRMADA}"			>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_AGRADECE_PART=${AUDIO_AGRADECE_PART}"		>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_CANCELADA=${AUDIO_CANCELADA}"				>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_REAGENDAR=${AUDIO_REAGENDAR}"				>> ${ABSOLUTE_FILE_NAME}
echo "Set: AUDIO_ALO=${AUDIO_ALO}"							>> ${ABSOLUTE_FILE_NAME}
echo "Set: DISCAR_TEL_2=S"									>> ${ABSOLUTE_FILE_NAME}
echo "Archive: yes"											>> ${ABSOLUTE_FILE_NAME}
#echo "$(date +"%d-%m-%Y_%H:%M:%S") Chamando TEL_2 ${TEL}"	>> /opt/leucotron/log/confirmaNode.log
mv ${ABSOLUTE_FILE_NAME} /var/spool/asterisk/outgoing/
