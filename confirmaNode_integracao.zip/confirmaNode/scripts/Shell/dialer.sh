#!/bin/bash
#+---------------------------------------------------------------------------------------------------------------+
#|date +%w: retorna o dia da semana sendo:                                                                       |
#|0-Domingo, 1-Segunda, 2-Terça, 3-Quarta, 4-Quinta, 5-Sexta e 6-Sábado                                          |
#|date +%H%M: retorna hora e minuto do sistema de forma concatenada.                                             |
#+---------------------------------------------------------------------------------------------------------------+
#|Descrição: Discador para Asterisk integrado com banco de dados Postgresql 9.3                                  |
#| - Script realiza uma busca diaria ao BD remoto a fim de obter os contatos a serem discadod durante o dia.     |
#+---------------------------------------------------------------------------------------------------------------+
#|Autor: Evaldo de Oliveira                                                                                      |
#|Data: 29/03/2019                                                                                               |
#+---------------------------------------------------------------------------------------------------------------+

#*********************Variaveis globais de controle*********************

#Parâmetro de entrada (start/stop)
OPCAO="$1"

export PGPASSWORD="sml3uc0"
DBUSER="postgres"
DBNAME="confirma"
DBTABLECONTATO="contato"
DBTABLECDR="cdr"
DBTABLEFERIADO="feriado"
DBTABLELOG="log"
DBTABLECONF="configuracao"
DBTABLESEMANA="dia_semana"
DBTABLEAUDIO="audio"

#Quantidade minima de digitos esperado que os tel1 e tel2 possuam
QTD_DG_TEL=8

CONF=$(echo "SELECT * FROM "${DBTABLECONF}";" | psql -t -d "${DBNAME}" -U "${DBUSER}")
#Limite de discagens por dia para um mesmo contato
#nao usei a abordagem de -1, mas troquei >= por > no select de comparacao do cont. Testar!!!
CALL_LIMIT=$(echo "${CONF}" | awk -F '|' '{ print $2 }' | xargs)
#Intervalo minimo de horas entre discagens
INTERVAL=$(echo "${CONF}" | awk -F '|' '{ print $3 }' | xargs)
#Limite de chamadas simultaneas
CHANNLIMIT=$(echo "${CONF}" | awk -F '|' '{ print $4 }' | xargs)
#resolver a questao de discagem antes de feriado posteriormente
#amd ativo/desativado

AUDIO=$(echo "SELECT * FROM "${DBTABLEAUDIO}";" | psql -t -d "${DBNAME}" -U "${DBUSER}")
AUDIO_INFORMA=$(echo "${AUDIO}" | awk -F '|' '{ print $2 }' | xargs)
AUDIO_CONFIRMA=$(echo "${AUDIO}" | awk -F '|' '{ print $3 }' | xargs)
AUDIO_TENTATIVAS=$(echo "${AUDIO}" | awk -F '|' '{ print $4 }' | xargs)
AUDIO_AGRADECE=$(echo "${AUDIO}" | awk -F '|' '{ print $5 }' | xargs)
AUDIO_NOVAMENTE=$(echo "${AUDIO}" | awk -F '|' '{ print $6 }' | xargs)
AUDIO_INVALIDA=$(echo "${AUDIO}" | awk -F '|' '{ print $7 }' | xargs)
AUDIO_CONFIRMADA=$(echo "${AUDIO}" | awk -F '|' '{ print $8 }' | xargs)
AUDIO_AGRADECE_PART=$(echo "${AUDIO}" | awk -F '|' '{ print $9 }' | xargs)
AUDIO_CANCELADA=$(echo "${AUDIO}" | awk -F '|' '{ print $10 }' | xargs)
AUDIO_REAGENDAR=$(echo "${AUDIO}" | awk -F '|' '{ print $11 }' | xargs)
AUDIO_ALO=$(echo "${AUDIO}" | awk -F '|' '{ print $12 }' | xargs)

#*********************Functions*********************

#Se RETURN=1 data analisada esta na tabela de feriado
validaFeriado(){
	local RETURN=0
	local DATA=$(echo "$(date +%m-%d)")
	local FERIADO=$(echo "SELECT * FROM "${DBTABLEFERIADO}" WHERE to_char(feriado_data, 'MM-DD') = '${DATA}';" | psql -t -d "${DBNAME}" -U "${DBUSER}" | xargs)

	#-n testa se retorno != null
	if [ -n "${FERIADO}" ]
	then
		RETURN=1
	fi

	echo "${RETURN}"
}

#Se RETURN=1 dia esta ativo e dentro do horario de discagem
validaDiaHora(){
    local RETURN=0
	local DSEMANA=$(echo `date +%w`)
	local HORA=$(echo `date +%H%M`)
	local DADOS_DIA=$(echo "SELECT * FROM ${DBTABLESEMANA} WHERE dia_semana_ativo = TRUE AND dia_semana_dia = '${DSEMANA}';" | psql -t -d ${DBNAME} -U ${DBUSER})

	#-n testa se retorno != null
	if [ -n "${DADOS_DIA}" ]
	then
		local HORA_INI=$(echo "${DADOS_DIA}" | awk -F '|' '{ print $3 }' | xargs)
		local HORA_FIM=$(echo "${DADOS_DIA}" | awk -F '|' '{ print $4 }' | xargs)
		if [ ${HORA} -ge ${HORA_INI} -a ${HORA} -le ${HORA_FIM} ]
		then
			RETURN=1
		fi
	fi

    echo "${RETURN}"
}

populaTabelaContato(){
	#Verifica na tabela log se ha registro com a data atual em caso de positivo, nao executa a aplicacao que popula a tabela contato novamente.
	local DATA=$(echo "$(date +%Y-%m-%d)")
	local TOTAL=$(echo "SELECT * FROM ${DBTABLELOG} WHERE log_data_hora_exe_query::DATE = '${DATA}';"| psql -t -d ${DBNAME} -U ${DBUSER})

	#-z testa se retorno == null
	if [ -z "${TOTAL}" ]
	then
		local TOTAL=$(bash select_bd_remoto.sh | wc -l)
		echo "INSERT INTO ${DBTABLELOG}(log_total_consultas) VALUES ('${TOTAL}');" | psql -t -d ${DBNAME} -U ${DBUSER} >> /dev/null
		bash select_bd_remoto.sh | while read local CONTATO
		do
			#Testa se fim de lista de contatos
			#-n testa se retorno != null
			if [ -n "${CONTATO}" ]
			then
				local ID_CONSULTA=$(echo "${CONTATO}" | awk -F '|' '{ print $2 }' | xargs)
				local DATA_HORA_CONSULTA=$(echo "${CONTATO}" | awk -F '|' '{ print $3 }' | xargs )
				local PACIENTE_ID=$(echo "${CONTATO}" | awk -F '|' '{ print $4 }' | xargs)
				local PACIENTE_NOME=$(echo "${CONTATO}" | awk -F '|' '{ print $5 }' | xargs)
				local TEL_1_ORIGINAL=$(echo "${CONTATO}" | awk -F '|' '{ print $6 }' | xargs)
				local TEL_2_ORIGINAL=$(echo "${CONTATO}" | awk -F '|' '{ print $7 }' | xargs)
				local MED_ID=$(echo "${CONTATO}" | awk -F '|' '{ print $8 }' | xargs)
				local MED_NOME=$(echo "${CONTATO}" | awk -F '|' '{ print $9 }' | xargs)
				echo "INSERT INTO ${DBTABLECONTATO}(contato_consulta_id, contato_consulta_data_hora, contato_paciente_id, contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_id, contato_medico_nome) VALUES ('${ID_CONSULTA}', '${DATA_HORA_CONSULTA}', '${PACIENTE_ID}', '${PACIENTE_NOME}', '${TEL_1_ORIGINAL}', '${TEL_2_ORIGINAL}', '${MED_ID}', '${MED_NOME}');" | psql -t -d ${DBNAME} -U ${DBUSER} >> /dev/null
			fi
		done
	fi
}

coreDial(){
	local NUMBER=""
	#Pega da base local os contatos a serem discados
	echo "SELECT * FROM ${DBTABLECONTATO} WHERE contato_ativado = TRUE AND contato_cont_discagem < ${CALL_LIMIT} ORDER BY contato_data_hora_discagem ASC, contato_cont_discagem ASC;" | psql -t -d ${DBNAME} -U ${DBUSER} | while read NUMBER
	do

		#Testa se fim de lista de contatos
		#-n testa se retorno != null
		if [ -n "${NUMBER}" ]
		then
			#Testa se ainda esta dentro do dia e horario de discagem
			local DIA_HORA=$(validaDiaHora)
			if [ "${DIA_HORA}" -eq 1 ]
			then
				#Testa qtd de canais utilizado pelo Confirmador
				NCALLSLOCAL=`sudo asterisk -rx "group show channels CONFIRMADOR" | egrep "active" | awk '{ print $1 }'`
				if [ "${NCALLSLOCAL}" -lt "${CHANNLIMIT}" ]
				then
					#Testa qtd digitos telefone
					local ID=$(echo "${NUMBER}" | awk -F '|' '{ print $1 }' | xargs )
					local TEL_1=$(echo "${NUMBER}" | awk -F '|' '{ print $6 }' | xargs | sed 's/[^0-9]//g')
					local TEL_2=$(echo "${NUMBER}" | awk -F '|' '{ print $7 }' | xargs | sed 's/[^0-9]//g')
					#Testa se o numero do tel1 e tel2 possui numero de digitos >= 8
					if [ "${#TEL_1}" -ge "${QTD_DG_TEL}" -o "${#TEL_2}" -ge "${QTD_DG_TEL}" ]
					then
						local CONT=$(echo "${NUMBER}" | awk -F '|' '{ print $15 }' | xargs)
						#DIF recebe a hora da ultima discagem para o paciente em questao
						local DIF=$(echo "SELECT TO_CHAR(CURRENT_TIMESTAMP - contato_data_hora_discagem, 'HH24') FROM ${DBTABLECONTATO} WHERE contato_id = '${ID}';" | psql -t -d ${DBNAME} -U ${DBUSER} | xargs)
						#Testa se o intervalo entre discagem para o mesmo contato foi atingido ou se eh a primeira discagem para este contato
						if [ \( "${DIF}" -ge "${INTERVAL}" \) -o \( "${CONT}" -eq "0" \) ]
						then
							#Testa se atingiu limite de discagem
							if [ "${CONT}" -ge "${CALL_LIMIT}" ]
							then
								STATUS='LIMITE ATINGIDO'
								echo "UPDATE ${DBTABLECONTATO} SET contato_ativado = FALSE;" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
							else
								STATUS='AGENDADA' 
							fi

							local ID_CONSULTA=$(echo "${NUMBER}" | awk -F '|' '{ print $2 }' | xargs)
							local DATA_HORA_CONSULTA=$(echo "${NUMBER}" | awk -F '|' '{ print $3 }' | xargs )
							local PACIENTE_ID=$(echo "${NUMBER}" | awk -F '|' '{ print $4 }' | xargs)
							local PACIENTE_NOME=$(echo "${NUMBER}" | awk -F '|' '{ print $5 }' | xargs)
							local TEL_1_ORIGINAL=$(echo "${NUMBER}" | awk -F '|' '{ print $6 }' | xargs)
							local TEL_2_ORIGINAL=$(echo "${NUMBER}" | awk -F '|' '{ print $7 }' | xargs)
							local MED_ID=$(echo "${NUMBER}" | awk -F '|' '{ print $8 }' | xargs)
							local MED_NOME=$(echo "${NUMBER}" | awk -F '|' '{ print $9 }' | xargs)
							local ESPECIALIDADE=$(echo "${NUMBER}" | awk -F '|' '{ print $10 }' | xargs)
							local PROCEDIMENTO=$(echo "${NUMBER}" | awk -F '|' '{ print $11 }' | xargs)
							local LOCALIDADE=$(echo "${NUMBER}" | awk -F '|' '{ print $12 }' | xargs)
							local OUTROS=$(echo "${NUMBER}" | awk -F '|' '{ print $13 }' | xargs)

							local ABSOLUTE_FILE_NAME='/opt/leucotron/confirmaNode/call/'$(date +"%d%m%Y%H%M%S")_${TEL_1}'.call'
							echo "Channel: Local/${TEL_1}@outbound-call"			> ${ABSOLUTE_FILE_NAME}
							echo "Callerid: "5999" 5999"							>> ${ABSOLUTE_FILE_NAME}
							echo "MaxRetries: 0"									>> ${ABSOLUTE_FILE_NAME}
							echo "WaitTime: 180"									>> ${ABSOLUTE_FILE_NAME}
							echo "Context: inbound-call"							>> ${ABSOLUTE_FILE_NAME}
							echo "Extension: ${TEL_1}"								>> ${ABSOLUTE_FILE_NAME}
							echo "Priority: 1"										>> ${ABSOLUTE_FILE_NAME}
							echo "Set: ID=${ID}"									>> ${ABSOLUTE_FILE_NAME}
							echo "Set: ID_CONSULTA=${ID_CONSULTA}"					>> ${ABSOLUTE_FILE_NAME}
							echo "Set: DATA_HORA_CONSULTA=${DATA_HORA_CONSULTA}"	>> ${ABSOLUTE_FILE_NAME}
							echo "Set: PACIENTE_ID=${PACIENTE_ID}"					>> ${ABSOLUTE_FILE_NAME}
							echo "Set: PACIENTE_NOME=${PACIENTE_NOME}"				>> ${ABSOLUTE_FILE_NAME}
							echo "Set: TEL_1_ORIGINAL=${TEL_1_ORIGINAL}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: TEL_2_ORIGINAL=${TEL_2_ORIGINAL}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: MED_ID=${MED_ID}"							>> ${ABSOLUTE_FILE_NAME}
							echo "Set: MED_NOME=${MED_NOME}"						>> ${ABSOLUTE_FILE_NAME}
							echo "Set: ESPECIALIDADE=${ESPECIALIDADE}"				>> ${ABSOLUTE_FILE_NAME}
							echo "Set: PROCEDIMENTO=${PROCEDIMENTO}"				>> ${ABSOLUTE_FILE_NAME}
							echo "Set: LOCALIDADE=${LOCALIDADE}"					>> ${ABSOLUTE_FILE_NAME}
							echo "Set: OUTROS=${OUTROS}"							>> ${ABSOLUTE_FILE_NAME}
							echo "Set: TEL_1=${TEL_1}"								>> ${ABSOLUTE_FILE_NAME}
							echo "Set: TEL_2=${TEL_2}"								>> ${ABSOLUTE_FILE_NAME}
							echo "Set: CONT=${CONT}"								>> ${ABSOLUTE_FILE_NAME}
							echo "Set: STATUS=${STATUS}"							>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_INFORMA=${AUDIO_INFORMA}"				>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_CONFIRMA=${AUDIO_CONFIRMA}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_TENTATIVAS=${AUDIO_TENTATIVAS}"		>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_AGRADECE=${AUDIO_AGRADECE}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_NOVAMENTE=${AUDIO_NOVAMENTE}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_INVALIDA=${AUDIO_INVALIDA}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_CONFIRMADA=${AUDIO_CONFIRMADA}"		>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_AGRADECE_PART=${AUDIO_AGRADECE_PART}"	>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_CANCELADA=${AUDIO_CANCELADA}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_REAGENDAR=${AUDIO_REAGENDAR}"			>> ${ABSOLUTE_FILE_NAME}
							echo "Set: AUDIO_ALO=${AUDIO_ALO}"						>> ${ABSOLUTE_FILE_NAME}
							#echo "Set: DIALSTATUS=ANSWER"							>> ${ABSOLUTE_FILE_NAME}
							echo "Archive: yes"										>> ${ABSOLUTE_FILE_NAME}
#							echo "$(date +"%d-%m-%Y_%H:%M:%S") Chamando ${TEL_1}"	>> /opt/leucotron/log/confirmaConsulta.log
							mv ${ABSOLUTE_FILE_NAME} /var/spool/asterisk/outgoing/

							#Atualiza o numero de discagem realizada para o contato em questao
							echo "UPDATE ${DBTABLECONTATO} SET contato_cont_discagem = contato_cont_discagem +  1, contato_data_hora_discagem = now() WHERE contato_id = '${ID}';" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null

							#sleep usado para otimizar o processo de discagem para segundo tel. Tentando evitar congestion qnd usa Neogate
							sleep 10

						#Fim testa intervalo de hora da discagem ou se primeira discagem
						fi
					#Fim testa qtd digito telefones
					fi
				else
					sleep 30
				#Fim testa num de canais
				fi
			else
				echo "UPDATE ${DBTABLECONTATO} SET contato_ativado = FALSE;" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
				break
			#Fim testa horario de discagem
			fi
		else
			break
		#Fim testa ultimo contato da lista
		fi
	#Fim While le tb contato da base local
	done	
#podemos trabalhar com mecanimso de retorno para cada situacao e tratar caso a caso.
#ex: r=10 fim dos contatos, r=11 fora do horario...
}

main(){
	case "${OPCAO}" in
		start)
			#sleep 120

			while :
			do
				local FERIADO=$(validaFeriado)
				sleep 1
				if [ "${FERIADO}" -eq 0 ]
				then
					local DIA_HORA=$(validaDiaHora)
					sleep 1
					if [ "${DIA_HORA}" -eq 1 ]
					then
						populaTabelaContato
						coreDial
					else
						sleep 300
					#Fim testa se dia e horario de discagem
					fi
				else
					sleep 300
				#Fim testa se feriado
				fi
			#Fim While true.
			done & echo $! > /opt/leucotron/confirmaNode/.pid	
			if [ $? -ne 0 ]
			then
				echo "Programa não pode ser inicializado! Verifique se esta executando como root."
				sudo kill -9 `ps -aux | egrep dialer.sh | awk '{ print $2 }'| grep -v PID`
				exit
			fi
		;;
		stop)
			local DATA=$(echo "$(date +%Y-%m-%d)")
			local TOTAL=$(echo "SELECT * FROM ${DBTABLECONTATO} WHERE data_hora::DATE = '${DATA}';"| psql -t -d ${DBNAME} -U ${DBUSER})
			#-z testa se retorno == null
			if [ -z "${TOTAL}" ]
			then
				echo "UPDATE ${DBTABLECONTATO} SET contato_ativado = FALSE;" | psql -d ${DBNAME} -U ${DBUSER} >> /dev/null
			fi
			rm /opt/leucotron/confirmaNode/.pid >> /dev/null
		#	sudo pkill -f dialer.sh
			sudo kill -9 `ps -aux | egrep dialer.sh | awk '{ print $2 }'| grep -v PID`
		;;
		*)
			echo "Use start|stop"
			exit 0
		;;
	esac
}

main
