﻿-------------------------------------------------------------------------------------------
INSERT INTO contato(
	    contato_consulta_id, contato_consulta_data_hora, 
            contato_paciente_id, contato_paciente_nome, contato_paciente_tel1, 
            contato_paciente_tel2, contato_medico_id, contato_medico_nome, 
            contato_especialidade, contato_procedimento, contato_localidade, 
            contato_outros)
    VALUES ('1', '2018-11-20 08:00:00',
	    '100','Evaldo de Oliveira','(35)9 9159-6272',
	    '(35)3471-9553','200','Verner',
	    '','','',
	    '');

INSERT INTO cdr(
            contato_fk, cdr_tel_discado, cdr_status_chamada, 
            cdr_status_consulta, cdr_tipo)
    VALUES (1, '0035991596272', 'BUSY', 
            'AGENDADA', 'MACHINE');

INSERT INTO cdr(
            contato_fk, cdr_tel_discado, cdr_status_chamada, 
            cdr_status_consulta, cdr_tipo)
    VALUES (1, '003534719553', 'ANSWER', 
            'CONFIRMADA', 'HUMAN');
---------------------------------------------------------------------------------------
INSERT INTO contato(
	    contato_consulta_id, contato_consulta_data_hora, 
            contato_paciente_id, contato_paciente_nome, contato_paciente_tel1, 
            contato_paciente_tel2, contato_medico_id, contato_medico_nome, 
            contato_especialidade, contato_procedimento, contato_localidade, 
            contato_outros)
    VALUES ('2', '2018-11-25 09:30:00',
	    '101','Juliana Faria','(35)9 8888-9999',
	    '(35)3274-1111','201','Andiara',
	    '','','',
	    '');

INSERT INTO cdr(
            contato_fk, cdr_tel_discado, cdr_status_chamada, 
            cdr_status_consulta, cdr_tipo)
    VALUES (2, '0035988889999', 'NOANSWER', 
            'AGENDADA', '');

INSERT INTO cdr(
            contato_fk, cdr_tel_discado, cdr_status_chamada, 
            cdr_status_consulta, cdr_tipo)
    VALUES (2, '003532741111', 'BUSY', 
            'REAGENDADA', '');

INSERT INTO cdr(
            contato_fk, cdr_tel_discado, cdr_status_chamada, 
            cdr_status_consulta, cdr_tipo)
    VALUES (2, '0035988889999', 'ANSWER', 
            'CANCELADA', 'HUMAN');
------------------------------------------------------------------------
INSERT INTO contato(
	    contato_consulta_id, contato_consulta_data_hora, 
            contato_paciente_id, contato_paciente_nome, contato_paciente_tel1, 
            contato_paciente_tel2, contato_medico_id, contato_medico_nome, 
            contato_especialidade, contato_procedimento, contato_localidade, 
            contato_outros)
    VALUES ('3', '2018-11-22 11:50:00',
	    '103','Evandro de Oliveira','(35)9 9999-8888',
	    '(35)3271-1000','203','Davi',
	    '','','',
	    '');
-------------------------------------------------------------------------------
INSERT INTO log(log_data_hora_exe_query, log_total_consultas) VALUES ('2019-03-14 08:40:20',590);
SELECT COUNT(cdr_status_consulta) as canceladas FROM cdr WHERE cdr_status_consulta = 'CANCELADA'

INSERT INTO configuracao (conf_num_tentativa, conf_intervalo_discagem, conf_chamadas_simultaneas, conf_dias_antes, conf_cod_tomada_linha, conf_csp, conf_amd)
VALUES (4, 2, 3, 2, 15, 15, false);

SELECT * FROM configuracao WHERE conf_id = 1;
SELECT * FROM configuracao;
-------------------------------------------------------------------------------

--SELECT  * FROM cdr AS c LEFT JOIN contato AS cont ON cont.contato_id = c.contato_fk ORDER BY cdr_id DESC
--tela de listagem cdr
SELECT cdr_id, contato_consulta_data_hora, contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, 
contato_especialidade, contato_procedimento, contato_outros, contato_cont_discagem,
cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo
 FROM cdr AS c LEFT JOIN contato AS cont ON cont.contato_id = c.contato_fk ORDER BY cdr_id DESC LIMIT 10 OFFSET 0
--SELECT  * FROM contato AS cont LEFT JOIN cdr AS c ON c.contato_fk = cont.contato_id ORDER BY cdr_id DESC
--tela de listagem dos contatos
SELECT DISTINCT ON (contato_id) contato_id, cdr_id, contato_consulta_data_hora, contato_paciente_nome, contato_paciente_tel1, contato_paciente_tel2, contato_medico_nome, 
contato_especialidade, contato_procedimento, contato_outros, contato_cont_discagem,
cdr_data_hora_chamada, cdr_tel_discado, cdr_status_chamada, cdr_status_consulta, cdr_tipo
FROM contato AS cont LEFT JOIN cdr AS c ON c.contato_fk = cont.contato_id ORDER BY contato_id, cdr_id DESC LIMIT 10 OFFSET 0

