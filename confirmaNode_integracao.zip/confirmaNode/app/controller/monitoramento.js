const exec = require('child_process').exec;
const si = require('systeminformation');

module.exports = {
    select: (req, res) => {
        si.fsSize(function (data) {
            var object = new Object()
            for (let i = 0; i < data.length; i++) {
                if (object.system === undefined || (data[i].type === 'ext4'
                    && object.system.size < data[i].size)) {
                    object.system = data[i]
                }
            }
            var infoSystem = {
                fs: object.system.fs,
                type: object.system.type,
                size: bytesToSize(object.system.size),
                used: bytesToSize(object.system.used),
                use: object.system.use,
                mount: object.system.mount,
                free: bytesToSize(object.system.size) - bytesToSize(object.system.used)
            }
            res.status(200).send(infoSystem);
        });

    },
    selectAsterisk: (req, res) => {
        var numberOfChannels;
        var returnJson;

        //Executar comando no bash do servidor para obter a quantidade exata de canais de comunicação
        var commandForObtainNumberOfChannels = 'sudo asterisk -rx "group show channels DISCADOR" | egrep "active" | awk' +
            " '{ print $1 }'";
        //Execução do comando e guardado o numero de canais para utilzar posteriormente
        execute(commandForObtainNumberOfChannels, (error, stdout) => {
            numberOfChannels = stdout;
        });

        //Executar comando no bash do servidor para obter os numeros que estao sendo discados no momento
        var commandForObtainChannels = 'sudo asterisk -rx "group show channels DISCADOR" | egrep "DISCADOR"' +
            "| awk '{ print $1 }' | cut -d '/' -f2 | cut -d '@' -f1";
        //Execução do comando e montando o arquivo JSON que sera enviado como resposta para o front-end
        execute(commandForObtainChannels, (error, stdout) => {
            var strin = String(stdout);
            returnJson = {
                numberOfChannels: numberOfChannels.split("\n")[0],
                numbers: strin.split("\n")
            }
            res.status(200).send(returnJson);
        });
    }
}

function bytesToSize(bytes) {
    if (bytes == 0) return 0;
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2);
};

function execute(command, callback) {
    exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};