const pg = require('../db');
const exec = require('child_process').exec;
var houveAlteracaoEstatico = 0;
// Requiring fs module in which 
// writeFile function is defined. 
const fs = require('fs')
var igual = 0;

module.exports = {
  select: (req, res) => {
    pg.query('SELECT audio_informa, audio_confirma, audio_tentativas, ' +
      'audio_agradece, audio_novamente, audio_invalida, ' +
      'audio_confirmada, audio_agradece_part, audio_cancelada, audio_reagendar, audio_alo FROM audio', [], (err, ans) => {
        if (err) {
          return res.status(500).send({
            error: 'Erro interno',
            message: 'Erro ao selecionar dados no servidor'
          });
        } else {
          if (ans.rowCount > 0) {
            fs.readFile(__dirname + '/alteracaoAudios.txt', (err, data) => {
              return res.send({
                rows: ans.rows,
                houveAlteracao: parseInt(data)
              });
            });

          } else {
            return res.status(500).send({
              message: 'Nenhum arquivo de áudio no servidor'
            });
          }
        }
      });
  },

  insert: async (req, res) => {
    files = req.files;
    filesName = req.body;

    if (!files) {
      return res.status(400).send({
        error: 'Missing audios',
        message: 'Nenhum áudio enviado'
      });
    }

    var { rows } = await pg.queryAsync('SELECT COUNT(*) FROM audio;');

    if (rows[0].count < 1) {
      if (files.audios.length == 11) {
        values = []
        for (var i = 0; i < files.audios.length; i++) {
          values.push(files.audios[i].name.split('.')[0]);
          try {
            //await files.audios[i].mv('/home/filipefirmino/Music/sounds/' + files.audios[i].name)
            await files.audios[i].mv('/opt/leucotron/confirmaNode/sounds/' + files.audios[i].name)
          } catch (error) {
            console.log("\nErro 1: " + error);
            return res.status(500).send({
              error: 'Upload file',
              message: 'Erro ao gravar áudio no servidor'
            });
          }
        }

        try {
          var { rows } = await pg.queryAsync('INSERT INTO audio(audio_informa, audio_confirma, audio_tentativas, ' +
            'audio_agradece, audio_novamente, audio_invalida, ' +
            'audio_confirmada, audio_agradece_part, audio_cancelada, audio_reagendar, audio_alo) ' +
            'VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);', values);

          execute('sudo converteAudio.sh', (stdout) => { });
          //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
          return res.status(200).send({
            success: 'Configurado',
            message: 'Áudios configurados com sucesso'
          });
        } catch (error) {
          console.log("\nErro 2: " + error);
          return res.status(500).send({
            error: 'Upload file',
            message: 'Erro ao gravar áudio no servidor'
          });
        }

      } else {
        return res.status(400).send({
          error: 'First submit',
          message: 'Na primeira utilização é necessário enviar todos os áudios'
        });
      }
    } else {

      //Try-Catch para verificar se existe algum áudio no banco de dados com o mesmo nome vindo do front-end
      try {
        //Caso tenha sido feito o upload de 1 arquivo apenas
        if (files.audios.length === undefined) {
          var igual = await analisarNomesIguais(files.audios.name.split('.')[0], 0, files);

          if (igual.igual) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Nome do áudio: ' + igual.nomeAudio + ', já existe no banco de dados.'
            });
          }
        } else {
          //Caso tenha sido feito o upload de mais de 1 arquivo no front-end
          //files.audios[0].name.split('.')[0] neste caso é apenas para não deixar nulo o parametro, já que não é usado
          var igual = await analisarNomesIguais(files.audios[0].name.split('.')[0], 1, files);

          if (igual.igual) {
            return res.status(500).send({
              error: 'Erro interno',
              message: 'Nome do áudio: ' + igual.nomeAudio + ', já existe no banco de dados.'
            });
          }
        }
      } catch (error) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao validar o nome do áudio no banco de dados (122)'
        });
      }

      var houveAlteracao = await analyzeReturn(files.audios, filesName);
      arquivoTxt(houveAlteracao);

      try {
        //Query para alterar os nomes no BD
        var sql = await buildQuery(files.audios, filesName, res);

        var { rows } = await pg.query(sql);

        if (files.audios.length === undefined) {
          try {
            await files.audios.mv('/opt/leucotron/confirmaNode/sounds/' + files.audios.name)
            //await files.audios.mv('/home/filipefirmino/Music/sounds/' + files.audios.name)
          } catch (error) {
            console.log("\nErro 3: " + error);
            return res.status(500).send({
              error: 'Upload file',
              message: 'Erro ao gravar áudio no servidor'
            })
          }
        } else {
          for (var i = 0; i < files.audios.length; i++) {
            try {
              await files.audios[i].mv('/opt/leucotron/confirmaNode/sounds/' + files.audios[i].name)
              //await files.audios[i].mv('/home/filipefirmino/Music/sounds/' + files.audios[i].name)
            } catch (error) {
              console.log("\nErro 4: " + error);
              return res.status(500).send({
                error: 'Upload file',
                message: 'Erro ao gravar áudio no servidor'
              });
            }
          }
        }
        execute('sudo converteAudio.sh', (error, stdout) => { });
        //execute('sudo /etc/init.d/dialer restart', (stdout) => { })
        fs.readFile(__dirname + '/alteracaoAudios.txt', (err, data) => {
          return res.status(200).send({
            success: 'Configurado',
            message: 'Áudio(s) configurado(s) com sucesso',
            houveAlteracao: parseInt(data)
          });
        });
      } catch (err) {
        return res.status(500).send({
          error: 'Erro interno',
          message: 'Erro ao validar o nome do áudio no banco de dados'
        });
      }
    }
  },

  restart: (req, res) => {
    try {
      execute('sudo dialer.sh start', (error, stdout) => { });

      setTimeout(() => {
        houveAlteracaoEstatico = 0;
        arquivoTxt(houveAlteracaoEstatico);
        res.status(200).send()
      }, 2500);
    } catch (error) {
      console.log(error);
      return res.status(500).send({
        error: 'Erro interno',
        message: 'Erro interno ao reiniciar o servidor.'
      });
    }
  }
}

async function buildQuery(files, filesName, res) {
  var query = null;
  query = 'UPDATE audio SET '

  if (files.length === undefined) {
    query += `${filesName[files.name]} = '${files.name.split('.')[0]}' `

  } else {
    for (var i = 0; i < files.length; i++) {
      if (i < (files.length - 1)) {
        query += `${filesName[files[i].name]} = '${files[i].name.split('.')[0]}', `
      } else {
        query += `${filesName[files[i].name]} = '${files[i].name.split('.')[0]}' `
      }
    }
  }
  return query + 'WHERE audio_id = 1';
}

async function analisarNomesIguais(valueFrontOne, qtdFront, files) {
  //Mapas para auxilio de comparação dos nomes
  var mapBackEnd = new Map();
  var mapFront = new Map();

  //Variavel de controle para informar se existe igualdade entre o que tem no front-end e back-end
  var igual = null;

  //Variavel para saber o nome do áudio que está igual e mostrar para o usuário
  var nomeAudio;

  //Query para trazer os nomes dos audios e comparar com o que veio do front-end
  var query = 'SELECT * FROM audio;'
  var { rows } = await pg.query(query);

  try {
    //Mapa dos dados do BD para ficar fácil a consulta
    mapBackEnd.set(0, rows[0].audio_informa);
    mapBackEnd.set(1, rows[0].audio_confirma);
    mapBackEnd.set(2, rows[0].audio_tentativas);
    mapBackEnd.set(3, rows[0].audio_agradece);
    mapBackEnd.set(4, rows[0].audio_novamente);
    mapBackEnd.set(5, rows[0].audio_invalida);
    mapBackEnd.set(6, rows[0].audio_confirmada);
    mapBackEnd.set(7, rows[0].audio_agradece_part);
    mapBackEnd.set(8, rows[0].audio_cancelada);
    mapBackEnd.set(9, rows[0].audio_reagendar);
    mapBackEnd.set(10, rows[0].audio_alo);

    //Se somente 1( o que é marco) um áudio foi enviado e é preciso analisar o nome dele com todos que tem no banco
    if (qtdFront == 0) {
      for (var valueBack of mapBackEnd.values()) {
        if (valueBack == valueFrontOne) {
          igual = true;
          nomeAudio = valueFrontOne;
        }
      }
      //Caso mais de 1 áudio tenha sido enviado, então será analisados de todos para todos os nomes
    } else if (qtdFront == 1) {

      //Preencher o mapa de nome vindo do Front-end
      for (var i = 0; i < files.audios.length; i++) {
        mapFront.set(i, files.audios[i].name.split('.')[0]);
      }

      //Verificando os nomes
      for (var valueBack of mapBackEnd.values()) {
        for (var valueFront of mapFront.values()) {

          if (valueBack == valueFront) {
            igual = true;
            nomeAudio = valueFront;
          }
        }
      }
    }

    //Retorna para o método principal se existiu algum match
    return { igual: igual, nomeAudio: nomeAudio };

  } catch (error) {
    res.status(500).send({
      error: 'Erro interno',
      message: 'Erro ao validar o nome do áudio no banco de dados'
    });
  }
}

function execute(command, callback) {
  exec(command, function (error, stdout, stderr) { callback(error, stdout); });
};

async function analyzeReturn(files, filesName) {
  //Query para trazer os nomes dos audios e comparar com o que veio do front-end
  var queryConferencia = 'SELECT * FROM audio;'
  var { rows } = await pg.query(queryConferencia);
  var houveAlteracao = 0;

  if (files.length === undefined) {
    //Quando um arquivo somente foi manipulado
    var audioFrontEnd = String(filesName[files.name]);
    var dadoFrontEnd = String(files.name.split('.')[0]);

    houveAlteracao = audioSwitch(audioFrontEnd, houveAlteracao, rows, dadoFrontEnd);

  } else {
    for (var i = 0; i < files.length; i++) {
      //Quando mais de um arquivo de audio foi manipulado no Front-end
      var audioFrontEnd = String(filesName[files[i].name]);
      var dadoFrontEnd = String(files[i].name.split('.')[0]);

      houveAlteracao = audioSwitch(audioFrontEnd, houveAlteracao, rows, dadoFrontEnd);
    }
  }
  return houveAlteracao;
}

function audioSwitch(audioFrontEnd, houveAlteracao, rows, dadoFrontEnd) {
  switch (audioFrontEnd) {
    case 'audio_informa':
      if (rows[0].audio_informa != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_confirma':
      if (rows[0].audio_confirma != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_tentativas':
      if (rows[0].audio_tentativas != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_agradece':
      if (rows[0].audio_agradece != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_novamente':
      if (rows[0].audio_novamente != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_invalida':
      if (rows[0].audio_invalida != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_confirmada':
      if (rows[0].audio_confirmada != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_agradece_part':
      if (rows[0].audio_agradece_part != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_cancelada':
      if (rows[0].audio_cancelada != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_reagendar':
      if (rows[0].audio_reagendar != dadoFrontEnd)
        houveAlteracao = 1;
      break

    case 'audio_alo':
      if (rows[0].audio_alo != dadoFrontEnd)
        houveAlteracao = 1;
      break
  }
  return houveAlteracao;
}

function arquivoTxt(houveAlteracao) {
  fs.open(__dirname + '/alteracaoAudios.txt', 'wx', (err, fd) => {
    if (err) {
      if (err.code === 'EEXIST') {
        fs.unlink(__dirname + '/alteracaoAudios.txt', function (err) {
          if (err) throw err;
          return;
        });
        fs.appendFile(__dirname + '/alteracaoAudios.txt', houveAlteracao, (err) => {
          if (err) throw err;
        });
      } else if (err.code === 'ENOENT') {
        fs.appendFile(__dirname + '/alteracaoAudios.txt', houveAlteracao, (err) => {
          if (err) throw err;
          return;
        });
      }
    }
  });
}