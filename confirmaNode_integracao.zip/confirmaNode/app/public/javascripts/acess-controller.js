function sendCredentials() {

    var username = document.getElementById('inputUsername').value;
    var password = document.getElementById('inputPassword').value;
    var alert = document.getElementById('red-alert');

    alert.style.visibility = 'none'

    if (username == '' || password == '') {
        return;
    }

    var object = new Object();
    object.username = username;
    object.password = password;

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 400:
                    break;

                case 401:
                    alertSwal('Usuário ou senha inválidos');
                    break;

                case 500:
                    alertSwal('Erro interno com o servidor');
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor');
                    break;

                case 200:
                    window.open("/", "_self");
                    break;
                default:
                    alertSwal('Erro inesperado, contate o administrador');
            }
        }
    }

    xhttp.open("POST", '/users/signin', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
}

function alertSwal(message) {
    swal({
        title: "Ops :(",
        text: message,
        type: "error"
    });
}