function atualizarGraficos(json) {
    //Mostrar data no front-end para o usuário ter a opções de filtro.
    var date = new Date();
    $('#dataFiltroDashboard').val((date.getDate() < 10 ? '0' : '') + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : '') + "/" + date.getFullYear());

    //Confirmadas, canceladas, reagendadas -----------------------------------------------------------------
    var barData = {
        labels: ["Confirmadas", "Canceladas", "Reagendadas"],
        datasets: [
            {
                label: "Total",
                backgroundColor: 'rgba(26,179,148,0.5)',
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [json.confirmadas, json.canceladas, json.reagendadas]
            }
        ]
    };

    var barOptions = {
        responsive: true
    };

    var ctx1 = document.getElementById("barConfirmadasCanceladasReagendadas").getContext("2d");
    new Chart(ctx1, { type: 'bar', data: barData, options: barOptions });

    //Preencher informações dos contadores na tela
    $('#totalConsultasConfirmar').val(json.consultasAConfirmar);
    $('#totalDiscagensRestantes').val(json.restantes);
    $('#totalDiscagensRealizadas').val(json.discagemRealizadas);
    $('#totalConfirmadas').val(json.confirmadas);
    $('#totalReagendadas').val(json.reagendadas);
    $('#totalCanceladas').val(json.canceladas);
};

function buscaInfo() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/monitoramento-dashboard')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    atualizarGraficos(JSON.parse(this.response).retornoJson);
                    break;
                case 304:
                    atualizarGraficos(JSON.parse(this.response).retornoJson);
                    break;
                case 400:
                    atualizarGraficos(JSON.parse(this.response).retornoJson);
                    break;
                case 500:
                    //alertSwal(JSON.parse(this.response).message);
                    break;

                default:
                    //alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }
    xhttp.send()
}

function alertSwal(message) {
    swal({
        title: "Ops :(",
        text: message,
        type: "error",
        showConfirmButton: true
    });
}