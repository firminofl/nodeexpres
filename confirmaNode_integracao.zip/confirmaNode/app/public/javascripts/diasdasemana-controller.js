function validarCampos() {
    //Variaveis---------------------------------
    //Segunda-feira
    var horaInicioSegundaFeira = $('#horaInicioSegundaFeira').val();
    var horaFimSegundaFeira = $('#horaFimSegundaFeira').val();
    var ativoSegundaFeira;

    //Terça-feira
    var horaInicioTercaFeira = $('#horaInicioTercaFeira').val();
    var horaFimTercaFeira = $('#horaFimTercaFeira').val();
    var ativoTercaFeira;

    //Quarta-feira
    var horaInicioQuartaFeira = $('#horaInicioQuartaFeira').val();
    var horaFimQuartaFeira = $('#horaFimQuartaFeira').val();
    var ativoQuartaFeira;

    //Quinta-feira
    var horaInicioQuintaFeira = $('#horaInicioQuintaFeira').val();
    var horaFimQuintaFeira = $('#horaFimQuintaFeira').val();
    var ativoQuintaFeira;

    //Sexta-feira
    var horaInicioSextaFeira = $('#horaInicioSextaFeira').val();
    var horaFimSextaFeira = $('#horaFimSextaFeira').val();
    var ativoSextaFeira;

    //Sábado
    var horaInicioSabado = $('#horaInicioSabado').val();
    var horaFimSabado = $('#horaFimSabado').val();
    var ativoSabado;

    //Domingo
    var horaInicioDomingo = $('#horaInicioDomingo').val();
    var horaFimDomingo = $('#horaFimDomingo').val();
    var ativoDomingo;
    //Fim Variaveis-----------------------------

    //Validar todos os campos de uma vez
    if (horaInicioSegundaFeira.length == 0 && horaFimSegundaFeira.length == 0
        && horaInicioTercaFeira.length == 0 && horaFimTercaFeira.length == 0
        && horaInicioQuartaFeira.length == 0 && horaFimQuartaFeira.length == 0
        && horaInicioQuintaFeira.length == 0 && horaFimQuintaFeira.length == 0
        && horaInicioSextaFeira.length == 0 && horaFimSextaFeira.length == 0
        && horaInicioSabado.length == 0 && horaFimSabado.length == 0
        && horaInicioDomingo.length == 0 && horaFimDomingo.length == 0) {
        return alertSwal('Nenhum campo preenchido, por favor preencha-os!');
    }

    //Segunda-feira ------------------------------------------------------------------------------------
    if ($('#checkboxSegundaFeira').is(':checked')) {
        ativoSegundaFeira = 'true';
        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioSegundaFeira.length == 0 && horaFimSegundaFeira.length == 0) {
            return alertSwal('Os horários de segunda-feira não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioSegundaFeira.length != 0 && horaFimSegundaFeira.length == 0) {
            return alertSwal('Os horários de segunda-feira não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioSegundaFeira.length == 0 && horaFimSegundaFeira.length != 0) {
            return alertSwal('Os horários de segunda-feira não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioSegundaFeira = horaInicioSegundaFeira.split(':')[0] + horaInicioSegundaFeira.split(':')[1];
        horaFimSegundaFeira = horaFimSegundaFeira.split(':')[0] + horaFimSegundaFeira.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioSegundaFeira >= horaFimSegundaFeira) {
            return alertSwal('Hora fim de segunda-feira é menor ou igual à hora início.');
        }
    } else {
        ativoSegundaFeira = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioSegundaFeira = horaInicioSegundaFeira.split(':')[0] + horaInicioSegundaFeira.split(':')[1];
        horaFimSegundaFeira = horaFimSegundaFeira.split(':')[0] + horaFimSegundaFeira.split(':')[1];
    }
    //Fim Segunda-feira ------------------------------------------------------------------------------------

    //Terça-feira ------------------------------------------------------------------------------------
    if ($('#checkboxTercaFeira').is(':checked')) {
        ativoTercaFeira = 'true';

        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioTercaFeira.length == 0 && horaFimTercaFeira.length == 0) {
            return alertSwal('Os horários de terça-feira não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioTercaFeira.length != 0 && horaFimTercaFeira.length == 0) {
            return alertSwal('Os horários de terça-feira não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioTercaFeira.length == 0 && horaFimTercaFeira.length != 0) {
            return alertSwal('Os horários de terça-feira não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioTercaFeira = horaInicioTercaFeira.split(':')[0] + horaInicioTercaFeira.split(':')[1];
        horaFimTercaFeira = horaFimTercaFeira.split(':')[0] + horaFimTercaFeira.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioTercaFeira >= horaFimTercaFeira) {
            return alertSwal('Hora fim de terça-feira é menor ou igual à hora início.');
        }
    } else {
        ativoTercaFeira = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioTercaFeira = horaInicioTercaFeira.split(':')[0] + horaInicioTercaFeira.split(':')[1];
        horaFimTercaFeira = horaFimTercaFeira.split(':')[0] + horaFimTercaFeira.split(':')[1];
    }
    //Fim Terça-feira ------------------------------------------------------------------------------------

    //Quarta-feira ------------------------------------------------------------------------------------
    if ($('#checkboxQuartaFeira').is(':checked')) {
        ativoQuartaFeira = 'true';

        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioQuartaFeira.length == 0 && horaFimQuartaFeira.length == 0) {
            return alertSwal('Os horários de quarta-feira não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioQuartaFeira.length != 0 && horaFimQuartaFeira.length == 0) {
            return alertSwal('Os horários de quarta-feira não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioQuartaFeira.length == 0 && horaFimQuartaFeira.length != 0) {
            return alertSwal('Os horários de quarta-feira não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioQuartaFeira = horaInicioQuartaFeira.split(':')[0] + horaInicioQuartaFeira.split(':')[1];
        horaFimQuartaFeira = horaFimQuartaFeira.split(':')[0] + horaFimQuartaFeira.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioQuartaFeira >= horaFimQuartaFeira) {
            return alertSwal('Hora fim de quarta-feira é menor ou igual à hora início.');
        }
    } else {
        ativoQuartaFeira = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioQuartaFeira = horaInicioQuartaFeira.split(':')[0] + horaInicioQuartaFeira.split(':')[1];
        horaFimQuartaFeira = horaFimQuartaFeira.split(':')[0] + horaFimQuartaFeira.split(':')[1];
    }
    //Fim Quarta-feira ------------------------------------------------------------------------------------

    //Quinta-feira ------------------------------------------------------------------------------------
    if ($('#checkboxQuintaFeira').is(':checked')) {
        ativoQuintaFeira = 'true';

        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioQuintaFeira.length == 0 && horaFimQuintaFeira.length == 0) {
            return alertSwal('Os horários de quinta-feira não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioQuintaFeira.length != 0 && horaFimQuintaFeira.length == 0) {
            return alertSwal('Os horários de quinta-feira não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioQuintaFeira.length == 0 && horaFimQuintaFeira.length != 0) {
            return alertSwal('Os horários de quinta-feira não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioQuintaFeira = horaInicioQuintaFeira.split(':')[0] + horaInicioQuintaFeira.split(':')[1];
        horaFimQuintaFeira = horaFimQuintaFeira.split(':')[0] + horaFimQuintaFeira.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioQuintaFeira >= horaFimQuintaFeira) {
            return alertSwal('Hora fim de quinta-feira é menor ou igual à hora início.');
        }
    } else {
        ativoQuintaFeira = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioQuintaFeira = horaInicioQuintaFeira.split(':')[0] + horaInicioQuintaFeira.split(':')[1];
        horaFimQuintaFeira = horaFimQuintaFeira.split(':')[0] + horaFimQuintaFeira.split(':')[1];
    }
    //Fim Quinta-feira ------------------------------------------------------------------------------------

    //Sexta-feira ------------------------------------------------------------------------------------
    if ($('#checkboxSextaFeira').is(':checked')) {
        ativoSextaFeira = 'true';

        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioSextaFeira.length == 0 && horaFimSextaFeira.length == 0) {
            return alertSwal('Os horários de sexta-feira não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioSextaFeira.length != 0 && horaFimSextaFeira.length == 0) {
            return alertSwal('Os horários de sexta-feira não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioSextaFeira.length == 0 && horaFimSextaFeira.length != 0) {
            return alertSwal('Os horários de sexta-feira não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioSextaFeira = horaInicioSextaFeira.split(':')[0] + horaInicioSextaFeira.split(':')[1];
        horaFimSextaFeira = horaFimSextaFeira.split(':')[0] + horaFimSextaFeira.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioSextaFeira >= horaFimSextaFeira) {
            return alertSwal('Hora fim de sexta-feira é menor ou igual à hora início.');
        }
    } else {
        ativoSextaFeira = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioSextaFeira = horaInicioSextaFeira.split(':')[0] + horaInicioSextaFeira.split(':')[1];
        horaFimSextaFeira = horaFimSextaFeira.split(':')[0] + horaFimSextaFeira.split(':')[1];
    }
    //Fim Sexta-feira ------------------------------------------------------------------------------------

    //Sabado ------------------------------------------------------------------------------------
    if ($('#checkboxSabado').is(':checked')) {
        ativoSabado = 'true';

        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioSabado.length == 0 && horaFimSabado.length == 0) {
            return alertSwal('Os horários de sábado não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioSabado.length != 0 && horaFimSabado.length == 0) {
            return alertSwal('Os horários de sábado não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioSabado.length == 0 && horaFimSabado.length != 0) {
            return alertSwal('Os horários de sábado não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioSabado = horaInicioSabado.split(':')[0] + horaInicioSabado.split(':')[1];
        horaFimSabado = horaFimSabado.split(':')[0] + horaFimSabado.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioSabado >= horaFimSabado) {
            return alertSwal('Hora fim de sábado é menor ou igual à hora início.');
        }
    } else {
        ativoSabado = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioSabado = horaInicioSabado.split(':')[0] + horaInicioSabado.split(':')[1];
        horaFimSabado = horaFimSabado.split(':')[0] + horaFimSabado.split(':')[1];
    }
    //Fim sabado ------------------------------------------------------------------------------------

    //Domingo ------------------------------------------------------------------------------------
    if ($('#checkboxDomingo').is(':checked')) {
        ativoDomingo = 'true';

        //Campo de hora inicio vazio e hora fim vazio
        if (horaInicioDomingo.length == 0 && horaFimDomingo.length == 0) {
            return alertSwal('Os horários de domingo não foram preenchidos.');
        }

        //Campo de hora inicio preenchido e hora fim vazio
        if (horaInicioDomingo.length != 0 && horaFimDomingo.length == 0) {
            return alertSwal('Os horários de domingo não foram preenchidos corretamente.');
        }

        //Campo de hora inicio vazio e hora fim preenchido
        if (horaInicioDomingo.length == 0 && horaFimDomingo.length != 0) {
            return alertSwal('Os horários de domingo não foram preenchidos corretamente.');
        }

        //Parametros sem os 2 pontos da hora
        horaInicioDomingo = horaInicioDomingo.split(':')[0] + horaInicioDomingo.split(':')[1];
        horaFimDomingo = horaFimDomingo.split(':')[0] + horaFimDomingo.split(':')[1];

        //Verificar se a hora inicio é maior que hora fim (NÃO PODE ACONTECER ISSO)
        if (horaInicioDomingo >= horaFimDomingo) {
            return alertSwal('Hora fim de domingo é menor ou igual à hora início.');
        }
    } else {
        ativoDomingo = 'false';
        //Parametros sem os 2 pontos da hora
        horaInicioDomingo = horaInicioDomingo.split(':')[0] + horaInicioDomingo.split(':')[1];
        horaFimDomingo = horaFimDomingo.split(':')[0] + horaFimDomingo.split(':')[1];
    }
    //Fim domingo ------------------------------------------------------------------------------------

    var object = {
        horaInicioSegundaFeira: horaInicioSegundaFeira,
        horaFimSegundaFeira: horaFimSegundaFeira,
        ativoSegundaFeira: ativoSegundaFeira,

        horaInicioTercaFeira: horaInicioTercaFeira,
        horaFimTercaFeira: horaFimTercaFeira,
        ativoTercaFeira: ativoTercaFeira,

        horaInicioQuartaFeira: horaInicioQuartaFeira,
        horaFimQuartaFeira: horaFimQuartaFeira,
        ativoQuartaFeira: ativoQuartaFeira,

        horaInicioQuintaFeira: horaInicioQuintaFeira,
        horaFimQuintaFeira: horaFimQuintaFeira,
        ativoQuintaFeira: ativoQuintaFeira,

        horaInicioSextaFeira: horaInicioSextaFeira,
        horaFimSextaFeira: horaFimSextaFeira,
        ativoSextaFeira: ativoSextaFeira,

        horaInicioSabado: horaInicioSabado,
        horaFimSabado: horaFimSabado,
        ativoSabado: ativoSabado,

        horaInicioDomingo: horaInicioDomingo,
        horaFimDomingo: horaFimDomingo,
        ativoDomingo: ativoDomingo
    }

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    if (JSON.parse(this.response).houveAlteracao == 0) {
                        setTimeout(() => {
                            atualizarDiasDaSemana();
                        }, 1500);

                    } else {
                        alertChangeInfo("Dados salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
                    }
                    break;

                case 304:
                    if (JSON.parse(this.response).houveAlteracao == 0) {
                        setTimeout(() => {
                            atualizarDiasDaSemana();
                        }, 1500);

                    } else {
                        alertChangeInfo("Dados salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
                    }
                    break;

                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor.');
                    break;

                default:
                    alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }

    xhttp.open("POST", '/diasdasemana/update', true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(object));
}

function atualizarDiasDaSemana() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', '/diasdasemana/select')

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    if (JSON.parse(this.response).houveAlteracao == 0) {
                        popularHorarios(JSON.parse(this.response).rows);
                    } else {
                        popularHorarios(JSON.parse(this.response).rows);
                        alertChangeInfo("Os dados já estão salvos no banco de dados!\nMas é necessário aplicar as alterações para que o sistema funcione de maneira adequeada.\n\nDeseja aplicar as configurações agora?");
                    }

                    break;
                case 304:
                    if (JSON.parse(this.response).houveAlteracao == 0) {
                        popularHorarios(JSON.parse(this.response).rows);
                    } else {
                        popularHorarios(JSON.parse(this.response).rows);
                        alertChangeInfo("Os dados já estão salvos, porém é necessário aplicá-los.\n\nDeseja aplicar as configurações agora?");
                    }
                    break;
                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;
                default:
                    alertSwal(JSON.parse(this.response).message);
                    break;
            }
        }
    }

    xhttp.send()
}

function popularHorarios(rows) {
    for (var i = 0; i < rows.length; i++) {
        //DOMINGO -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 0) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioDomingo').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioDomingo').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioDomingo').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioDomingo').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimDomingo').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimDomingo').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimDomingo').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimDomingo').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxDomingo').checked = true;
            } else {
                document.getElementById('checkboxDomingo').checked = false;
            }
        }
        //FIM DOMINGO -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //SEGUNDA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 1) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioSegundaFeira').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioSegundaFeira').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioSegundaFeira').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioSegundaFeira').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimSegundaFeira').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimSegundaFeira').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimSegundaFeira').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimSegundaFeira').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxSegundaFeira').checked = true;
            } else {
                document.getElementById('checkboxSegundaFeira').checked = false;
            }
        }
        //FIM SEGUNDA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //TERÇA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 2) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioTercaFeira').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioTercaFeira').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioTercaFeira').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioTercaFeira').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimTercaFeira').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimTercaFeira').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimTercaFeira').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimTercaFeira').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxTercaFeira').checked = true;
            } else {
                document.getElementById('checkboxTercaFeira').checked = false;
            }
        }
        //FIM TERÇA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //QUARTA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 3) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioQuartaFeira').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioQuartaFeira').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioQuartaFeira').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioQuartaFeira').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimQuartaFeira').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimQuartaFeira').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimQuartaFeira').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimQuartaFeira').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxQuartaFeira').checked = true;
            } else {
                document.getElementById('checkboxQuartaFeira').checked = false;
            }
        }
        //FIM QUARTA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //QUINTA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 4) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioQuintaFeira').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioQuintaFeira').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioQuintaFeira').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioQuintaFeira').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimQuintaFeira').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimQuintaFeira').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimQuintaFeira').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimQuintaFeira').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxQuintaFeira').checked = true;
            } else {
                document.getElementById('checkboxQuintaFeira').checked = false;
            }
        }
        //FIM QUINTA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //SEXTA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 5) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioSextaFeira').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioSextaFeira').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioSextaFeira').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioSextaFeira').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimSextaFeira').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimSextaFeira').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimSextaFeira').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimSextaFeira').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxSextaFeira').checked = true;
            } else {
                document.getElementById('checkboxSextaFeira').checked = false;
            }
        }
        //FIM SEXTA -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //SABADO -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        if (String(rows[i].dia_semana_dia) == 6) {
            //hora inicio
            if (String(rows[i].dia_semana_hora_ini).length == 1) {
                $('#horaInicioSabado').val('00:0' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 2) {
                $('#horaInicioSabado').val('00:' + String(rows[i].dia_semana_hora_ini));

            } else if (String(rows[i].dia_semana_hora_ini).length == 3) {
                $('#horaInicioSabado').val('0' + String(rows[i].dia_semana_hora_ini)[0] + ':' + String(rows[i].dia_semana_hora_ini)[1] + String(rows[i].dia_semana_hora_ini)[2]);

            } else if (String(rows[i].dia_semana_hora_ini).length == 4) {
                $('#horaInicioSabado').val(String(rows[i].dia_semana_hora_ini)[0] + String(rows[i].dia_semana_hora_ini)[1] + ":" + String(rows[i].dia_semana_hora_ini)[2] + String(rows[i].dia_semana_hora_ini)[3]);
            }

            //hora fim
            if (String(rows[i].dia_semana_hora_fim).length == 1) {
                $('#horaFimSabado').val('00:0' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 2) {
                $('#horaFimSabado').val('00:' + String(rows[i].dia_semana_hora_fim));

            } else if (String(rows[i].dia_semana_hora_fim).length == 3) {
                $('#horaFimSabado').val('0' + String(rows[i].dia_semana_hora_fim)[0] + ':' + String(rows[i].dia_semana_hora_fim)[1] + String(rows[i].dia_semana_hora_fim)[2]);

            } else if (String(rows[i].dia_semana_hora_fim).length == 4) {
                $('#horaFimSabado').val(String(rows[i].dia_semana_hora_fim)[0] + String(rows[i].dia_semana_hora_fim)[1] + ":" + String(rows[i].dia_semana_hora_fim)[2] + String(rows[i].dia_semana_hora_fim)[3]);
            }

            //checkbox
            if (rows[i].dia_semana_ativo) {
                document.getElementById('checkboxSabado').checked = true;
            } else {
                document.getElementById('checkboxSabado').checked = false;
            }
        }
        //FIM SABADO -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    }
}

function alertSwal(message) {
    swal({
        title: "Ops :-(",
        text: message,
        type: "error",
        showConfirmButton: true
    });
}

function sucessSwal(message) {
    swal({
        title: "Sucesso :)",
        text: message,
        type: "success",
        timer: 4500
    },
        function () {
            swal.close();
        });
}

function validarHora(num) {
    var er = /[^0-9\:]+/;
    er.lastIndex = 0;
    var campo = num;
    if (er.test(campo.value)) {
        campo.value = "";
    }
}

function alertChangeInfo(message) {
    swal({
        title: "Atenção!",
        text: message,
        type: "warning",
        showCancelButton: true,
        showLoaderOnConfirm: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Sim",
        cancelButtonText: "Não",
        closeOnConfirm: true
    },
        function (isConfirm) {
            if (isConfirm) {
                executeRestartSystem();
            }
        });
}

function executeRestartSystem() {
    var xhttp = new XMLHttpRequest()

    xhttp.open('GET', '/diasdasemana/restart', true);

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            switch (this.status) {
                case 200:
                    atualizarDiasDaSemana();
                    setTimeout(() => {
                        sucessSwal("Configurações aplicadas!");
                    }, 1500);
                    break;

                case 304:
                    atualizarDiasDaSemana();
                    setTimeout(() => {
                        sucessSwal("Configurações aplicadas!");
                    }, 1500);
                    break;

                case 401:
                    alertSwal('Usuário ou senha inválidos');
                    break;

                case 500:
                    alertSwal(JSON.parse(this.response).message);
                    break;

                case 404:
                    alertSwal('Não foi possível alcançar o servidor');
                    break;

                default:
                    alertSwal('Erro inesperado, contate o administrador');
            }
        }
    }
    xhttp.send();
}