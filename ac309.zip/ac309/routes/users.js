var express = require("express");
var router = express.Router();

/* GET users listing. */
router.get("/", function(req, res, next) {
  res.send("respond with a resource");
});

router.post("/validar", function(req, res, next) {
  files = req.files.importaContatos;
  //console.log("Cheguei aqui");

  if (!files) {
    return res.status(400).send({
      message: "Nenhum arquivo CSV."
    });
  }

  var allRows = null;

  //Converter arquivo csv para texto e fazer sua analise
  allRows = files.data.toString().split(/\r?\n|\r/);
  //console.log(allRows)

  //Fazer update na tabela de campanha a quantidade de contatos
  qtdContatos = allRows.length.valueOf() - 1;
  //console.log(qtdContatos);

  //Construir query para multiplos parametros no insert
  var chunks = [];

  //Inicia a partir do dado e desconsidera o titulo das colunas no csv
  for (var singleRow = 1; singleRow <= qtdContatos; singleRow++) {
    var rowCells = allRows[singleRow].split(";");
    for (var rowCell = 2; rowCell < rowCells.length; rowCell++) {
      var valueClause = [];
      //Pegar nome da cidade
      //var nomeCidade = rowCells[rowCell];
      //valueClause.push("'" + nomeCidade + "'")
      //rowCell++;

      //Pegar nome do estado
      //var nomeEstado = rowCells[rowCell];
      //valueClause.push("'" + nomeEstado + "'")
      //rowCell++;

      //Pegar Latitude
      var latitude = rowCells[rowCell];
      valueClause.push(latitude);
      rowCell++;

      //Pegar longitude
      var longitude = rowCells[rowCell];
      valueClause.push(longitude);

      //Construindo um array para insercao
      chunks.push(valueClause);
    }
  }

  /*
  console.log("Latitude 1: " + chunks[0][0]);
  console.log("Latitude 2: " + chunks[1][0]);

  console.log("\nLongitude 1: " + chunks[0][1]);
  console.log("\nLongitude 2: " + chunks[1][1]);
  */

  //console.log(chunks.length);
  for (var i = 0; i < chunks.length; i++) {
    var R = 6371e3; // metres
    var latitude1 = null;
    var latitude2 = null;
    var longitude1 = null;
    var longitude2 = null;

    if (i >= chunks.length - 1) i = chunks.length - 1;

    console.log("********************************************")
    console.log("Valor de i: " + i);
    latitude1 = chunks[i][0];
    latitude2 = chunks[i + 1][0];

    longitude1 = chunks[i][1];
    longitude2 = chunks[i + 1][1];

    console.log("Latitude 1: " + latitude1);
    console.log("Latitude 2: " + latitude2);

    console.log("\nLongitude 1: " + longitude1);
    console.log("Longitude 2: " + longitude2);

    var variacaoLatitude = toRad(latitude2 - latitude1);
    var variacaoLongitude = toRad(longitude2 - longitude1);

    console.log("Varia: " + variacaoLatitude + " Varia2: " + variacaoLongitude);
    console.log("********************************************")
    var a =
      Math.sin(variacaoLatitude / 2) * Math.sin(variacaoLatitude / 2) +
      Math.cos(latitude1) *
        Math.cos(latitude2) *
        Math.sin(variacaoLongitude / 2) *
        Math.sin(variacaoLongitude / 2);

    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    var d = R * c;

    console.log("Distancia: " + (d / 1000));
  }

  res.status(200).send({ message: "Sucesso" });
});

function toRad(coordenadas) {
  /** Converts numeric degrees to radians */
  return coordenadas * Math.PI / 180;
}

module.exports = router;
