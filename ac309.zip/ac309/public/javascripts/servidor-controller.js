function validarArquivo() {
  const importaContatos = document.getElementById("importaContatosExterno");
  var formData = new FormData();

  var data = importaContatos.files[0];

  if (data) {
    formData.append("importaContatos", data, data.name);
  } else {
    console.log("Erro ao fazer upload");
  }

  var xhttp = new XMLHttpRequest();
  xhttp.open("POST", "/users/validar", true);


  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && (this.status == 200 || this.status == 304)) {
      console.log(JSON.parse(this.response).message);
    } else if (
      this.readyState == 4 &&
      (this.status != 200 || this.status != 304)
    ) {
      console.log(JSON.parse(this.response).message);
    }
  };

  xhttp.send(formData);
}
