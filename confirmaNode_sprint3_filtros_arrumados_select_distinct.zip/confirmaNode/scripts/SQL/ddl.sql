﻿-- Database: confirma

-- DROP DATABASE confirma;

-- CREATE DATABASE confirma;

DROP TABLE contato CASCADE;
CREATE TABLE contato(
	contato_id BIGSERIAL NOT NULL,
	contato_consulta_id VARCHAR(15),
	contato_consulta_data_hora VARCHAR(80) NOT NULL,
	contato_paciente_id VARCHAR(15),
	contato_paciente_nome VARCHAR(128) NOT NULL,
	contato_paciente_tel1 VARCHAR(50) NOT NULL,
	contato_paciente_tel2 VARCHAR(50),
	contato_medico_id VARCHAR(15),
	contato_medico_nome VARCHAR(128),
	contato_especialidade VARCHAR(80),
	contato_procedimento VARCHAR(80),
	contato_localidade VARCHAR(80),
	contato_outros VARCHAR(128),
	contato_data_hora_discagem TIMESTAMP DEFAULT NOW(),
	contato_cont_discagem INT DEFAULT 0,
	PRIMARY KEY (contato_id)
);

DROP TABLE  cdr;
CREATE TABLE cdr(
	cdr_id BIGSERIAL NOT NULL,
	contato_fk BIGINT NOT NULL,
	cdr_data_hora_chamada TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	cdr_tel_discado VARCHAR(30),
	cdr_status_chamada VARCHAR(15),
	cdr_status_consulta VARCHAR(15),
	cdr_tipo VARCHAR(30),
	PRIMARY KEY (cdr_id)
);

ALTER TABLE cdr ADD CONSTRAINT cdr_contato_fk FOREIGN KEY (contato_fk) REFERENCES contato(contato_id) ON UPDATE CASCADE ON DELETE CASCADE;

DROP TABLE feriado;
CREATE TABLE feriado(
	feriado_id BIGSERIAL NOT NULL,
	feriado_data DATE NOT NULL UNIQUE,
	feriado_nome VARCHAR(20) NOT NULL,
	PRIMARY KEY (feriado_id)
);

DROP TABLE usuario;
CREATE TABLE usuario(
	usuario_id BIGSERIAL NOT NULL,
	usuario_login CHARACTER VARYING(20) NOT NULL UNIQUE,
	usuario_senha CHARACTER VARYING(128) NOT NULL,
	PRIMARY KEY (usuario_id)
);

INSERT INTO usuario(usuario_id,usuario_login,usuario_senha)
VALUES(1,'admin','353ba90f8c0b3e0f355a3d6c960b7caed5f2c1412992277c0669a04a62e7dfd35fba9f4631a7dc6d00fb44d93d305cc0b749c7501d9ce86f26148d05101b8324');

INSERT INTO usuario(usuario_id,usuario_login,usuario_senha)
VALUES(2,'filipe','353ba90f8c0b3e0f355a3d6c960b7caed5f2c1412992277c0669a04a62e7dfd35fba9f4631a7dc6d00fb44d93d305cc0b749c7501d9ce86f26148d05101b8324');
--admin
--master
--filipe
--master

DROP TABLE log;
CREATE TABLE log(
	log_id BIGSERIAL NOT NULL,
	log_data_hora_exe_query TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	log_total_consultas INTEGER,
	PRIMARY KEY (log_id)
);

DROP TABLE dia_semana;
CREATE TABLE dia_semana(
	dia_semana_id BIGSERIAL NOT NULL,
	dia_semana_dia INTEGER NOT NULL UNIQUE,
	dia_semana_hora_ini INTEGER NOT NULL,
	dia_semana_hora_fim INTEGER NOT NULL,
	PRIMARY KEY (dia_semana_id)
);

DROP TABLE configuracao;
CREATE TABLE configuracao(
	conf_id BIGSERIAL NOT NULL,
	conf_num_tentativa INT NOT NULL,--Número de tentativas CALL_LIMIT
 	conf_intervalo_discagem INT NOT NULL,--Intervalo entre discagens
	conf_chamadas_simultaneas INT NOT NULL, --CHANNLIMIT
	conf_dias_antes INT NOT NULL,--num de dias antes da consulta o sistema deve discar
	conf_cod_tomada_linha INT,--ision chipway?
	conf_csp INT, --operadora
	PRIMARY KEY (conf_id)
);

DROP TABLE audio;
CREATE TABLE audio(
	audio_id BIGSERIAL NOT NULL,
	audio_informa VARCHAR(15) NOT NULL,
	audio_confirma VARCHAR(15) NOT NULL,
	audio_tentativas VARCHAR(15) NOT NULL,
	audio_agradece VARCHAR(15) NOT NULL,
	audio_novamente VARCHAR(15) NOT NULL,
	audio_invalida VARCHAR(15) NOT NULL,
	audio_confirmada VARCHAR(15) NOT NULL,
	audio_obrigado VARCHAR(15) NOT NULL,
	audio_cancelada VARCHAR(15) NOT NULL,
	audio_reagendar VARCHAR(15) NOT NULL,
	audio_alo VARCHAR(15) NOT NULL,
	PRIMARY KEY (audio_id)
);



--verificar criar uma tela de cadastro para ision e outra pra chipway, sendo vários chipway possiveis
--DROP TABLE sip_server;--neste momento vamos pensar em somente um chipway ip com validacao por ip de origem
/*CREATE TABLE sip_server(
	id BIGSERIAL NOT NULL,
	--usuario VARCHAR(20) NOT NULL,
	--senha VARCHAR(20) NOT NULL,
	ip VARCHAR(50) NOT NULL,
	porta VARCHAR(5) NOT NULL,
	primary key (id)
);
*/
