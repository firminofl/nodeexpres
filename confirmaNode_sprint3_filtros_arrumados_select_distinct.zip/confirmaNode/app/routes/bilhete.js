var express = require('express');
var router = express.Router();
var bilhetes_controller = require('../controller/bilhetes');
var authenticate = require('../controller/authenticate');

router.use(authenticate.apiAuth);

//Mostrar todos os registros na tabela
router.get('/select', bilhetes_controller.select);

//Mostrar os registros com filtro na tabela
router.post('/search', bilhetes_controller.search);

module.exports = router;
