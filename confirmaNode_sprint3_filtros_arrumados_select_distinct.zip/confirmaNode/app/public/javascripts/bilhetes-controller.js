function exportarCSV(){
  //Datas e horas referentes ao filtro
  var inputDataInicioDiscagemBilhetes = $('#dataInicioDiscagemBilhetes').val();
  var inputDataFimDiscagemBilhetes = $('#dataFimDiscagemBilhetes').val();

  var inputHoraInicioDiscagemBilhetes = $('#horaInicioDiscagemBilhetes').val();
  var inputHoraFimDiscagemBilhetes = $('#horaFimDiscagemBilhetes').val();

  var inputDataInicioConsultaBilhetes = $('#dataInicioConsultaBilhetes').val();
  var inputDataFimConsultaBilhetes = $('#dataFimConsultaBilhetes').val();

  var inputHoraInicioConsultaBilhetes = $('#horaInicioConsultaBilhetes').val();
  var inputHoraFimConsultaBilhetes = $('#horaFimConsultaBilhetes').val();

  //paciente
  var inputNomePacienteBilhetes = $('#nomePacienteBilhetes').val();
  var inputTel1PacienteBilhetes = $('#tel1PacienteBilhetes').val();
  var inputTel2PacienteBilhetes = $('#tel2PacienteBilhetes').val();

  //medico
  var inputNomeMedicoBilhetes = $('#nomeMedicoBilhetes').val();

  //status
  var inputStatusChamadaBilhetes = $('#statusChamadaBilhetes').val();
  var inputStatusConsultaBilhetes = $('#statusConsultaBilhetes').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoBilhetes = $('#tipoAtendimentoBilhetes').val();
  var inputTelDiscadoBilhetes = $('#telDiscadoBilhetes').val();

  //Id consulta
  var inputIdConsultaBilhetes = $('#idConsultaBilhetes').val();

  //criando um objeto para passar como referencia na rota
  var object = {
    dataInicioDiscagemBilhetes: inputDataInicioDiscagemBilhetes,
    dataFimDiscagemBilhetes: inputDataFimDiscagemBilhetes,

    horaInicioDiscagemBilhetes: inputHoraInicioDiscagemBilhetes,
    horaFimDiscagemBilhetes: inputHoraFimDiscagemBilhetes,

    dataInicioConsultaBilhetes: inputDataInicioConsultaBilhetes,
    dataFimConsultaBilhetes: inputDataFimConsultaBilhetes,

    horaInicioConsultaBilhetes: inputHoraInicioConsultaBilhetes,
    horaFimConsultaBilhetes: inputHoraFimConsultaBilhetes,

    nomePacienteBilhetes: inputNomePacienteBilhetes,
    tel1PacienteBilhetes: inputTel1PacienteBilhetes,
    tel2PacienteBilhetes: inputTel2PacienteBilhetes,

    nomeMedicoBilhetes: inputNomeMedicoBilhetes,

    statusChamadaBilhetes: inputStatusChamadaBilhetes,
    statusConsultaBilhetes: inputStatusConsultaBilhetes,

    tipoAtendimentoBilhetes: inputTipoAtendimentoBilhetes,
    telDiscadoBilhetes: inputTelDiscadoBilhetes,

    idConsultaBilhetes: inputIdConsultaBilhetes
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        montarExportarTabelaCSV(JSON.parse(this.response));
        alert("Arquivo CSV gerado com sucesso!");
        break;

        case 304:
        montarExportarTabelaCSV(JSON.parse(this.response));
        alert("Arquivo CSV gerado com sucesso!");
        break;

        case 500:
        alert(JSON.parse(this.response).message);
        break;

        default:
        alert('Erro inesperado, contate o administrador.');
        break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function montarExportarTabelaCSV(rows){
  var csv = 'Data/Hora Chamada, Data/Hora Consulta, Paciente,Médico(a), Status Chamada, Status Consulta, Tipo Chamada, Tel discado, Id consulta\n';

  for (var i = 0; i < rows.length; i++) {
    csv += rows[i].cdr_data_hora_chamada;
    csv += ','+ rows[i].contato_consulta_data_hora;
    csv += ','+ rows[i].contato_paciente_nome;
    csv += ','+ rows[i].contato_medico_nome;
    csv += ','+ rows[i].cdr_status_chamada;
    csv += ','+ rows[i].cdr_status_consulta;
    csv += ','+ rows[i].cdr_tipo;
    csv += ','+ rows[i].cdr_tel_discado;
    csv += ','+ rows[i].contato_consulta_id;
    csv += '\n';
  }

  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'bilhetes.csv';
  hiddenElement.click();
}

function atualizaBilhetes() {
  var xhttp = new XMLHttpRequest();
  xhttp.open('GET', '/bilhete/select')

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        addBilhetesNaTabela(JSON.parse(this.response))
        break;
        case 304:
        addBilhetesNaTabela(JSON.parse(this.response))
        break;
        case 500:
        console.log("Erro interno com o servidor.");
        break;
        default:
        console.log("Erro inesperado, contate o administrador.");
        break;
      }
    }
  }
  xhttp.send()
}

function addBilhetesNaTabela(rows) {
  //Pegar referencia da tabela de bilhetes
  const table = document.querySelector('#tabelaBilhetes tbody');

  while (table.hasChildNodes()) {
    table.removeChild(table.firstChild);
  }

  for (var i = 0; i < rows.length; i++) {
    var newRow = table.insertRow(i);
    var count = 0;

    var actionCell = newRow.insertCell(count);

    //Data/Hora chamada
    var chamadaCell = newRow.insertCell(count);
    var date = new Date(rows[i].cdr_data_hora_chamada)
    var chamadaValue = document.createTextNode(`${(date.getDate()<10?'0':'') + date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}` + ` ${(date.getHours()<10?'0':'') + date.getHours()}:${(date.getMinutes()<10?'0':'') + date.getMinutes()}`);
    chamadaCell.appendChild(chamadaValue);
    count++;

    //Data/Hora Consulta
    var consultaCell = newRow.insertCell(count);
    var consultaValue = document.createTextNode(rows[i].contato_consulta_data_hora);
    consultaCell.appendChild(consultaValue);
    count++;

    //Paciente
    var pacienteCell = newRow.insertCell(count);
    var pacienteValue = document.createTextNode(rows[i].contato_paciente_nome);
    pacienteCell.appendChild(pacienteValue);
    count++;

    //Médico
    var medicoCell = newRow.insertCell(count);
    var medicoValue = document.createTextNode(rows[i].contato_medico_nome);
    medicoCell.appendChild(medicoValue);
    count++;


    //Status Chamada
    var statusClienteCell = newRow.insertCell(count);
    var statusClienteValue = document.createTextNode(rows[i].cdr_status_chamada);
    statusClienteCell.appendChild(statusClienteValue);
    count++;

    //Status consulta
    var statusConsultaCell = newRow.insertCell(count);
    var statusConsultaValue = document.createTextNode(rows[i].cdr_status_consulta);
    statusConsultaCell.appendChild(statusConsultaValue);
    count++;

    //Tipo consulta
    var tipoCell = newRow.insertCell(count);
    var tipoValue = document.createTextNode(rows[i].cdr_tipo);
    tipoCell.appendChild(tipoValue);
    count++;

    //Telefone discado
    var telDiscadoCell = newRow.insertCell(count);
    var telDiscadoValue = document.createTextNode(rows[i].cdr_tel_discado);
    telDiscadoCell.appendChild(telDiscadoValue);
    count++;

    //Id consulta
    var idConsultaCell = newRow.insertCell(count);
    var idConsultaValue = document.createTextNode(rows[i].contato_consulta_id);
    idConsultaCell.appendChild(idConsultaValue);
    count++;

  }
}

function buscarBilhetes() {
  //Datas e horas referentes ao filtro
  var inputDataInicioDiscagemBilhetes = $('#dataInicioDiscagemBilhetes').val();
  var inputDataFimDiscagemBilhetes = $('#dataFimDiscagemBilhetes').val();

  var inputHoraInicioDiscagemBilhetes = $('#horaInicioDiscagemBilhetes').val();
  var inputHoraFimDiscagemBilhetes = $('#horaFimDiscagemBilhetes').val();

  var inputDataInicioConsultaBilhetes = $('#dataInicioConsultaBilhetes').val();
  var inputDataFimConsultaBilhetes = $('#dataFimConsultaBilhetes').val();

  var inputHoraInicioConsultaBilhetes = $('#horaInicioConsultaBilhetes').val();
  var inputHoraFimConsultaBilhetes = $('#horaFimConsultaBilhetes').val();

  //paciente
  var inputNomePacienteBilhetes = $('#nomePacienteBilhetes').val();
  var inputTel1PacienteBilhetes = $('#tel1PacienteBilhetes').val();
  var inputTel2PacienteBilhetes = $('#tel2PacienteBilhetes').val();

  //medico
  var inputNomeMedicoBilhetes = $('#nomeMedicoBilhetes').val();

  //status
  var inputStatusChamadaBilhetes = $('#statusChamadaBilhetes').val();
  var inputStatusConsultaBilhetes = $('#statusConsultaBilhetes').val();

  //tipo de atendimento e telefone discado
  var inputTipoAtendimentoBilhetes = $('#tipoAtendimentoBilhetes').val();
  var inputTelDiscadoBilhetes = $('#telDiscadoBilhetes').val();

  //Id consulta
  var inputIdConsultaBilhetes = $('#idConsultaBilhetes').val();

  var red_alert_modal = document.getElementById('red-alert_modal');

  red_alert_modal.style.visibility = 'none';

  //criando um objeto para passar como referencia na rota
  var object = {
    dataInicioDiscagemBilhetes: inputDataInicioDiscagemBilhetes,
    dataFimDiscagemBilhetes: inputDataFimDiscagemBilhetes,

    horaInicioDiscagemBilhetes: inputHoraInicioDiscagemBilhetes,
    horaFimDiscagemBilhetes: inputHoraFimDiscagemBilhetes,

    dataInicioConsultaBilhetes: inputDataInicioConsultaBilhetes,
    dataFimConsultaBilhetes: inputDataFimConsultaBilhetes,

    horaInicioConsultaBilhetes: inputHoraInicioConsultaBilhetes,
    horaFimConsultaBilhetes: inputHoraFimConsultaBilhetes,

    nomePacienteBilhetes: inputNomePacienteBilhetes,
    tel1PacienteBilhetes: inputTel1PacienteBilhetes,
    tel2PacienteBilhetes: inputTel2PacienteBilhetes,

    nomeMedicoBilhetes: inputNomeMedicoBilhetes,

    statusChamadaBilhetes: inputStatusChamadaBilhetes,
    statusConsultaBilhetes: inputStatusConsultaBilhetes,

    tipoAtendimentoBilhetes: inputTipoAtendimentoBilhetes,
    telDiscadoBilhetes: inputTelDiscadoBilhetes,

    idConsultaBilhetes: inputIdConsultaBilhetes
  }

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function () {
    if (this.readyState == 4) {
      switch (this.status) {
        case 200:
        addBilhetesNaTabela(JSON.parse(this.response));
        $('#dismiss-modal').trigger('click');
        break;

        case 304:
        addBilhetesNaTabela(JSON.parse(this.response));
        $('#dismiss-modal').trigger('click');
        break;

        case 500:
        redAlert(JSON.parse(this.response).message);
        break;

        default:
        redAlert('Erro inesperado, contate o administrador.');
        break;
      }
    }
  }
  xhttp.open('POST', '/bilhete/search', true);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send(JSON.stringify(object));
}

function redAlert(message) {
  var success = document.getElementById('red-alert_modal');
  success.innerHTML = message
  success.classList.add('show');
  setTimeout(() => {
    success.classList.remove('show');
  }, 3000);
}

function limparCampos(){
  //Datas e horas referentes ao filtro
  $('#dataInicioDiscagemBilhetes').val('');
  $('#dataFimDiscagemBilhetes').val('');

  $('#horaInicioDiscagemBilhetes').val('');
  $('#horaFimDiscagemBilhetes').val('');

  $('#dataInicioConsultaBilhetes').val('');
  $('#dataFimConsultaBilhetes').val('');

  $('#horaInicioConsultaBilhetes').val('');
  $('#horaFimConsultaBilhetes').val('');

  //paciente
  $('#nomePacienteBilhetes').val('');
  $('#tel1PacienteBilhetes').val('');
  $('#tel2PacienteBilhetes').val('');

  //medico
  $('#nomeMedicoBilhetes').val('');

  //status
  $('#statusChamadaBilhetes').val('');
  $('#statusConsultaBilhetes').val('');

  //tipo de atendimento e telefone discado
  $('#tipoAtendimentoBilhetes').val('');
  $('#telDiscadoBilhetes').val('');

  //id consulta
  $('#idConsultaBilhetes').val('');

  atualizaBilhetes();
}
